# FAST MW 无 Docker 虚拟机生产部署指南

本文适用于在 Linux 虚拟机上直接部署以下组件：

- FAST MW 前端：Vue 3 构建后的静态文件，由 Nginx 提供访问；
- FAST MW 平台后端：Go + Gin + SQLite；
- mwDeploy：Go + BoltDB + Ansible；
- MinIO：平台日志对象存储，可使用已有 MinIO/S3 兼容服务，也可在虚拟机上以 systemd 运行 MinIO；
- 外部系统：CMDB、监控服务、CAS SSO，以及目标机器的 SSH 网络。

本文不使用 Docker。示例域名、IP、账号、证书和密码必须替换为生产值。

## 0. 已生成的 x86_64 Linux 发布目录

工作区已经生成可整体上传的发布目录：

```text
release/fast-mw-linux-amd64/
```

其中包含三个 Linux x86_64 静态二进制、前端生产构建、配置模板、systemd、Nginx、安装/预检/启停/备份脚本及本文档。目标机不需要安装 Go 或 Node.js，只需要安装运行时基础软件：Nginx、Ansible、sqlite3、curl、OpenSSL 和 systemd。

上传后执行：

```bash
sha256sum -c SHA256SUMS
sudo ./scripts/install.sh
```

发布包不会包含生产密码、TLS 证书、SSH 私钥、业务数据，也不会伪造中间件专用 Playbook。真实 `mw-ansible` 资产和 Catalog 必须在安装前补齐。

## 1. 推荐部署架构

生产环境建议至少拆成两台虚拟机：

```text
用户浏览器
    │ HTTPS :443
    ▼
平台虚拟机
    ├── Nginx：前端静态文件、/api 和 /ws 反向代理
    └── fast-mw-platform：:8080（通过防火墙仅允许本机 Nginx 访问）
          ├── SQLite：/var/lib/fast-mw/fast-mw.db
          ├── MinIO：日志上传与读取
          ├── CMDB / 监控服务 / CAS
          └── mwDeploy API
                    │ HTTPS 或受限内网 :18848
                    ▼
部署执行虚拟机
    └── mwdeploy：Ansible + BoltDB + Inventory + Playbook
          └── SSH :22 → 中间件目标机器
```

小规模环境可以把所有服务部署在同一台虚拟机：

- 平台后端当前按 `:8080` 监听全部接口，必须用主机防火墙禁止外部直接访问 8080；
- mwDeploy 监听 `127.0.0.1:18848`；
- Nginx 只暴露 `443`；
- MinIO 建议使用独立域名，如 `minio.example.internal`，避免在子路径下代理导致预签名 URL 校验失败。

### 单实例约束

- FAST MW 平台只能运行一个后端实例。SQLite 文件不能放在 NFS 上，也不能被多个进程同时作为主库使用。
- mwDeploy 的 BoltDB 状态文件同样只能由一个 mwDeploy 实例打开。
- 可以通过虚拟机快照、磁盘备份和 systemd 自动拉起提升可恢复性，但当前版本不支持多活或水平扩容。

## 2. 软件和网络准备

### 2.1 建议版本

| 软件 | 用途 | 建议 |
|---|---|---|
| Linux x86_64 | 运行环境 | 企业批准的 Rocky/RHEL/Ubuntu LTS |
| Go | 编译两个 Go 服务 | 1.22；最低需兼容项目 `go.mod` 的 1.19 |
| GCC/开发工具 | 编译平台 SQLite CGO | 必须，仅构建阶段需要 |
| Node.js | 构建前端 | 22 LTS |
| Nginx | 静态资源和反向代理 | 企业仓库稳定版 |
| sqlite3 CLI | 校验和在线备份平台数据库 | 建议安装 |
| ansible-core | mwDeploy 实际执行部署 | 必须，需提供 `ansible-playbook` |
| OpenSSH client | mwDeploy 连接目标机器 | 必须 |
| MinIO Client (`mc`) | 初始化和运维日志桶 | 建议安装 |

生产二进制应在与生产系统兼容的 Linux 构建机上编译。当前仓库中的 macOS 二进制不能复制到 Linux 使用。

### 2.2 网络端口

| 来源 | 目标 | 端口 | 说明 |
|---|---|---:|---|
| 用户浏览器 | Nginx | 443 | 平台唯一对用户开放的入口 |
| Nginx | 平台后端 | 8080 | 当前后端绑定全部接口，必须由防火墙限制为本机访问 |
| 平台后端 | mwDeploy | 18848 | 同机走回环；分机部署只允许平台 IP 访问 |
| 平台后端 | MinIO | 9000 或 HTTPS 443 | 上传、读取日志 |
| 用户浏览器 | MinIO | 9000 或 HTTPS 443 | 部署详情中的预签名日志链接可能直接访问 MinIO |
| 平台后端 | CMDB | 以生产接口为准 | 查询交付资源和部署 IP |
| 平台后端 | 监控服务 | 以生产接口为准 | 监控部署与配置 |
| 平台后端 | CAS | 443 | SSO 登录票据校验 |
| mwDeploy | 目标机器 | 22 | Ansible SSH |
| mwDeploy | 软件源等 | 以 Playbook 为准 | 安装包下载或内部制品库 |

平台后端的 8080 不应直接暴露给用户；mwDeploy 的 18848 不应暴露到办公网或公网。

## 3. 目录和运行用户

以下命令使用 root 执行：

```bash
useradd --system --user-group --home-dir /var/lib/fast-mw --shell /sbin/nologin fastmw
useradd --system --user-group --home-dir /var/lib/mwdeploy --shell /sbin/nologin mwdeploy

install -d -o root -g fastmw -m 0750 /opt/fast-mw/bin /etc/fast-mw
install -d -o fastmw -g fastmw -m 0750 /var/lib/fast-mw
install -d -o fastmw -g fastmw -m 0750 /var/log/fast-mw

install -d -o root -g mwdeploy -m 0750 /opt/mwdeploy/bin /opt/mwdeploy/mw-ansible /etc/mwdeploy
install -d -o mwdeploy -g mwdeploy -m 0700 /var/lib/mwdeploy
install -d -o mwdeploy -g mwdeploy -m 0700 /var/lib/mwdeploy/task-logs /var/lib/mwdeploy/inventory
install -d -o mwdeploy -g mwdeploy -m 0750 /var/log/mwdeploy

install -d -o root -g root -m 0755 /usr/share/nginx/html/fast-mw
```

若系统的 `nologin` 位于 `/usr/sbin/nologin`，应调整命令路径。

最终目录建议如下：

```text
/opt/fast-mw/bin/fast-mw-platform
/etc/fast-mw/config.yaml
/etc/fast-mw/platform.env
/etc/fast-mw/resource_template.xlsx
/var/lib/fast-mw/fast-mw.db

/usr/share/nginx/html/fast-mw/
/etc/nginx/conf.d/fast-mw.conf

/opt/mwdeploy/bin/mwdeploy
/opt/mwdeploy/mw-ansible/common/verify.yml
/opt/mwdeploy/mw-ansible/common/inventory_tpl/*.tpl
/opt/mwdeploy/mw-ansible/<service>/*.yml
/etc/mwdeploy/fastMwService.yml
/etc/mwdeploy/mwManageConfig.yml
/etc/mwdeploy/api-token
/var/lib/mwdeploy/mwdeploy.bolt
/var/lib/mwdeploy/task-logs/
/var/lib/mwdeploy/inventory/
/var/log/mwdeploy/mwdeploy.log
```

## 4. 构建发布包

### 4.1 构建平台后端

在 Linux 构建机进入 `fast-mw_platform/STUBS`：

```bash
go mod download
go test ./...
mkdir -p build
CGO_ENABLED=1 go build -trimpath -ldflags "-s -w" -o build/fast-mw-platform ./cmd/server
CGO_ENABLED=1 go build -trimpath -ldflags "-s -w" -o build/fast-mw-migrate ./cmd/migrate
file build/fast-mw-platform
```

平台使用 `go-sqlite3`，因此必须在 Linux 上启用 CGO 并安装 GCC。不要在 macOS 上直接交叉编译后复制到 Linux。

复制产物：

```bash
install -o root -g fastmw -m 0750 build/fast-mw-platform /opt/fast-mw/bin/fast-mw-platform
install -o root -g fastmw -m 0750 build/fast-mw-migrate /opt/fast-mw/bin/fast-mw-migrate
install -o root -g fastmw -m 0640 internal/resource/template.xlsx /etc/fast-mw/resource_template.xlsx
```

### 4.2 构建前端

进入 `fast-mw_platform/STUBS/web`：

```bash
npm ci
npm run build
```

前端 API 和 WebSocket 都使用相对路径 `/api`、`/ws`，生产构建时不需要写入后端 IP。由 Nginx 同源代理即可。

将 `dist` 中的内容发布到 Nginx 根目录：

```bash
rsync -a --delete dist/ /usr/share/nginx/html/fast-mw/
chown -R root:root /usr/share/nginx/html/fast-mw
```

### 4.3 构建 mwDeploy

进入 `mwDeploy` 仓库。该服务为纯 Go，可在 Linux 构建机执行：

```bash
go mod download
go test ./...
mkdir -p build
CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" -o build/mwdeploy ./cmd/fast-mw
file build/mwdeploy
install -o root -g mwdeploy -m 0750 build/mwdeploy /opt/mwdeploy/bin/mwdeploy
```

还必须将真实的 Ansible 资产同步到 `/opt/mwdeploy/mw-ansible`。仓库当前只包含服务代码和空的 Catalog 示例，不包含可用于生产部署的完整 Playbook、Inventory 模板和验证脚本。

## 5. 配置 MinIO 日志存储

平台仍使用 MinIO 保存核查、部署、监控和演练日志，桶名由 `minio.bucket` 配置。

推荐优先使用已有企业 MinIO/S3 兼容服务。必须完成：

1. 创建与 `minio.bucket` 相同名称的 bucket（下例使用 `fast-mw-logs`）；
2. 创建只对该桶拥有读写权限的应用账号；
3. 确保平台后端能访问 MinIO API；
4. 如果用户会打开预签名 URL，`minio.endpoint` 必须是浏览器也能解析和访问的地址；
5. 生产环境使用 HTTPS，并配置 `use_ssl: true`。

使用 `mc` 初始化的基本示例：

```bash
mc alias set prod-minio https://minio.example.internal MINIO_ADMIN_USER MINIO_ADMIN_PASSWORD
mc mb --ignore-existing prod-minio/fast-mw-logs
```

若没有现成 MinIO，可从企业制品库取得经过批准的 `minio` 二进制，并以独立 systemd 服务运行：

```bash
useradd --system --user-group --home-dir /var/lib/minio --shell /sbin/nologin minio
install -d -o minio -g minio -m 0700 /var/lib/minio
install -d -o root -g minio -m 0750 /etc/minio
```

```ini
[Unit]
Description=MinIO Object Storage
After=network-online.target
Wants=network-online.target

[Service]
User=minio
Group=minio
EnvironmentFile=/etc/minio/minio.env
ExecStart=/usr/local/bin/minio server /var/lib/minio --address :9000 --console-address :9001
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
```

`/etc/minio/minio.env` 至少包含 `MINIO_ROOT_USER` 和高强度 `MINIO_ROOT_PASSWORD`，权限设置为 `0600`。生产应为 MinIO 配置 TLS、专用应用账号和独立备份；不要让平台使用 root 凭据。

## 6. 配置并启动 mwDeploy

### 6.1 API Token

生成一段随机 Token：

```bash
openssl rand -hex 32 > /etc/mwdeploy/api-token
chown root:mwdeploy /etc/mwdeploy/api-token
chmod 0640 /etc/mwdeploy/api-token
```

平台环境变量中的 `MW_DEPLOY_API_TOKEN` 必须与该文件内容完全一致。

### 6.2 服务配置

创建 `/etc/mwdeploy/fastMwService.yml`：

```yaml
server:
  # 同机部署使用 127.0.0.1；分机部署可绑定部署网 IP。
  listenAddress: "127.0.0.1:18848"
  tls:
    enabled: false
    certFile: ""
    keyFile: ""
  timeouts:
    readHeader: 10s
    read: 30s
    write: 30s
    idle: 60s
  maxRequestBodyBytes: 2097152

auth:
  enabled: true
  tokenFile: /etc/mwdeploy/api-token

middlewareConfig: /etc/mwdeploy/mwManageConfig.yml

deployment:
  workers: 4
  queueCapacity: 100
  defaultTimeout: 30m
  maxTimeout: 2h
  defaultExistingPolicy: FAIL
  conflictScope: SERVICE_CLUSTER

ansible:
  binary: /usr/bin/ansible-playbook
  forks: 100
  noColor: true
  extraVarsFormat: JSON
  enableLifecycleHooks: false
  verifyPlaybook: /opt/mwdeploy/mw-ansible/common/verify.yml

inventory:
  reuseIdentical: true
  fileNameSeparator: "__"
  hashLength: 12
  extension: .inventory
  directoryMode: "0750"
  fileMode: "0640"
  retention:
    enabled: false

state:
  # 这是 mwDeploy 的 BoltDB 状态库，不是平台 SQLite。
  databasePath: /var/lib/mwdeploy/mwdeploy.bolt

taskLog:
  directory: /var/lib/mwdeploy/task-logs
  maxFileSize: 32MB
  retentionDays: 180

runtimeLog:
  format: json
  level: info
  directory: /var/log/mwdeploy
  fileName: mwdeploy.log
  maxSizeMB: 100
  maxBackups: 10
  retentionDays: 30
  compress: true
  # 保留一份到journald；若只希望写滚动文件可设为false。
  alsoStdout: true
```

`runtimeLog` 控制 mwDeploy 进程自身日志，和 `taskLog`（每个部署任务的执行日志）不是同一类文件。
`level` 支持 `debug/info/warn/error`，`format` 支持 `json/text`。生产建议保持 JSON + info；健康检查仅在 debug 输出，正常请求和任务阶段为 info，4xx 为 warn，5xx及任务失败为 error。运行日志不会记录 Bearer Token 或完整动态参数，可使用 `request_id`、`task_id`、`stage`、`error_code` 串联排障。
相对目录按 `fastMwService.yml` 所在目录解析，生产应使用绝对路径。升级旧配置时应显式补齐上述字段；
未配置 `directory`（包括仅保留旧版 `output: stdout`）时为兼容旧版本继续只写标准输出/journald。

如果平台与 mwDeploy 分别部署在不同虚拟机：

- `listenAddress` 改为部署网 IP，例如 `10.20.30.12:18848`；
- 建议启用 mwDeploy 自身 TLS，填写证书和私钥绝对路径；
- 使用内部 CA 时，将 CA 证书安装到平台虚拟机的系统信任库；
- 防火墙只放行平台后端 IP；
- 平台的 `external.deploy_service.base_url` 使用对应的 `https://` 地址。

### 6.3 部署 Catalog 配置

`/etc/mwdeploy/mwManageConfig.yml` 不能为空。示例：

```yaml
services:
  - name: redis
    invTemplateDir: /opt/mwdeploy/mw-ansible/common/inventory_tpl
    deployOps:
      - templateName: redis-cluster-mode
        version: "6.2.17"
        supportsRedeploy: true
        appNameMatchPattern: "redis-*"
        playbookPath: /opt/mwdeploy/mw-ansible/redis/deploy.yml
        verifyShellPath: /opt/mwdeploy/mw-ansible/redis/verify.sh
        workDir: /opt/mwdeploy/mw-ansible/redis
        invGenDir: /var/lib/mwdeploy/inventory
```

启动时会严格检查：

- `verifyPlaybook` 必须存在；
- 每个部署档案的 Inventory 模板目录、Playbook、验证脚本和工作目录必须存在；
- Inventory 模板中必须存在与 `templateName` 同名的 `{{ define "..." }}`；
- 至少存在一个 `deployOps`；
- `serviceName + templateName + version` 不能重复；
- 需要重新部署时必须显式设置 `supportsRedeploy: true`。

配置只在 mwDeploy 启动时加载，修改 `mwManageConfig.yml` 后必须重启 mwDeploy。重启运行中的部署任务会使其变成 `INTERRUPTED`，因此应在没有活动任务时操作。

对应的 Inventory 模板至少需要提供同名模板定义。例如
`/opt/mwdeploy/mw-ansible/common/inventory_tpl/redis.tpl`：

```gotemplate
{{ define "redis-cluster-mode" -}}
{{- VariableMetadata "port" "服务端口" "input" "6379" -}}
[redis]
{{- range $ip := .Params.ipList }}
{{ $ip }} redis_port={{ $.Params.port }}
{{- end }}
{{- end }}
```

`VariableMetadata`/`VariableDefine` 声明的参数会通过 Catalog 返回给平台；模板渲染时系统自动注入 `ipList`、`selectIps` 和 `clusterName`，这些是保留参数，不能由用户动态参数覆盖。

### 6.4 SSH 与 Ansible

将部署私钥放在 mwDeploy 运行用户目录，并限制权限：

```bash
install -d -o mwdeploy -g mwdeploy -m 0700 /var/lib/mwdeploy/.ssh
install -o mwdeploy -g mwdeploy -m 0600 /secure-source/id_ed25519 /var/lib/mwdeploy/.ssh/id_ed25519
```

需要同时确认：

- Inventory 模板正确设置 `ansible_user`、私钥或跳板机参数；
- mwDeploy 用户能够读取 Playbook、模板、脚本和制品；
- `sudo -u mwdeploy /usr/bin/ansible-playbook --version` 成功；
- 从 mwDeploy 虚拟机到所有目标 IP 的 SSH 和制品下载网络畅通；
- 生产应维护 `known_hosts`，避免关闭主机身份校验。

### 6.5 systemd 服务

创建 `/etc/systemd/system/mwdeploy.service`：

```ini
[Unit]
Description=FAST MW Deployment Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=mwdeploy
Group=mwdeploy
WorkingDirectory=/opt/mwdeploy
Environment=HOME=/var/lib/mwdeploy
ExecStart=/opt/mwdeploy/bin/mwdeploy --config /etc/mwdeploy/fastMwService.yml
Restart=on-failure
RestartSec=5
TimeoutStopSec=45
LimitNOFILE=65536
UMask=0027
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/mwdeploy /var/log/mwdeploy
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

启动并验证：

```bash
systemctl daemon-reload
systemctl enable --now mwdeploy
systemctl status mwdeploy
curl -fsS http://127.0.0.1:18848/health/live
curl -fsS http://127.0.0.1:18848/health/ready
curl -fsS -H "Authorization: Bearer $(cat /etc/mwdeploy/api-token)" \
  http://127.0.0.1:18848/api/v1/catalog/services
```

最后一个接口必须返回实际服务、模板、版本和 `supportsRedeploy` 能力。

## 7. 配置并启动平台后端

### 7.1 生产配置

不要直接使用仓库中的 `config.yaml` 或 `config.docker.yaml`，其中包含开发地址和开发密钥。

创建 `/etc/fast-mw/config.yaml`：

```yaml
server:
  port: 8080
  mode: release

logging:
  directory: /var/log/fast-mw
  filename: fast-mw-platform.log
  max_size_mb: 100
  max_backups: 10
  max_age_days: 30
  compress: true
  # 保留一份到journald；若只希望写滚动文件可设为false。
  also_stdout: true

database:
  path: /var/lib/fast-mw/fast-mw.db
  busy_timeout_ms: 5000
  max_open_conns: 1
  max_idle_conns: 1
  # silent/error/warn/info；生产保持warn，避免普通轮询SELECT刷屏。
  sql_log_level: warn
  slow_query_ms: 500

resource:
  # fastmw用户必须可读；替换该文件后下一次下载立即生效。
  template_path: /etc/fast-mw/resource_template.xlsx

minio:
  # 不带 http:// 或 https://；协议由 use_ssl 决定。
  endpoint: minio.example.internal
  access_key: FAST_MW_MINIO_USER
  secret_key: REPLACE_WITH_REAL_SECRET
  use_ssl: true
  bucket: fast-mw-logs

# 必须固定保存。更换 AES 密钥会导致已有敏感配置无法解密。
aes_secret_key: REPLACE_WITH_EXACTLY_32_BYTE_KEY
# 更换 JWT 密钥会使所有当前登录会话失效。
jwt_secret_key: REPLACE_WITH_LONG_RANDOM_JWT_SECRET

auth:
  # SSO 尚未联调完成时可暂时关闭，但平台必须仅开放在受控内网。
  enabled: false
  dev_username: production-operator
  frontend_url: https://fast-mw.example.internal
  session_hours: 8
  cookie_secure: true
  cas:
    server_url: https://sso.example.internal/cas
    service_url: https://fast-mw.example.internal/api/v1/auth/cas/callback
    user_id_attribute: employeeId
    role_attribute: role
    default_role: user

external:
  cmdb:
    base_url: https://cmdb-api.example.internal
    # 请求时分别写入全大写 X-CONTROL-ACCESS-APP 与 X-CONTROL-ACCESS-OPERATOR。
    access_app: fast-mw-platform
    access_operator: REPLACE_WITH_CMDB_OPERATOR
    timeout: 30
    retry_count: 3
    retry_interval: 5
  deploy_service:
    # 同机部署使用 http://127.0.0.1:18848。
    base_url: http://127.0.0.1:18848
    timeout: 30
    token_env: MW_DEPLOY_API_TOKEN
  monitor_service:
    base_url: https://monitor-api.example.internal
    timeout: 30
  ops_service:
    base_url: ""
    timeout: 30
```

升级旧配置时应显式补上 `logging` 段；未配置 `logging.directory` 时为兼容旧版本仅输出到标准输出/journald，不创建滚动文件。相对日志目录按配置文件所在目录解析，生产建议始终使用绝对路径。`database.sql_log_level`生产建议为`warn`，`database.slow_query_ms`建议从500开始调优：普通SELECT不再写运行日志，错误和慢SQL仍保留；临时排障可改为`info`，完成后应恢复`warn`。

`resource.template_path`可以使用绝对路径，也可以使用相对`config.yaml`所在目录的路径。字段缺失时默认读取同目录的`resource_template.xlsx`。文件必须非空且可由`fastmw`用户读取；运维人员可以直接替换该文件，平台每次下载时重新读取，因此无需重启。建议先写入临时文件，再以`mv`原子替换，避免用户下载到写入一半的文件。

配置文件目前不会展开 `${ENV_VAR}`。AES、JWT、MinIO 凭据必须写入 YAML 并依靠文件权限保护；只有 mwDeploy Token 会通过 `token_env` 指定的环境变量读取。

生成新密钥：

```bash
openssl rand -hex 16
openssl rand -hex 32
```

第一条输出 32 个 ASCII 字符，可作为新环境的 AES-256 密钥。若复制已有 SQLite 数据库，必须继续使用创建这些敏感配置时的原 AES 密钥，不能重新生成。

设置权限：

```bash
chown root:fastmw /etc/fast-mw/config.yaml
chmod 0640 /etc/fast-mw/config.yaml
```

### 7.2 mwDeploy Token 环境文件

创建 `/etc/fast-mw/platform.env`：

```text
MW_DEPLOY_API_TOKEN=与/etc/mwdeploy/api-token相同的Token
```

然后执行：

```bash
chown root:fastmw /etc/fast-mw/platform.env
chmod 0640 /etc/fast-mw/platform.env
```

### 7.3 初始化或迁移 SQLite

全新环境不需要提前创建数据库文件，后端会自动创建并执行 GORM AutoMigrate。也可以在启动服务前显式验证：

```bash
sudo -u fastmw /opt/fast-mw/bin/fast-mw-migrate --config /etc/fast-mw/config.yaml
sqlite3 /var/lib/fast-mw/fast-mw.db "PRAGMA integrity_check; PRAGMA journal_mode;"
```

期望输出包括：

```text
ok
wal
```

如果需要带入现有数据，应先在源端使用在线备份生成一致文件：

```bash
sqlite3 /path/to/source/fast-mw.db ".backup '/tmp/fast-mw-production.db'"
```

将备份文件复制为 `/var/lib/fast-mw/fast-mw.db`，设置所有者为 `fastmw:fastmw`、权限为 `0600`，再启动服务。不要在服务运行时只复制 `.db` 文件而忽略 WAL。

### 7.4 systemd 服务

创建 `/etc/systemd/system/fast-mw-platform.service`：

```ini
[Unit]
Description=FAST MW Delivery Platform API
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=fastmw
Group=fastmw
WorkingDirectory=/opt/fast-mw
EnvironmentFile=/etc/fast-mw/platform.env
ExecStart=/opt/fast-mw/bin/fast-mw-platform --config /etc/fast-mw/config.yaml
Restart=on-failure
RestartSec=5
TimeoutStopSec=15
LimitNOFILE=65536
UMask=0027
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/fast-mw /var/log/fast-mw
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

启动并验证：

```bash
systemctl daemon-reload
systemctl enable --now fast-mw-platform
systemctl status fast-mw-platform
curl -fsS http://127.0.0.1:8080/api/v1/auth/config
```

当前平台没有独立 `/health` 接口，公开的 `/api/v1/auth/config` 可用于进程 HTTP 检查。日志通过以下命令查看：

```bash
journalctl -u fast-mw-platform -f
```

## 8. 配置 Nginx 和前端

创建 `/etc/nginx/conf.d/fast-mw.conf`：

```nginx
map $http_upgrade $connection_upgrade {
    default upgrade;
    ''      close;
}

server {
    listen 80;
    server_name fast-mw.example.internal;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name fast-mw.example.internal;

    ssl_certificate     /etc/pki/tls/certs/fast-mw.crt;
    ssl_certificate_key /etc/pki/tls/private/fast-mw.key;

    root /usr/share/nginx/html/fast-mw;
    index index.html;
    client_max_body_size 20m;

    location /api/ {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 10s;
        proxy_read_timeout 120s;
    }

    location /ws {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;
        proxy_set_header Host $host;
        proxy_read_timeout 3600s;
    }

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

检查并启动：

```bash
nginx -t
systemctl enable --now nginx
curl -kfsS https://fast-mw.example.internal/api/v1/auth/config
```

不要把 mwDeploy 代理给浏览器，只有平台后端需要访问 mwDeploy。

## 9. 平台配置与 mwDeploy Catalog 对齐

服务启动后，在平台“管理配置 → 部署配置”中建立部署配置。以下字段必须与 mwDeploy Catalog 完全一致：

| 平台部署配置 | mwDeploy `mwManageConfig.yml` |
|---|---|
| `service_name` | `services[].name` |
| `template_name` | `deployOps[].templateName` |
| `version` | `deployOps[].version` |
| 已存在策略 `REDEPLOY` | 对应档案 `supportsRedeploy: true` |
| 动态参数名称 | Inventory 模板中的变量元数据 |

还需在平台配置：

- MWType 管理：先维护实际中间件类型，不会自动恢复默认值；
- 部署配置：配置集群正则或 MWType、服务、模板、版本、超时和动态参数；
- 核查规则、演练场景；
- 如需平台直接 SSH 核查/演练，按下一节写入 `ops` 域 SSH 配置；
- CMDB 返回的集群名、MWType 和 IP 必须与平台申请数据匹配。

修改 mwDeploy Catalog 后先调用 Catalog API 验证，再修改平台部署配置，避免用户触发时才发现档案不存在。

### 9.1 写入平台 SSH 配置

平台的 SCRIPT 核查和 SSH 演练读取以下配置，保存后后续任务立即生效，无需重启服务：

| config_group | config_key | 是否敏感 | 值 |
|---|---|---:|---|
| `ops` | `ssh_user` | 否 | 登录目标机或跳板机的用户名 |
| `ops` | `ssh_port` | 否 | SSH端口；未配置时默认`22` |
| `ops` | `ssh_private_key` | **是** | 完整PEM/OpenSSH私钥文本，不是私钥文件路径 |

推荐使用网页中的“管理配置 → SSH配置”：填写用户名和端口，粘贴完整私钥后保存。页面只显示“是否配置、格式是否有效、SHA256公钥指纹”，不会读取已保存私钥；后续只修改用户名或端口时私钥留空即可，粘贴新私钥则完成轮换。

无法使用网页时，可通过以下API方式写入。专用接口为 `GET/PUT /api/v1/configs/ssh`；以下保留通用配置接口示例，便于自动化初始化。

使用 `POST /api/v1/configs` 写入，请求必须携带有效的 `fast_mw_session` Cookie 或 Bearer JWT。下例使用安全目录中的Cookie文件，并通过 `jq --rawfile` 读取私钥，避免手工破坏换行：

```bash
PLATFORM_URL='https://fast-mw.example.com'
COOKIE_FILE='/secure/fast-mw.cookies'

curl -sS --cookie "$COOKIE_FILE" \
  -H 'Content-Type: application/json' \
  --data '{"config_group":"ops","config_key":"ssh_user","config_value":"fastmw","is_sensitive":false}' \
  "$PLATFORM_URL/api/v1/configs"

curl -sS --cookie "$COOKIE_FILE" \
  -H 'Content-Type: application/json' \
  --data '{"config_group":"ops","config_key":"ssh_port","config_value":"22","is_sensitive":false}' \
  "$PLATFORM_URL/api/v1/configs"

jq -n --rawfile key /secure/id_ed25519 \
  '{config_group:"ops",config_key:"ssh_private_key",config_value:$key,is_sensitive:true}' |
curl -sS --cookie "$COOKIE_FILE" \
  -H 'Content-Type: application/json' \
  --data-binary @- \
  "$PLATFORM_URL/api/v1/configs"
```

三次响应都应为HTTP 200且JSON字段 `code` 为 `0`；私钥响应中的 `data.value` 固定为 `****`。私钥在SQLite中以 `aes_secret_key` 加密保存，配置历史与审计参数也只保存掩码。`ops/ssh_private_key` 未设置 `is_sensitive:true` 时接口会拒绝写入，已有敏感配置也不能降级为非敏感配置。若旧版本曾把私钥按普通配置写入，升级后务必按上述命令重新写入一次；系统会把当前值加密，并清理该配置既有历史记录中的明文。

当前SSH客户端只支持无需口令解锁的私钥。写入前应确认私钥文件仅允许运维账号读取，并确认平台主机到目标IP/跳板机端口可达。执行核查后如仍失败，在SCRIPT规则明细中查看私钥解析、认证或网络错误；缺少配置时会显示 `SSH credentials not configured`。

## 10. 推荐启动顺序和上线验证

### 10.1 启动顺序

1. MinIO，并确认 `minio.bucket` 指定的 bucket 存在；
2. mwDeploy，并确认 Catalog 加载成功；
3. FAST MW 平台后端；
4. Nginx；
5. 浏览器访问平台，完成业务配置；
6. 使用测试集群执行一次完整部署链路。

### 10.2 验证命令

```bash
systemctl is-active mwdeploy fast-mw-platform nginx

curl -fsS http://127.0.0.1:18848/health/ready
curl -fsS -H "Authorization: Bearer $(cat /etc/mwdeploy/api-token)" \
  http://127.0.0.1:18848/api/v1/catalog/services

curl -fsS http://127.0.0.1:8080/api/v1/auth/config
curl -kfsS https://fast-mw.example.internal/api/v1/auth/config

# 从平台后端机器验证CMDB访问身份与查询契约。
curl -fsSG 'https://cmdb-api.example.internal/api/v2/data/server' \
  -H 'X-CONTROL-ACCESS-APP: fast-mw-platform' \
  -H 'X-CONTROL-ACCESS-OPERATOR: REPLACE_WITH_CMDB_OPERATOR' \
  --data-urlencode 'query={"and":[{"eq":{"field":"operator","value":"01"}},{"eq":{"field":"status","value":"ACTIVE"}},{"eq":{"field":"cloudCode","value":"REPLACE_WITH_IDC"}}],"field":["ipAddress","appName"]}'

sqlite3 /var/lib/fast-mw/fast-mw.db "PRAGMA integrity_check;"
journalctl -u mwdeploy -n 100 --no-pager
journalctl -u fast-mw-platform -n 100 --no-pager
tail -n 100 /var/log/mwdeploy/mwdeploy.log
tail -n 100 /var/log/fast-mw/fast-mw-platform.log
```

业务验收至少覆盖：

- 登录或关闭认证时的受控访问；
- 创建流程和刷新页面后数据仍存在；
- CMDB 能返回正确集群/IP；
- 平台能读取 mwDeploy Catalog；
- 首次部署、日志读取、失败重试；
- 声明能力后的重新部署；
- 用户编辑的 IP 顺序原样传入 mwDeploy；
- MinIO 日志可查看；
- 重启平台后历史流程仍可查询；
- 无活动任务时重启 mwDeploy，历史任务仍可查询。

## 11. 备份与恢复

### 11.1 平台 SQLite

在线备份：

```bash
install -d -o fastmw -g fastmw -m 0700 /var/backups/fast-mw
sudo -u fastmw sqlite3 /var/lib/fast-mw/fast-mw.db \
  ".backup '/var/backups/fast-mw/fast-mw-$(date +%F-%H%M%S).db'"
```

恢复：

1. 停止 `fast-mw-platform`；
2. 备份当前数据库及 `-wal`、`-shm` 文件；
3. 将目标备份复制为 `/var/lib/fast-mw/fast-mw.db`；
4. 修正属主和权限；
5. 执行 `PRAGMA integrity_check`；
6. 启动平台并验证。

### 11.2 mwDeploy

BoltDB 状态文件与任务日志应一起备份。为获得确定的一致性，选择没有活动部署任务的时间窗口：

```bash
systemctl stop mwdeploy
tar -C /var/lib -czf /var/backups/mwdeploy-$(date +%F-%H%M%S).tar.gz mwdeploy
systemctl start mwdeploy
```

同时备份 `/etc/mwdeploy` 和 `/opt/mwdeploy/mw-ansible`。恢复时版本、Catalog、Playbook 和状态库应保持配套。

### 11.3 MinIO

使用企业对象存储的版本控制、复制或备份策略。只有 SQLite 而没有 `minio.bucket` 指定的 bucket 时，流程记录仍在，但历史日志会无法读取。

## 12. 升级与回滚

### 平台升级

1. 构建并测试新后端和前端；
2. 在线备份 SQLite；
3. 保存旧二进制、旧前端目录和旧配置；
4. 停止平台后端；
5. 替换二进制并运行 `fast-mw-migrate`；
6. 替换前端静态文件；
7. 启动后端并检查 API；
8. `nginx -t` 后 reload；
9. 业务验证。

如果新版本执行了不可逆 Schema 迁移，回滚二进制时也必须同时恢复升级前 SQLite 备份。

### mwDeploy 升级

1. 确认没有 `QUEUED/RUNNING/CANCELING` 任务；
2. 停止服务并备份 BoltDB、日志、Catalog 和 Ansible 资产；
3. 替换二进制和配置；
4. 启动后检查 `/health/ready` 和 Catalog API；
5. 用测试集群验证。

## 13. 安全要求

- 平台当前允许临时关闭认证。关闭期间必须依赖内网、VPN、Nginx ACL 或防火墙限制访问，不能暴露公网。
- 平台后端当前只配置端口、不配置监听地址，会绑定全部接口；主机防火墙必须拒绝外部访问 8080。
- SSO 联调完成后启用 `auth.enabled: true`，确保 CAS 回调地址与平台注册地址完全一致，并保持 `cookie_secure: true`。
- mwDeploy 必须启用 Bearer Token；跨虚拟机时应同时启用 TLS 或在可信部署专网中传输。
- 平台 YAML、mwDeploy Token、SSH 私钥和 TLS 私钥不得进入源码仓库。
- SQLite、BoltDB、配置文件和日志目录按最小权限设置。
- mwDeploy 运行用户不应拥有无边界 root 权限。Playbook 如需提权，应使用受控的 `become` 和 sudo 规则。
- 限制 mwDeploy 到目标机器的网络范围，维护 SSH `known_hosts`。
- 对所有备份加密，并定期执行恢复演练。

## 14. 常见故障

### 平台启动报 SQLite 文件不可写

检查 `/var/lib/fast-mw` 是否属于 `fastmw:fastmw`，systemd 是否包含 `ReadWritePaths=/var/lib/fast-mw /var/log/fast-mw`，磁盘是否只读或已满。若提示日志目录不可写，同样检查 `/var/log/fast-mw` 的所有者与权限。

### 平台提示 mwDeploy 未配置或调用失败

检查：

- `external.deploy_service.base_url`；
- `MW_DEPLOY_API_TOKEN` 是否加载；
- Token 是否与 `/etc/mwdeploy/api-token` 一致；
- 18848 防火墙和 TLS 证书；
- `curl` Catalog API 是否成功。

### mwDeploy 无法启动

通常是 Catalog 资产不完整。查看：

```bash
journalctl -u mwdeploy -n 200 --no-pager
```

重点检查 `ansible-playbook`、通用验证 Playbook、Inventory 模板中的 `define`、部署 Playbook、验证脚本、工作目录和至少一个 `deployOps`。
若错误提示运行日志目录不可写，检查 `/var/log/mwdeploy` 是否属于 `mwdeploy:mwdeploy`，以及 systemd 是否包含
`ReadWritePaths=/var/lib/mwdeploy /var/log/mwdeploy`。

### 平台提示部署档案不存在

平台的 service/template/version 与 mwDeploy Catalog 不一致。以 Catalog API 返回结果为准逐字段核对，大小写之外不要依赖模糊匹配。

### `REDEPLOY_NOT_SUPPORTED`

在对应的 `serviceName + templateName + version` 档案中配置 `supportsRedeploy: true`，重启 mwDeploy，再调用 Catalog API 确认能力已生效。

### MinIO 日志链接浏览器打不开

预签名 URL 使用 `minio.endpoint` 生成。不要配置只有平台服务器自己能解析的 `localhost` 或容器名；应配置浏览器可访问的 MinIO 域名，并确保 HTTP/HTTPS 与 `use_ssl` 一致。

## 15. 上线检查清单

- [ ] 两个 Go 二进制均为 Linux 目标架构；
- [ ] 前端 `npm run build` 成功并已发布到 Nginx；
- [ ] Nginx HTTPS、SPA 回退、`/api`、`/ws` 均正常；
- [ ] 平台 SQLite 位于本地持久化磁盘，单实例运行；
- [ ] SQLite 完整性为 `ok`、journal mode 为 `wal`；
- [ ] AES 密钥已固定保存，迁移旧库时沿用原密钥；
- [ ] MinIO 中 `minio.bucket` 指定的 bucket 已创建且凭据为最小权限；
- [ ] `/var/log/fast-mw` 可写，日志滚动大小、保留个数和保留天数符合运维策略；
- [ ] mwDeploy Bearer Token 已启用并与平台环境变量一致；
- [ ] mwDeploy BoltDB、任务日志和 Inventory 目录可写；
- [ ] Ansible、Playbook、模板、验证脚本和 SSH 网络验证通过；
- [ ] 平台部署配置与 mwDeploy Catalog 完全一致；
- [ ] CMDB、监控服务、CAS/认证策略已确认；
- [ ] systemd 服务已启用自动启动；
- [ ] 防火墙只开放必要端口；
- [ ] SQLite、BoltDB、MinIO 和配置文件备份已启用；
- [ ] 已使用非生产测试集群完成一次端到端部署。

## 逐步演练升级（2026-09-17）

1. 升级前备份SQLite业务库和现有加密密钥配置；按现有停机/备份流程操作，避免升级时仍有真实演练执行。
2. 启动自动迁移新增接口模板、步骤尝试模型并扩展演练记录。旧记录保留只读；旧固定IP、ANSIBLE或自由API场景需在管理页重新配置。
3. 成功部署记录须包含HostOrder主机快照才能创建新演练。先登记“演练接口”和凭据，再为场景配置Shell/API步骤；不需要新增中间件依赖。
4. 后端需能SSH访问目标节点及HTTP访问登记的接口；认证凭据加密存储于SQLite，备份恢复必须同时保留原加密密钥。
5. 新演练输入与限长步骤输出存SQLite，纳入容量和备份管理；旧日志仍在MinIO。重启后执行中的尝试为UNKNOWN，运维核实远端结果并记录依据后才能继续，不会自动重放。
6. 终止演练只结束平台记录，不会自动撤销已执行的外部操作；应先执行所需恢复步骤并填写终止原因。

