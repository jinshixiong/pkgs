# 必须补充生产 Ansible 资产

mwDeploy 启动前，应将实际资产放到本目录。安装脚本会整体复制到
`/opt/mwdeploy/mw-ansible`。

最低结构：

```text
mw-ansible/
├── common/
│   ├── verify.yml
│   └── inventory_tpl/
│       └── <service>.tpl
└── <service>/
    ├── deploy.yml
    └── verify.sh
```

Inventory 模板必须包含与 Catalog `templateName` 同名的定义：

```gotemplate
{{ define "redis-cluster-mode" -}}
{{- VariableMetadata "port" "服务端口" "input" "6379" -}}
[redis]
{{- range $ip := .Params.ipList }}
{{ $ip }} redis_port={{ $.Params.port }}
{{- end }}
{{- end }}
```

不要使用无条件成功的空验证脚本或空 Playbook代替真实资产，否则会给生产部署结果造成误判。
