#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "请使用 root 或 sudo 执行 install.sh" >&2
  exit 1
fi

case "$(uname -m)" in
  x86_64|amd64) ;;
  *) echo "本发布包仅支持 x86_64 Linux，当前架构: $(uname -m)" >&2; exit 1 ;;
esac

bundle_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
nologin_bin="$(command -v nologin || true)"
if [[ -z ${nologin_bin} ]]; then
  nologin_bin=/sbin/nologin
fi

for required in openssl install systemctl; do
  command -v "${required}" >/dev/null || { echo "缺少命令: ${required}" >&2; exit 1; }
done

id fastmw >/dev/null 2>&1 || useradd --system --user-group --home-dir /var/lib/fast-mw --shell "${nologin_bin}" fastmw
id mwdeploy >/dev/null 2>&1 || useradd --system --user-group --home-dir /var/lib/mwdeploy --shell "${nologin_bin}" mwdeploy

install -d -o root -g fastmw -m 0750 /opt/fast-mw/bin /etc/fast-mw
install -d -o fastmw -g fastmw -m 0750 /var/lib/fast-mw
install -d -o fastmw -g fastmw -m 0750 /var/log/fast-mw
install -d -o root -g mwdeploy -m 0750 /opt/mwdeploy/bin /opt/mwdeploy/mw-ansible /etc/mwdeploy
install -d -o mwdeploy -g mwdeploy -m 0700 /var/lib/mwdeploy /var/lib/mwdeploy/task-logs /var/lib/mwdeploy/inventory
install -d -o mwdeploy -g mwdeploy -m 0750 /var/log/mwdeploy
install -d -o root -g root -m 0755 /usr/share/nginx/html/fast-mw

install -o root -g fastmw -m 0750 "${bundle_dir}/bin/fast-mw-platform" /opt/fast-mw/bin/fast-mw-platform
install -o root -g fastmw -m 0750 "${bundle_dir}/bin/fast-mw-migrate" /opt/fast-mw/bin/fast-mw-migrate
install -o root -g mwdeploy -m 0750 "${bundle_dir}/bin/mwdeploy" /opt/mwdeploy/bin/mwdeploy

cp -a "${bundle_dir}/frontend/." /usr/share/nginx/html/fast-mw/
chown -R root:root /usr/share/nginx/html/fast-mw

cp -a "${bundle_dir}/mw-ansible/." /opt/mwdeploy/mw-ansible/
chown -R root:mwdeploy /opt/mwdeploy/mw-ansible
find /opt/mwdeploy/mw-ansible -type d -exec chmod 0750 {} +
chmod -R g+rX,o-rwx /opt/mwdeploy/mw-ansible

if [[ ! -f /etc/mwdeploy/fastMwService.yml ]]; then
  install -o root -g mwdeploy -m 0640 "${bundle_dir}/config/mwdeploy/fastMwService.yml" /etc/mwdeploy/fastMwService.yml
fi
if [[ ! -f /etc/mwdeploy/mwManageConfig.yml ]]; then
  install -o root -g mwdeploy -m 0640 "${bundle_dir}/config/mwdeploy/mwManageConfig.yml" /etc/mwdeploy/mwManageConfig.yml
fi
if [[ ! -f /etc/mwdeploy/api-token ]]; then
  umask 0077
  openssl rand -hex 32 > /etc/mwdeploy/api-token
  chown root:mwdeploy /etc/mwdeploy/api-token
  chmod 0640 /etc/mwdeploy/api-token
fi

if [[ ! -f /etc/fast-mw/config.yaml ]]; then
  aes_secret="$(openssl rand -hex 16)"
  jwt_secret="$(openssl rand -hex 32)"
  sed -e "s/__AES_SECRET_KEY__/${aes_secret}/" -e "s/__JWT_SECRET_KEY__/${jwt_secret}/" \
    "${bundle_dir}/config/fast-mw/config.yaml" > /etc/fast-mw/config.yaml
  chown root:fastmw /etc/fast-mw/config.yaml
  chmod 0640 /etc/fast-mw/config.yaml
fi
if [[ ! -f /etc/fast-mw/resource_template.xlsx ]]; then
  install -o root -g fastmw -m 0640 "${bundle_dir}/config/fast-mw/resource_template.xlsx" /etc/fast-mw/resource_template.xlsx
fi

token_value="$(tr -d '\r\n' < /etc/mwdeploy/api-token)"
if [[ ! -f /etc/fast-mw/platform.env ]]; then
  printf 'MW_DEPLOY_API_TOKEN=%s\n' "${token_value}" > /etc/fast-mw/platform.env
  chown root:fastmw /etc/fast-mw/platform.env
  chmod 0640 /etc/fast-mw/platform.env
fi

install -o root -g root -m 0644 "${bundle_dir}/config/systemd/fast-mw-platform.service" /etc/systemd/system/fast-mw-platform.service
install -o root -g root -m 0644 "${bundle_dir}/config/systemd/mwdeploy.service" /etc/systemd/system/mwdeploy.service

install -d -o root -g root -m 0755 /etc/nginx/conf.d
install -o root -g root -m 0644 "${bundle_dir}/config/nginx/fast-mw.conf" /etc/nginx/conf.d/fast-mw.conf.example

systemctl daemon-reload

echo "文件安装完成，尚未启动服务。"
echo "请补齐 /etc/fast-mw/config.yaml、/etc/mwdeploy/mwManageConfig.yml、Ansible资产和Nginx证书配置。"
echo "然后执行: ${bundle_dir}/scripts/preflight.sh"
