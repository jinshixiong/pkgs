#!/usr/bin/env bash
set -u

systemctl --no-pager --full status mwdeploy fast-mw-platform nginx || true

echo
echo "mwDeploy live:"
curl -fsS http://127.0.0.1:18848/health/live || true
echo
echo "mwDeploy ready:"
curl -fsS http://127.0.0.1:18848/health/ready || true
echo
echo "平台 API:"
curl -fsS http://127.0.0.1:8080/api/v1/auth/config || true
echo
