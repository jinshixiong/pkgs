#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "请使用 root 或 sudo 执行 stop.sh" >&2
  exit 1
fi

systemctl stop fast-mw-platform
systemctl stop mwdeploy
echo "平台后端和mwDeploy已停止；Nginx保持运行。"
