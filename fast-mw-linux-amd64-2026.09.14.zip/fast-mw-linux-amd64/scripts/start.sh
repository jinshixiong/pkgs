#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "请使用 root 或 sudo 执行 start.sh" >&2
  exit 1
fi

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"${script_dir}/preflight.sh"

systemctl daemon-reload
systemctl enable --now mwdeploy
systemctl enable --now fast-mw-platform
systemctl enable --now nginx
systemctl reload nginx

echo "服务已启动。执行 ${script_dir}/status.sh 查看状态。"
