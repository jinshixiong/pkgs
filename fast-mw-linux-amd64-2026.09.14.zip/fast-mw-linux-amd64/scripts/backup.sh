#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "请使用 root 或 sudo 执行 backup.sh" >&2
  exit 1
fi

backup_root="${1:-/var/backups/fast-mw}"
backup_time="$(date +%F-%H%M%S)"
backup_dir="${backup_root}/${backup_time}"
install -d -o fastmw -g fastmw -m 0700 "${backup_dir}"

if [[ -f /var/lib/fast-mw/fast-mw.db ]]; then
  runuser -u fastmw -- sqlite3 /var/lib/fast-mw/fast-mw.db ".backup '${backup_dir}/fast-mw.db'"
  chown root:root "${backup_dir}/fast-mw.db"
  chmod 0600 "${backup_dir}/fast-mw.db"
fi

mwdeploy_was_active=false
restart_mwdeploy_on_exit() {
  if [[ ${mwdeploy_was_active} == true ]] && ! systemctl is-active --quiet mwdeploy; then
    systemctl start mwdeploy || true
  fi
}
trap restart_mwdeploy_on_exit EXIT

if systemctl is-active --quiet mwdeploy; then
  mwdeploy_was_active=true
  if [[ ${ALLOW_MWDEPLOY_STOP:-0} != 1 ]]; then
    echo "mwDeploy正在运行。请先确认没有活动任务，再执行：" >&2
    echo "ALLOW_MWDEPLOY_STOP=1 sudo -E $0 ${backup_root}" >&2
    exit 2
  fi
  echo "将短暂停止mwDeploy以一致备份BoltDB。"
  systemctl stop mwdeploy
fi

tar -C /var/lib -czf "${backup_dir}/mwdeploy-data.tar.gz" mwdeploy

if [[ ${mwdeploy_was_active} == true ]]; then
  systemctl start mwdeploy
  mwdeploy_was_active=false
fi

tar -czf "${backup_dir}/configuration.tar.gz" /etc/fast-mw /etc/mwdeploy /opt/mwdeploy/mw-ansible 2>/dev/null
chown -R root:root "${backup_dir}"

echo "备份完成: ${backup_dir}"
