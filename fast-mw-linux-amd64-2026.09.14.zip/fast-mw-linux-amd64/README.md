# FAST MW Linux x86_64 单目录发布包

本目录可整体复制到 x86_64 Linux 虚拟机。包内包含：

- `bin/fast-mw-platform`：平台后端 Linux x86_64 二进制；
- `bin/fast-mw-migrate`：SQLite Schema 迁移工具；
- `bin/mwdeploy`：mwDeploy Linux x86_64 二进制；
- `frontend/`：已构建的 Vue 前端静态文件；
- `config/`：平台、mwDeploy、systemd 和 Nginx 配置模板；
- `config/fast-mw/resource_template.xlsx`：由服务器目录动态读取的资源申请模板；
- `scripts/`：安装、预检、启停、状态和备份脚本；
- `mw-ansible/`：生产 Ansible 资产放置目录；
- `docs/`：完整生产部署指南；
- `SHA256SUMS`：发布文件校验值。

## 不能自动提供的生产信息

以下内容与实际机房和中间件部署方式相关，发布包不会伪造：

1. mwDeploy 的真实 Playbook、Inventory 模板和验证脚本；
2. `mwManageConfig.yml` 中的真实服务 Catalog；
3. MinIO、CMDB、监控服务和 CAS 的生产地址/凭据；
4. TLS 证书、SSH 私钥和 sudo/become 规则。

未补齐这些内容前，`scripts/preflight.sh` 会拒绝启动。

## 快速部署

1. 校验并解压发布包：

   ```bash
   sha256sum -c SHA256SUMS
   ```

2. 把真实 Ansible 资产放入当前目录的 `mw-ansible/`，编辑：

   - `config/mwdeploy/mwManageConfig.yml`
   - `config/mwdeploy/fastMwService.yml`
   - `config/fast-mw/config.yaml`
   - `config/nginx/fast-mw.conf`

3. root 执行安装。首次安装会生成 mwDeploy Token、平台 AES 密钥和 JWT 密钥：

   ```bash
   sudo ./scripts/install.sh
   ```

   如果要迁入已有平台 SQLite，启动前必须把 `/etc/fast-mw/config.yaml`
   中自动生成的 AES 密钥替换为原环境密钥，再复制数据库。

4. 根据实际域名修改并启用 Nginx 配置：

   ```bash
   sudo cp /etc/nginx/conf.d/fast-mw.conf.example /etc/nginx/conf.d/fast-mw.conf
   sudo vi /etc/nginx/conf.d/fast-mw.conf
   ```

5. 修改 `/etc/fast-mw/config.yaml` 和 `/etc/mwdeploy/*.yml` 中尚未替换的生产参数。

6. 预检并启动：

   ```bash
   sudo ./scripts/preflight.sh
   sudo ./scripts/start.sh
   ./scripts/status.sh
   ```

完整说明见 `docs/PRODUCTION_VM_DEPLOYMENT_GUIDE.md`。

## 重要限制

- 平台 SQLite 和 mwDeploy BoltDB 均按单实例运行；
- 平台后端当前监听全部接口的 8080，必须通过防火墙禁止外部直接访问；
- mwDeploy 18848 只允许平台后端访问；
- SSO 尚未启用时，平台必须位于受控内网；
- `minio.bucket` 指定的 bucket 必须在 MinIO 中提前创建；
- 平台运行日志按 `logging` 配置写入并滚动，安装脚本默认创建 `/var/log/fast-mw`。
- mwDeploy 运行日志按 `runtimeLog` 配置写入并滚动，安装脚本默认创建 `/var/log/mwdeploy`；升级已有安装时需手动把新增字段合入 `/etc/mwdeploy/fastMwService.yml`。
- SCRIPT 核查/SSH 演练所需的 `ops/ssh_user`、`ops/ssh_port`、`ops/ssh_private_key` 可在“管理配置 → SSH配置”维护；私钥只写不回显，操作说明见生产部署指南 9.1 节。
- “中间件类型”配置保存什么文本，各管理与交付页面就逐字显示什么文本，不再自动改变部分类型的大小写。
- 资源申请下载模板由`resource.template_path`指定；安装包默认安装到`/etc/fast-mw/resource_template.xlsx`，替换后无需重启平台。
