# Implementation Plan

> 本文档是弱模型可逐步执行的实现蓝图。严格按 Phase→Step 顺序执行，每个 Step 精确到文件路径、函数签名、依赖版本。

## Phase 依赖关系

```
Phase 1 (基础骨架) ──→ Phase 2 (数据模型与基础层) ──→ Phase 3 (管理配置模块) ──→ Phase 4 (交付流程引擎)
                                                                    │
                                                                    ├──→ Phase 5 (业务模块：资源+核查)
                                                                    ├──→ Phase 6 (业务模块：部署+监控)
                                                                    └──→ Phase 7 (业务模块：演练+推送)
Phase 5 ──→ Phase 6 ──→ Phase 7
Phase 8 (前端) 在 Phase 4 完成后可并行启动
```

---

## Phase 1: 项目骨架与基础层

**目标**：创建可编译的 Go 项目骨架，初始化依赖，实现配置中心和数据库连接。

### Step 1.1: 初始化项目结构与 Go Module

- 创建目录结构：
  ```
  fast-mw/
  ├── cmd/server/main.go
  ├── internal/
  │   ├── config/       # 配置中心
  │   ├── database/     # 数据库连接
  │   ├── cache/        # 进程内缓存
  │   ├── lock/         # 分布式锁
  │   ├── middleware/    # Gin中间件（认证、审计、限流）
  │   ├── model/        # GORM数据模型
  │   ├── adapter/      # 外部服务适配器
  │   │   ├── cmdb/
  │   │   ├── deploy/
  │   │   ├── monitor/
  │   │   └── ops/
  │   ├── flow/         # 交付流程引擎
  │   ├── resource/     # 资源申请模块
  │   ├── check/        # 核查引擎模块
  │   ├── monitor/      # 监控部署模块
  │   ├── deploy/       # 服务部署模块
  │   ├── drill/        # 演练引擎模块
  │   ├── admin/        # 管理配置模块
  │   └── common/       # 公共工具（错误码、响应格式）
  ├── api/              # HTTP handler（Gin路由分组）
  │   ├── v1/
  │   │   ├── flow.go
  │   │   ├── resource.go
  │   │   ├── check.go
  │   │   ├── monitor.go
  │   │   ├── deploy.go
  │   │   ├── drill.go
  │   │   └── admin.go
  ├── pkg/              # 可导出公共包
  │   ├── response/     # 统一响应格式
  │   ├── errcode/      # 错误码定义
  │   └── minio/        # MinIO客户端封装
  ├── config.yaml       # 配置文件模板
  ├── Dockerfile
  └── Makefile
  ```
- 文件: `cmd/server/main.go`
  - 函数签名: `func main()` — 初始化配置、数据库、缓存、路由，启动 Gin server
- 文件: `go.mod`
  - module: `github.com/yourorg/fast-mw`
  - 依赖声明:
    ```
    go 1.21
    github.com/gin-gonic/gin v1.9.1
    gorm.io/gorm v1.25.12
    gorm.io/driver/mysql v1.5.7
    github.com/patrickmn/go-cache v2.1.0+incompatible
    github.com/panjf2000/ants/v2 v2.10.0
    github.com/minio/minio-go/v7 v7.0.74
    github.com/golang-jwt/jwt/v5 v5.2.1
    github.com/swaggo/swag v1.16.3
    github.com/swaggo/gin-swagger v1.6.0
    github.com/xuri/excelize/v2 v2.8.1
    golang.org/x/crypto v0.28.0
    golang.org/x/oauth2 v0.23.0
    github.com/gorilla/websocket v1.5.3
    ```
- 验收: `go mod tidy && go build ./cmd/server/` 编译成功

- 新增: `config.yaml` 中 `external.cmdb.base_url` 等外部服务地址占位符

生产环境从环境变量注入

#### main.go 初始化接线详细逻辑流程

**启动顺序**: 配置加载 → 数据库初始化 → 缓存/锁初始化 → ConfigCenter初始化 → 服务创建 → 中间件注册 → 路由注册 → WebSocket Hub → 后台goroutine启动 → 优雅退出

**正常流程**:

```
func main() {
    // 1. 加载配置
    cfg, err := config.Load("config.yaml")
    if err != nil {
        log.Fatalf("加载配置失败: %v", err)
    }
    
    // 环境变量覆盖: AES_SECRET_KEY, JWT_SECRET_KEY
    // 生产环境建议从环境变量注入, 不写入config.yaml
    
    // 2. 初始化数据库
    db, err := database.InitDB(&cfg.Database)
    if err != nil {
        log.Fatalf("初始化数据库失败: %v", err)
    }
    
    // 3. 初始化缓存
    localCache := cache.NewLocalCache(30*time.Minute, 1*time.Minute)
    
    // 4. 初始化分布式锁
    distributedLock := lock.NewDistributedLock(db)
    
    // 5. 初始化 ConfigCenter
    configCenter := config.NewConfigCenter(db)
    if err := configCenter.Init(); err != nil {
        log.Fatalf("ConfigCenter初始化失败: %v", err)
    }
    
    // 6. 创建 MinIO 客户端
    minioClient, err := minio.NewMinioClient(&cfg.Minio)
    if err != nil {
        log.Fatalf("MinIO初始化失败: %v", err)
    }
    
    // 7. 创建外部服务适配器
    cmdbClient := adapter.NewCMDBClient(&cfg.External.CMDB)
    deployClient := adapter.NewDeployClient(&cfg.External.DeployService)
    monitorClient := adapter.NewMonitorClient(&cfg.External.MonitorService)
    opsClient := adapter.NewOpsClient(&cfg.External.OpsService, configCenter)  // ★ OpsClient依赖ConfigCenter(SSH凭据)
    
    // 8. 创建协程池
    pool, err := ants.NewPool(10)  // 10个协程, 限制并发
    if err != nil {
        log.Fatalf("协程池初始化失败: %v", err)
    }
    
    // 9. 创建管理配置服务(admin模块不依赖外部适配器)

    checkRuleSvc := admin.NewCheckRuleService(db)
    drillSceneSvc := admin.NewDrillSceneService(db)
    deployConfigSvc := admin.NewDeployConfigService(db)
    
    // 10. 创建业务服务(注意依赖注入顺序)
    flowEngine := flow.NewFlowEngine(db)
    resourceSvc := resource.NewResourceService(db, cmdbClient, configCenter)  // ★ ResourceService依赖ConfigCenter(ownerGroup/opsGroup)
    checkSvc := check.NewCheckService(db, pool, checkRuleSvc, minioClient)
    deploySvc := deploy.NewDeployService(db, deployClient, deployConfigSvc)  // ★ DeployService内部创建activeTasks
    monitorSvc := monitor.NewMonitorService(db, monitorClient, minioClient)  // ★ MonitorService内部创建activeTasks
    drillSvc := drill.NewDrillService(db, pool, drillSceneSvc, opsClient, minioClient)
    
    // 11. 创建 WebSocket Hub
    wsHub := flow.NewWSHub()
    flowWebSocket := flow.NewFlowWebSocket(wsHub)
    
    // 12. 注册 Gin 中间件
    r := gin.Default()
    r.Use(middleware.JWTAuth())        // JWT认证(应用在/api/v1路由组)
    r.Use(middleware.AuditLog(db))     // 审计日志(应用在/api/v1路由组)
    r.Use(middleware.RateLimit(100))   // 令牌桶限流: 100rps
    
    // 13. 注册路由
    apiGroup := r.Group("/api/v1")
    // JWTAuth+AuditLog+RateLimit 应用于 apiGroup
    apiGroup.Use(middleware.JWTAuth(), middleware.AuditLog(db), middleware.RateLimit(100))
    
    v1.RegisterFlowRoutes(apiGroup, flowEngine, flowWebSocket)
    v1.RegisterResourceRoutes(apiGroup, resourceSvc)
    v1.RegisterCheckRoutes(apiGroup, checkSvc)
    v1.RegisterDeployRoutes(apiGroup, deploySvc)
    v1.RegisterMonitorRoutes(apiGroup, monitorSvc)
    v1.RegisterDrillRoutes(apiGroup, drillSvc)
    v1.RegisterAdminRoutes(apiGroup, checkRuleSvc, drillSceneSvc, deployConfigSvc)
    
    // WebSocket 路由(不使用JWTAuth/AuditLog/RateLimit, 仅使用Gin的WebSocket升级)
    r.GET("/ws", flowWebSocket.HandleConnection)
    
    // 14. 启动后台goroutine
    ctx, cancel := context.WithCancel(context.Background())
    
    // ConfigCenter 热更新 goroutine
    go configCenter.StartHotReload(ctx)
    
    // DistributedLock 清理 goroutine
    go distributedLock.StartCleanup(ctx)
    
    // ★ 重启恢复: 查询DB中未完成的部署和监控任务, 恢复轮询
    // DeployService 重启恢复
    deploySvc.RecoverUnfinishedTasks()
    
    // MonitorService 重启恢复
    monitorSvc.RecoverUnfinishedTasks()
    
    // 15. 启动 Gin server
    srv := &http.Server{
        Addr:    fmt.Sprintf(":%d", cfg.Server.Port),
        Handler: r,
    }
    
    go func() {
        if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
            log.Printf("服务启动失败: %v", err)
        }
    }()
    
    // 16. 优雅退出
    quit := make(chan os.Signal, 1)
    signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
    <-quit
    
    log.Println("收到退出信号, 开始优雅退出...")
    
    // 17. 优雅退出步骤:
    // a. 停止接受新请求: srv.Shutdown(ctx_5s)
    shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 5*time.Second)
    defer shutdownCancel()
    if err := srv.Shutdown(shutdownCtx); err != nil {
        log.Printf("HTTP服务关闭失败: %v", err)
    }
    
    // b. 停止后台goroutine: cancel()
    cancel()  // 通知ConfigCenter热更新/锁清理goroutine退出
    
    // c. 停止部署/监控轮询goroutine: 遍历activeTasks调用cancel
    // DeployService和MonitorService通过StopAllTasks()遍历activeTasks调用每个cancel函数
    deploySvc.StopAllTasks()
    monitorSvc.StopAllTasks()
    
    // d. 关闭协程池
    pool.Release()
    
    // e. 关闭数据库连接
    sqlDB, _ := db.DB()
    sqlDB.Close()
    
    log.Println("优雅退出完成")
}
```

**异常流程**:

- **配置加载失败**: log.Fatalf 退出进程
- **数据库初始化失败**: log.Fatalf 退出进程
- **ConfigCenter初始化失败**: log.Fatalf 退出进程（配置是基础依赖）
- **MinIO初始化失败**: log.Fatalf 退出进程（日志存储是基础依赖）
- **协程池初始化失败**: log.Fatalf 退出进程（核查/演练需要协程池）
- **srv.ListenAndServe失败**: 日志记录错误，进程继续运行（端口冲突等）

- **优雅退出5秒超时**: 强制关闭HTTP服务，日志记录超时错误

- **HTTP服务关闭失败**: 日志记录错误，继续执行后续退出步骤

- **后台goroutine退出**: cancel()通知后goroutine应在1秒内退出

**边界情况**:

- **ConfigCenter.Init重复调用**: 启动时全量加载，不应被多次调用
- **DeployService/MonitorService.activeTasks**: sync.Map存储，StopAllTasks()遍历调用cancel; 每个activeTask有独立的cancel函数
- **协程池大小**: 10个worker（CONSTRAINTS未明确规定，建议10-20，满足核查/演练并发需求）
- **JWT_SECRET_KEY**: 启动时不校验（运行时校验），空值时JWTAuth中间件返回500错误
- **AES_SECRET_KEY**: 启动时不校验（运行时校验），空值时ConfigCenter加密/解密失败
- **优雅退出超时**: 5秒内HTTP服务必须关闭完; 超时则强制关闭

#### ants 协程池使用模式

**创建**: `ants.NewPool(10)` — 10个worker, 固定池大小, 不动态伸缩

**在 CheckService 和 DrillService 中使用 pool.Submit 的统一模式**:

```
// ★ 所有通过 pool.Submit 提交的任务必须遵循以下模式:

// 1. 任务函数必须是无参数闭包: pool.Submit 接收 func() (无参数无返回值)
// 2. 任务函数内部必须有 panic recovery:
//    ants.Pool 默认有 panic recovery, 但仅打印日志不更新DB状态
//    业务层需要在任务函数内自行 recover → 更新DB状态=FAILED+FailReason+WebSocket推送
// 3. 任务函数内必须使用 context 传递超时控制:
//    pool.Submit 不支持 context, 需在闭包内自行创建 context.WithTimeout

// ★ CheckService.ExecuteCheck 中使用 ants 的场景:
//    ExecuteCheck 串行执行三层规则, 不使用 ants
//    仅 SCRIPT 类型规则的多节点SSH执行使用 ants 并发:

func (s *CheckService) ExecuteCheck(ctx context.Context, flowID uint64, clusterName string) ([]*model.CheckRecord, error) {
    // ...串行执行三层规则(不并行)...
    
    for _, rule := range matchedRules {
        if rule.CheckType == "SCRIPT" {
            ips := parseIPsFromApplyItem(item.IPs)  // 从ResourceApplyItem.IPs获取IP列表
            
            // ★ 多节点并发SSH执行使用 ants:
            nodeResults := []NodeResult{}
            var mu sync.Mutex  // 保护 nodeResults 并发写入
            
            for _, ip := range ips {
                err := s.pool.Submit(func() {
                    // 任务函数: 单节点SSH执行
                    defer func() {
                        if r := recover(); r != nil {
                            // panic recovery: 记录节点失败
                            mu.Lock()
                            nodeResults = append(nodeResults, NodeResult{
                                IP:      ip,
                                Result:  "FAIL",
                                Error:   fmt.Sprintf("panic: %v", r),
                            })
                            mu.Unlock()
                        }
                    }()
                    
                    // SSH执行(60秒超时)
                    output, err := s.opsClient.ExecuteScript(ip, "shell", rule.CheckContent)
                    mu.Lock()
                    nodeResults = append(nodeResults, NodeResult{
                        IP:     ip,
                        Result: judgeResult(output, err, rule.JudgeRule),  // JudgeRule判定
                        Output: output,
                        Error:  err,
                    })
                    mu.Unlock()
                })
                if err != nil {
                    // pool.Submit失败(池满) → 记录节点失败
                    mu.Lock()
                    nodeResults = append(nodeResults, NodeResult{IP: ip, Result: "FAIL", Error: "pool submit failed"})
                    mu.Unlock()
                }
            }
            
            // ★ 等待所有节点任务完成: ants.Submit是非阻塞的
            // 使用 sync.WaitGroup 或等待足够时间确保所有任务完成:
            // 方案1: 在闭包内 wg.Add(1)/wg.Done() + 外部 wg.Wait()
            // 方案2: 等待固定时间(len(ips) * 60秒, 但总等待不超过60秒)
            // ★ 推荐方案1(WaitGroup):
            var wg sync.WaitGroup
            for _, ip := range ips {
                wg.Add(1)
                ipCopy := ip  // 闭包捕获变量需要复制
                err := s.pool.Submit(func() {
                    defer wg.Done()
                    defer func() { /* panic recovery */ }()
                    // SSH执行...
                    mu.Lock()
                    nodeResults = append(nodeResults, NodeResult{...})
                    mu.Unlock()
                })
                if err != nil {
                    wg.Done()  // Submit失败也要Done, 否则wg.Wait()永远阻塞
                    // 记录失败...
                }
            }
            wg.Wait()  // ★ 阻塞等待所有节点SSH执行完成
            
            // 汇总节点结果: 全部PASS→规则PASS, 任意FAIL→规则FAIL
        }
    }
}

// ★ DrillService.ExecuteDrill 中使用 ants 的场景:
//    ExecuteDrill 串行执行三层场景, 不使用 ants
//    仅 SHELL/ANSIBLE 步骤的多节点SSH执行使用 ants 并发(与CheckService模式完全一致)
```

**关键使用规则**:

| 规则 | 说明 | 否决方案 |
|------|------|---------|
| 三层规则/场景串行执行 | ExecuteCheck/ExecuteDrill 三层之间不并行, 层内也不并行 | 三层并行(违背需求) |
| 仅多节点SSH使用ants | SCRIPT多节点并发执行使用pool.Submit | 所有操作都用pool(过度) |
| 闭包内panic recovery | ants默认recovery只打日志不更新DB, 业务层自行recover | 依赖ants内置recovery(DB状态不更新) |
| sync.Mutex保护并发写入 | nodeResults在闭包内append, 需mutex保护 | channel收集(更复杂) |
| sync.WaitGroup等待完成 | wg.Wait()阻塞等待所有节点任务完成 | 不等待(结果不完整) |
| 闭包捕获变量需复制 | `ipCopy := ip` 防止for循环变量共享 | 不复制(所有闭包用最后一个ip) |
| pool.Submit失败要wg.Done | Submit失败时仍需Done, 否则WaitGroup永远阻塞 | 不Done(wg.Wait阻塞) |

- **环境变量优先级**: 环境变量 > config.yaml（生产环境推荐从环境变量注入密钥）
- **WebSocket不使用JWTAuth**: WebSocket连接通过独立路由 `/ws` 注册，不经过JWTAuth中间件

**依赖注入链路图**:

```
config.Load → cfg
    ↓
database.InitDB → db
    ↓               ↓
cache.NewLocalCache → localCache    lock.NewDistributedLock → distributedLock
    ↓               ↓
config.NewConfigCenter → configCenter    minio.NewMinioClient → minioClient
    ↓               ↓               ↓
adapter.NewCMDBClient → cmdbClient    adapter.NewDeployClient → deployClient    adapter.NewMonitorClient → monitorClient
    ↓               ↓               ↓
admin.NewCheckRuleService → checkRuleSvc    admin.NewDrillSceneService → drillSceneSvc    admin.NewDeployConfigService → deployConfigSvc
    ↓               ↓               ↓               ↓               ↓
resource.NewResourceService → resourceSvc    check.NewCheckService → checkSvc    deploy.NewDeployService → deploySvc    monitor.NewMonitorService → monitorSvc    drill.NewDrillService → drillSvc
    ↓               ↓               ↓               ↓               ↓               ↓
flow.NewFlowEngine → flowEngine    flow.NewWSHub → wsHub    flow.NewFlowWebSocket → flowWebSocket
    ↓               ↓               ↓
api/v1.RegisterRoutes → apiGroup    ws.GET("/ws") → flowWebSocket.HandleConnection
```

### Step 1.2: 统一响应格式与错误码

- 文件: `pkg/response/response.go`
  - struct: `Response` `{ Code int; Msg string; ReqID string; Data any; Timestamp int64 }`
  - 函数签名:
    ```go
    func Success(c *gin.Context, reqID string, data any)
    func Fail(c *gin.Context, reqID string, code int, msg string)
    func GenerateReqID() string  // 格式: 时间戳+6位随机数
    ```
- 文件: `pkg/errcode/errcode.go`
  - 定义错误码常量块:
    ```go
    // 系统级 1XXX
    ErrParamInvalid     = 1001  // 参数校验失败
    ErrInternalError    = 1002  // 内部错误
    ErrAPICallFailed    = 1003  // 接口调用失败
    
    // 业务级 2XXX
    ErrTemplateNameDup  = 2001  // 模板名称重复
    ErrCMDBAPIFailed    = 2002  // CMDB接口调用失败
    ErrResourceDelivering = 2003 // 资源交付中
    
    // 核查模块 22XX
    ErrCheckRuleNotFound = 2201
    ErrCheckFailed       = 2202
    
    // 部署模块 23XX
    ErrDeployFailed      = 2301
    ErrDeployRetrying    = 2302
    
    // 演练模块 24XX
    ErrDrillFailed       = 2401
    ErrDrillSceneNotFound = 2402
    
    // 监控模块 25XX
    ErrMonitorDeployFailed = 2501
    
    // 系统级补充 1XXX
    ErrSSHAuthFailed     = 1004  // SSH连接认证失败
    ErrConcurrentTrigger = 1005  // 操作正在进行中，不可重复触发
    ```
- 验收: `go build ./pkg/...` 编译成功

#### API Handler 统一模式示例

**所有 API handler 遵循同一模式**: 参数解析 → reqID生成 → Service调用 → Success/Fail响应

**示例: CreateFlow handler** (`api/v1/flow.go`):

```
func CreateFlow(c *gin.Context) {
    // 1. 生成请求ID
    reqID := response.GenerateReqID()
    
    // 2. 解析请求参数
    var req struct {
        FlowName string `json:"flow_name" binding:"required"`
        IDCName  string `json:"idc_name" binding:"required"`
        Creator  string `json:"creator"`        // 可选, 从JWT context取
    }
    if err := c.ShouldBindJSON(&req); err != nil {
        response.Fail(c, reqID, errcode.ErrParamInvalid, "参数校验失败: "+err.Error())
        return
    }
    
    // 3. 从JWT context补充operator(若未传则从context取)
    if req.Creator == "" {
        if userID, exists := c.Get("user_id"); exists {
            req.Creator = fmt.Sprintf("%v", userID)
        }
    }
    
    // 4. 调用Service方法
    flow, phases, err := flowEngine.CreateFlow(c.Request.Context(), req.FlowName, req.IDCName, req.Creator)
    if err != nil {
        response.Fail(c, reqID, errcode.ErrInternalError, err.Error())
        return
    }
    
    // 5. 构造响应数据
    data := map[string]any{
        "flow":   flow,
        "phases": phases,
    }
    
    // 6. 返回成功响应
    response.Success(c, reqID, data)
}
```

**Handler 模式规则**:

| 场景 | 参数来源 | binding方式 | Service调用 | 响应 |
|------|---------|-----------|------------|------|
| POST创建 | JSON Body | ShouldBindJSON | Service.Create | Success(data) |
| PUT更新 | JSON Body + URL :id | ShouldBindJSON + c.Param("id") | Service.Update | Success(data) |
| DELETE删除 | URL :id | c.Param("id") | Service.Delete | Success(nil) |
| GET列表 | URL Query | c.Query("scope")/c.Query("mw_type") | Service.List | Success(list) |
| GET单条 | URL :id | c.Param("id") | Service.Get | Success(data) |
| POST触发 | URL :id + JSON Body | c.Param("id") + ShouldBindJSON | Service.Trigger | Success(nil) |
| GET日志 | URL :id + Query | c.Param("id") + c.Query("start")/c.Query("count") | Service.GetLog | Success(lines) |

**统一规则**:

- 所有 handler 第一步生成 reqID: `response.GenerateReqID()`
- 所有 handler 使用 `c.Request.Context()` 传递 context 给 Service（支持超时控制）
- 所有 POST/PUT 使用 `ShouldBindJSON` 解析 Body（Gin自动校验 binding 标签）
- 所有 GET 使用 `c.Query()` 解析查询参数
- 所有 URL 参数使用 `c.Param()` 解析（如 :id）
- operator/user_id 从 `c.Get("user_id")` 获取（JWTAuth 注入）
- 错误响应使用 `response.Fail(c, reqID, errcode.XXX, msg)`
- 成功响应使用 `response.Success(c, reqID, data)`
- 不在 handler 中做业务逻辑（仅做参数解析和 Service 调用）

**路径参数 vs Query参数**:

- 路径参数(`:id`): 用于标识唯一资源（如 flow_id, rule_id, deploy_id）
- Query参数: 用于过滤/分页（如 mw_type, scope, start, count）

#### Handler Request 结构体定义

> 弱模型必须使用以下结构体进行 ShouldBindJSON 解析，不得直接用 Model 结构体（binding标签不同、字段可改范围不同）。

```go
// Flow模块
type CreateFlowReq struct {
    FlowName string `json:"flow_name" binding:"required"`
    IDCName  string `json:"idc_name" binding:"required"`
    Creator  string `json:"creator"`
}

// Resource模块
type InitApplyReq struct {
    RefIDC string `json:"ref_idc" binding:"required"`
}

type UpdateApplyItemReq struct {
    ClusterName string `json:"cluster_name"`
    MWType      string `json:"mw_type"`
    IDC         string `json:"idc"`
    Env         string `json:"env"`
    NodeCount   int    `json:"node_count"`
    CPU         string `json:"cpu"`
    Memory      string `json:"memory"`
    Disk        string `json:"disk"`
    // ★ 不可改字段不在req中: ApplyID, IPs, DeliverStatus, FailReason, Status
}

type AddApplyItemReq struct {
    ApplyID     uint64 `json:"apply_id" binding:"required"`
    ClusterName string `json:"cluster_name" binding:"required"`
    MWType      string `json:"mw_type" binding:"required"`
    IDC         string `json:"idc" binding:"required"`
    Env         string `json:"env"`
    NodeCount   int    `json:"node_count" binding:"required,min=1"`
    CPU         string `json:"cpu"`
    Memory      string `json:"memory"`
    Disk        string `json:"disk"`
}

// Monitor模块
type MonitorDeployReq struct {
    IPs []string `json:"ips" binding:"required,min=1"`
}

type MonitorConfigReq struct {
    ClusterNames []string `json:"clusters" binding:"required,min=1"`
}

// Drill模块
type DrillExecuteReq struct {
    SceneIDs []uint64 `json:"scene_ids"` // 可选, 空=全部场景
}
```

#### 缺失的响应 VO 结构体定义

> 以下VO仅在伪代码中出现但未给出Go结构体定义，弱模型必须在service层定义这些结构体。

```go
// CreateFlow响应
type CreateFlowVO struct {
    Flow   *model.DeliveryFlow `json:"flow"`
    Phases []*model.FlowPhase  `json:"phases"`
}

// ConfirmAndSubmit响应
type ConfirmSubmitResult struct {
    Total          int                 `json:"total"`
    Success        int                 `json:"success"`
    Failed         int                 `json:"failed"`
    FailedClusters []FailedClusterInfo `json:"failed_clusters"`
}

type FailedClusterInfo struct {
    ClusterName string `json:"cluster_name"`
    Reason      string `json:"reason"`
}

// QueryDeliverStatus响应
type DeliverStatusVO struct {
    ClusterName   string `json:"cluster_name"`
    MWType        string `json:"mw_type"`
    IDC           string `json:"idc"`
    DeliverStatus string `json:"deliver_status"` // NONE/PARTIAL/FULL/SUBMIT_FAILED
    ExpectedCount int    `json:"expected_count"`
    ActualCount   int    `json:"actual_count"`
}

// GetCheckedClusters响应
type ClusterDeployVO struct {
    ClusterName    string `json:"cluster_name"`
    MWType         string `json:"mw_type"`
    NodeCount      int    `json:"node_count"`
    IPs            string `json:"ips"`
    DeployConfigID uint64 `json:"deploy_config_id"` // 匹配的DeployConfig.ID, 0=无匹配
    Params         string `json:"params"`           // JSON: 部署参数, 无匹配则为 "{}"
}

// MonitorStatus合并响应
type MonitorStatusVO struct {
    Deploy *MonitorDeployVO `json:"deploy"`
    Config *MonitorConfigVO `json:"config"`
}
```

#### Handler Request 与 Service 方法参数映射

| Endpoint | Handler req结构 | Service方法参数 | 映射规则 |
|----------|---------------|---------------|---------|
| POST /flows | CreateFlowReq | CreateFlow(ctx, flowName, idcName, creator) | req.FlowName→flowName, req.IDCName→idcName, req.Creator→creator |
| POST /flows/:id/resource/init | InitApplyReq | InitApply(ctx, flowID, refIDC) | path:id→flowID, req.RefIDC→refIDC |
| POST /flows/:id/resource/submit | 无body | ConfirmAndSubmit(ctx, flowID) | path:id→flowID |
| POST /flows/:id/monitor/deploy | MonitorDeployReq | TriggerDeploy(ctx, flowID, ips) | path:id→flowID, req.IPs→ips |
| POST /flows/:id/monitor/config | MonitorConfigReq | TriggerConfig(ctx, flowID, clusterNames) | path:id→flowID, req.ClusterNames→clusterNames |
| POST /flows/:id/drill/execute | DrillExecuteReq | ExecuteDrill(ctx, flowID, clusterName, sceneIDs) | path:id→flowID, query:cluster→clusterName, req.SceneIDs→sceneIDs |

#### GET Endpoint Query参数完整定义

| Endpoint | Query参数 | 类型 | 说明 |
|----------|---------|------|------|
| GET /check-rules | scope, mw_type | string, string | 过滤: scope=COMMON/MW_TYPE/CLUSTER, mw_type=中间件类型 |
| GET /drill-scenes | scope, mw_type | string, string | 同check-rules |
| GET /deploy-configs | mw_type | string | 仅按中间件类型筛选 |
| GET /check-rules/match | cluster, mw_type | string, string | 三层匹配输入 |
| GET /drill-scenes/match | cluster, mw_type | string, string | 三层匹配输入 |
| GET /flows/:id/deploy/clusters | mw_type | string | 按中间件类型筛选可部署集群 |
| POST /flows/:id/deploy/trigger | cluster | string | 集群名称(query参数) |
| GET /flows/:id/deploy/detail | cluster | string | 集群名称(query参数) |
| GET /deploy/:id/log | stage, start, count | string, int, int | stage=VALIDATE/DEPLOY/VERIFY, start=行号(默认0), count=行数(默认100) |
| POST /flows/:id/check/execute | cluster | string | 集群名称(query参数,POST) |
| GET /flows/:id/check/detail | cluster | string | 集群名称(query参数) |
| GET /check/records/:id/log | start, count | int, int | start=行号, count=行数(默认100) |
| GET /flows/:id/monitor/status | 无 | — | 返回MonitorStatusVO(deploy+config合并) |
| GET /flows/:id/monitor/log | start, count | int, int | 同上 |
| GET /flows/:id/drill/clusters | mw_type | string | 按中间件类型筛选 |
| POST /flows/:id/drill/execute | cluster | string | 集群名称(query参数,POST) |
| GET /flows/:id/drill/detail | cluster | string | 集群名称(query参数) |
| GET /drill/records/:id/log | start, count | int, int | 同上 |
| GET /flows/:id/resource/items | 无 | — | 查询资源申请列表 |

### Step 1.3: 配置中心模块

- 文件: `config.yaml` — 配置模板，包含:
  ```yaml
  server:
    port: 8080
    mode: debug  # debug/release
  
  database:
    host: localhost
    port: 3306
    user: fast_mw
    password: ""
    dbname: fast_mw
    max_open_conns: 100
    max_idle_conns: 10
  
  minio:
    endpoint: localhost:9000
    access_key: ""
    secret_key: ""
    use_ssl: false
  
  aes_secret_key: ""  # AES-256密钥，生产环境从环境变量注入
  
  external:
    cmdb:
      base_url: ""
      timeout: 30
      retry_count: 3
      retry_interval: 5
    deploy_service:
      base_url: ""
      timeout: 30
    monitor_service:
      base_url: ""
      timeout: 30
    ops_service:
      base_url: ""
      timeout: 30
  ```
- 文件: `internal/config/config.go`
  - struct: `Config` — 映射 config.yaml 全部字段
  - 函数签名:
    ```go
    func Load(path string) (*Config, error)  // 读取yaml文件
    ```
- 文件: `internal/config/center.go`
  - struct: `ConfigCenter` `{ db *gorm.DB; store *sync.Map }`
  - 函数签名:
    ```go
    func NewConfigCenter(db *gorm.DB) *ConfigCenter
    func (cc *ConfigCenter) Init() error                    // 启动时全量加载sys_config表
    func (cc *ConfigCenter) Get(key, group string) (string, error) // 读取内存缓存(敏感配置返回****)
    func (cc *ConfigCenter) GetRealValue(key, group string) (string, error) // 读取真实解密值(内部模块使用,不通过API暴露)
    func (cc *ConfigCenter) Set(key, group, value, operator string) error // 写入MySQL+刷新内存+记录历史
    func (cc *ConfigCenter) StartHotReload(ctx context.Context)         // 常驻goroutine, 每5秒轮询版本号
    ```
  - 内部类型: `ConfigEntry` `{ Value string; Version int; IsSensitive bool }` — sync.Map 存储的值类型
  - sync.Map key格式: `{group}:{key}` (例: `"ops:ssh_user"`, `"ops:ssh_private_key"`)

#### AES-256-GCM 加密/解密实现细节

**加密方式**: AES-256-GCM (Galois/Counter Mode), 提供加密+认证(防篡改), 比 CBC 更安全且无需单独填充。

**密钥来源**: `os.Getenv("AES_SECRET_KEY")`, 必须为32字节(256位)的字符串。生产环境从环境变量注入, 不写入config.yaml。

**密文格式**: `base64(nonce[12字节] + ciphertext + tag[16字节])`
- nonce(IV): 每次加密随机生成12字节, 确保相同明文每次加密结果不同
- nonce嵌入密文前缀: 解密时从密文中截取前12字节作为nonce, 剩余部分为 ciphertext+tag
- base64编码: DB存储为可打印字符串, 避免二进制存储问题

**aesEncrypt 详细逻辑**:

```
输入: plaintext string

1. 获取密钥:
   key := os.Getenv("AES_SECRET_KEY")
   若 key == "" → 返回 ("", error("AES密钥未配置"))
   若 len(key) != 32 → 返回 ("", error("AES密钥长度必须为32字节"))

2. 创建 cipher block:
   block, err := aes.NewCipher([]byte(key))
   若 err != nil → 返回 ("", error("AES密钥非法: %v", err))

3. 创建 GCM mode:
   gcm, err := cipher.NewGCM(block)
   若 err != nil → 返回 ("", error("创建GCM失败: %v", err))

4. 生成随机 nonce:
   nonce := make([]byte, gcm.NonceSize())  // 12字节
   _, err = io.ReadFull(rand.Reader, nonce)
   若 err != nil → 返回 ("", error("生成nonce失败: %v", err))

5. 加密:
   // gcm.Seal 在nonce后追加ciphertext+tag
   ciphertext := gcm.Seal(nonce, nonce, []byte(plaintext), nil)
   // ciphertext格式: [nonce(12字节)] + [加密数据] + [tag(16字节)]

6. Base64编码:
   encoded := base64.StdEncoding.EncodeToString(ciphertext)

7. 返回 (encoded, nil)
```

**aesDecrypt 详细逻辑**:

```
输入: ciphertextBase64 string (base64编码的密文)

1. 获取密钥:
   key := os.Getenv("AES_SECRET_KEY")
   若 key == "" → 返回 ("", error("AES密钥未配置"))
   若 len(key) != 32 → 返回 ("", error("AES密钥长度必须为32字节"))

2. Base64解码:
   ciphertext, err := base64.StdEncoding.DecodeString(ciphertextBase64)
   若 err != nil → 返回 ("", error("密文Base64解码失败: %v", err))

3. 创建 cipher block + GCM:
   block, _ := aes.NewCipher([]byte(key))
   gcm, _ := cipher.NewGCM(block)

4. 验证密文长度:
   nonceSize := gcm.NonceSize()  // 12字节
   若 len(ciphertext) < nonceSize → 返回 ("", error("密文长度不足, 无法提取nonce"))

5. 提取 nonce 和 ciphertext+tag:
   nonce := ciphertext[:nonceSize]        // 前12字节为nonce
   actualCiphertext := ciphertext[nonceSize:]  // 剩余部分为加密数据+tag

6. 解密:
   plaintext, err := gcm.Open(nil, nonce, actualCiphertext, nil)
   若 err != nil → 返回 ("", error("AES-GCM解密失败(密文可能被篡改或密钥不匹配): %v", err))
   
   // GCM的Open方法会同时验证tag(认证), 确保密文未被篡改

7. 返回 (string(plaintext), nil)
```

**异常流程**:

- **AES_SECRET_KEY为空**: 加密/解密均返回错误, BeforeCreate Hook阻断创建, BeforeUpdate Hook阻断更新
- **密钥长度不等于32**: AES-256要求32字节密钥, 非标准长度返回错误
- **密文Base64解码失败**: 非法输入(可能不是加密值而是原始明文), 解密返回错误 → BeforeUpdate判断为新明文需加密
- **GCM解密失败(tag校验失败)**: 密文被篡改或密钥不匹配, 返回错误
- **nonce生成失败(rand.Reader)**: 极罕见, 返回错误

**边界情况**:

- **相同明文每次加密结果不同**: nonce随机生成 → 密文不同 → 安全性保证(防重放/防模式分析)
- **密钥更换后的旧密文**: 新密钥无法解密旧密文 → AfterFind解密失败 → 保留加密值 → GetRealValue返回错误 → 需手动用旧密钥解密后重新Set写入
- **非敏感配置(IsSensitive=false)**: 不调用aesEncrypt/aesDecrypt, ConfigValue为明文直存
- **空字符串加密**: plaintext="" → 加密后密文仍有效(空明文的合法加密), 解密还原为""
- **DB中非敏感配置被误标为敏感**: AfterFind尝试解密明文 → aesDecrypt失败 → log.Printf记录 → 保留原值 → 需管理员修正IsSensitive标记

#### ConfigCenter.Init 详细逻辑流程

**输入**: 无（启动时调用）

**正常流程**:

```
1. 查询全部配置: SELECT * FROM sys_config WHERE status='ENABLE'
2. 遍历每条记录:
   a. 若 IsSensitive=true:
      - ConfigValue 已在 BeforeUpdate Hook 中加密写入DB
      - Init 需要解密才能存入 sync.Map 供 GetRealValue() 使用
      - 解密: AES-256-CBC 解密 ConfigValue (密钥从 os.Getenv("AES_SECRET_KEY"))
      - 解密失败 → log.Printf("解密失败: key=%s, group=%s"), 仍存加密值到Map(GetRealValue()时返回错误)
   b. 若 IsSensitive=false:
      - ConfigValue 为明文，直接存入
   c. 存入 sync.Map:
      - key格式: "{configGroup}:{configKey}" (例: "ops:ssh_user", "ops:ssh_private_key")
      - Store(key, &ConfigEntry{Value: 解密后明文/原始明文, Version: record.Version, IsSensitive: record.IsSensitive})
3. log.Printf("[ConfigCenter] 初始化完成, 加载配置数=%d", len)
4. 返回 nil
```

**异常流程**:

- **AES_SECRET_KEY 环境变量为空**: 解密时失败 → log.Printf("AES密钥未配置"), 存加密值到Map，GetRealValue()时返回 ErrInternalError "敏感配置解密失败"
- **SELECT 查询失败**: 返回错误，Init 失败 → main.go 启动失败（配置是基础依赖）
- **单条记录解密失败**: 不中断，log.Printf 记录，存加密值到Map，该配置 GetRealValue()时返回错误

**边界情况**:

- **重复调用 Init**: 覆盖 sync.Map 全部内容（支持重启后重新加载）
- **Get()方法参数 order 为 (key, group)**，但 Map 内部 key 为 `{group}:{key}`，Get()内部拼接为 `fmt.Sprintf("%s:%s", group, key)` 查询

#### ConfigCenter.Get 详细逻辑流程

**输入**: `key string`, `group string`

**正常流程**:

```
1. 从 sync.Map 读取: mapKey = fmt.Sprintf("%s:%s", group, key)
   entry, ok := store.Load(mapKey)
   若 !ok → 返回 ("", error("配置项不存在: group=%s, key=%s", group, key))
2. entry 为 *ConfigEntry 类型:
   若 entry.IsSensitive=true → 返回 "****"（脱敏，不暴露明文）
   若 entry.IsSensitive=false → 返回 entry.Value（明文值）
3. 返回 (value, nil)
```

**异常流程**:

- **配置项不存在**: 返回 ("", error)，调用方需自行判断是否是必需配置
- **敏感配置**: 只返回 `****`，不返回真实值（防止通过 API 泄露）

#### ConfigCenter.GetRealValue 详细逻辑流程

**输入**: `key string`, `group string`

**正常流程**:

```
1. 从 sync.Map 读取: mapKey = fmt.Sprintf("%s:%s", group, key)
   entry, ok := store.Load(mapKey)
   若 !ok → 返回 ("", ErrParamInvalid "配置项不存在")
2. 返回 entry.Value（不论 IsSensitive，都返回真实解密后的明文值）
3. 此方法仅供内部模块使用（OpsClient 获取 SSH 凭据等），不通过 API 暴露
```

#### ConfigCenter.Set 详细逻辑流程

**输入**: `key string`, `group string`, `value string`, `operator string`

**正常流程**:

```
1. 查询 DB: SELECT * FROM sys_config WHERE config_key=? AND config_group=? AND status='ENABLE'
   若不存在 → INSERT 新记录（version=1）
   若存在 → UPDATE 记录
2. 写入 DB 时:
   - BeforeUpdate Hook 自动处理加密:
     若 IsSensitive=true → Hook 中加密 ConfigValue 后写入
     若 IsSensitive=false → Hook 中不加密，直接写入
   - Version = 旧版本 + 1
   - Operator = 参数 operator
3. 写入 SysConfigHistory:
   - ConfigID = 新记录.ID
   - OldValue = 旧记录.ConfigValue（加密前的原始值，从 sync.Map 取）
   - NewValue = 参数 value（用户输入的原始值）
   - Version = 新记录.Version
   - Operator = 参数 operator
4. 更新 sync.Map:
   mapKey = fmt.Sprintf("%s:%s", group, key)
   若 IsSensitive=true: Map.Value = value（用户输入的明文，Map存解密后明文）
   若 IsSensitive=false: Map.Value = value（明文）
   entry.Version = 新版本号
   store.Store(mapKey, entry)
5. 返回 nil
```

**异常流程**:

- **DB 写入失败**: 返回错误，sync.Map 不更新（保持旧值）
- **AES_SECRET_KEY 为空时设置敏感配置**: BeforeUpdate Hook 中加密失败 → 返回 ErrInternalError "AES密钥未配置，无法设置敏感配置"
- **SysConfigHistory 写入失败**: log.Printf 记录，不影响主流程（历史记录是辅助功能）

**边界情况**:

- **首次创建配置项**: INSERT 新记录，version=1，OldValue=""（无旧值）
- **Set 和 StartHotReload 并发**: Set 先更新 sync.Map，5秒内热更新 goroutine 会从 DB 看到新版本号，但 sync.Map 版本已更新，热更新不会重复拉取

#### ConfigCenter.StartHotReload 详细逻辑流程

**输入**: `ctx context.Context`（从 main.go 传入，用于优雅退出）

**正常流程**:

```
goroutine 入口:
go func() {
    defer log.Printf("[ConfigCenter] 热更新goroutine退出")
    
    ticker := time.NewTicker(5 * time.Second)
    defer ticker.Stop()
    
    for {
        select {
        case <-ctx.Done():
            return  // 优雅退出
        case <-ticker.C:
        }
        
        // 1. 查询每组最大版本号
        rows, err := db.Raw("SELECT config_group, MAX(version) as max_version FROM sys_config WHERE status='ENABLE' GROUP BY config_group").Rows()
        if err != nil {
            log.Printf("[ConfigCenter] 热更新查询失败: %v", err)
            continue  // 跳过本次，5秒后重试
        }
        
        // 2. 比对版本号，收集需要刷新的组
        changedGroups := []string{}
        for rows.Next() {
            var group string
            var maxVersion int
            rows.Scan(&group, &maxVersion)
            
            // 在 sync.Map 中查找该组的所有配置项
            // 遍历 Map 中 key 以 "{group}:" 开头的所有 entry
            store.Range(func(key, value any) bool {
                entry := value.(*ConfigEntry)
                mapKey := key.(string)
                parts := strings.SplitN(mapKey, ":", 2)
                if parts[0] == group && entry.Version < maxVersion {
                    changedGroups = append(changedGroups, group)
                    return false  // 找到一个版本落后的，该组需要刷新，停止遍历
                }
                return true  // 继续遍历
            })
        }
        rows.Close()
        
        // 3. 对每个需要刷新的组，增量拉取全组配置并覆盖刷新
        for _, group := range changedGroups {
            records := []model.SysConfig{}
            db.Where("config_group = ? AND status = 'ENABLE'", group).Find(&records)
            
            for _, record := range records {
                mapKey := fmt.Sprintf("%s:%s", record.ConfigGroup, record.ConfigKey)
                
                var value string
                if record.IsSensitive {
                    decrypted, err := aesDecrypt(record.ConfigValue, os.Getenv("AES_SECRET_KEY"))
                    if err != nil {
                        log.Printf("[ConfigCenter] 热更新解密失败: key=%s, group=%s", record.ConfigKey, record.ConfigGroup)
                        value = record.ConfigValue  // 存加密值，GetRealValue()会返回错误
                    } else {
                        value = decrypted
                    }
                } else {
                    value = record.ConfigValue
                }
                
                store.Store(mapKey, &ConfigEntry{
                    Value:       value,
                    Version:     record.Version,
                    IsSensitive: record.IsSensitive,
                })
            }
            
            // 4. 清理已删除的配置项: DB中DISABLE的配置 → 从Map中删除
            // 查询该组所有ENABLE的key，比对Map中已有的key
            activeKeys := map[string]bool{}
            for _, record := range records {
                activeKeys[fmt.Sprintf("%s:%s", record.ConfigGroup, record.ConfigKey)] = true
            }
            store.Range(func(key, value any) bool {
                mapKey := key.(string)
                parts := strings.SplitN(mapKey, ":", 2)
                if parts[0] == group && !activeKeys[mapKey] {
                    store.Delete(mapKey)  // DB中已不存在或已DISABLE → 从Map删除
                }
                return true
            })
            
            log.Printf("[ConfigCenter] 配置组 %s 已热更新", group)
        }
    }
}()
```

**异常流程**:

- **SQL 查询失败**: log.Printf 记录，跳过本次，5秒后重试（不影响现有 sync.Map 值）
- **解密失败**: log.Printf 记录该条，存加密值到 Map（该配置 GetRealValue() 返回错误）
- **ctx.Done()**: 优雅退出 goroutine

**边界情况**:

- **无版本变化**: changedGroups 为空，不执行增量拉取，节省 DB 查询
- **新增配置项**: 该组 version 变化 → 拉取全组 → 新项存入 Map
- **删除配置项（Status=DISABLE）**: 热更新后比对 Map 中 key → 不存在于 DB 的 → 从 Map 中 Delete

- 验收: `go test ./internal/config/... -run TestConfigCenter_Init` 通过

### Step 1.4: 数据库连接与缓存组件

- 文件: `internal/database/mysql.go`
  - 函数签名:
    ```go
    func InitDB(cfg *config.DatabaseConfig) (*gorm.DB, error)  // 连接MySQL, 配置连接池
    ```
- 文件: `internal/cache/local.go`
  - struct: `LocalCache` `{ cache *go_cache.Cache }`
  - 函数签名:
    ```go
    func NewLocalCache(defaultTTL, cleanupInterval time.Duration) *LocalCache
    func (lc *LocalCache) Get(key string) (any, bool)
    func (lc *LocalCache) Set(key string, value any, ttl time.Duration)
    func (lc *LocalCache) Delete(key string)
    func (lc *LocalCache) Flush()  // 清空全部缓存
    ```
- 文件: `internal/lock/distributed.go`
  - struct: `DistributedLock` `{ db *gorm.DB }`
  - 函数签名:
    ```go
    func NewDistributedLock(db *gorm.DB) *DistributedLock
    func (dl *DistributedLock) Acquire(lockKey, owner string, expireSeconds int) (bool, error)  // INSERT distributed_lock表
    func (dl *DistributedLock) Release(lockKey, owner string) error  // DELETE WHERE lock_key=? AND lock_owner=?
    func (dl *DistributedLock) StartCleanup(ctx context.Context)  // 每10秒清理过期锁
    ```

#### DistributedLock.Acquire 详细逻辑流程

**输入**: `lockKey string`, `owner string`, `expireSeconds int`

**正常流程**:

```
1. 尝试 INSERT:
   result := db.Create(&DistributedLock{
       LockKey:    lockKey,
       LockOwner:  owner,       // owner由调用方生成: uuid.NewString() 或 fmt.Sprintf("%d-%s", flowID, clusterName)
       LockTime:   time.Now(),
       ExpireTime: time.Now().Add(time.Duration(expireSeconds) * time.Second),
   })
   
   若 result.Error == nil → INSERT 成功 → 锁获取成功 → 返回 (true, nil)
   
   若 result.Error != nil:
     // 判断是"已存在锁"还是"其他DB错误"
     if strings.Contains(result.Error.Error(), "Duplicate entry") || strings.Contains(result.Error.Error(), "1062"):
       // lock_key 是 primaryKey，已存在 → 锁已被占用
       // 查询现有锁: SELECT * FROM distributed_lock WHERE lock_key=?
       existingLock := DistributedLock{}
       db.Where("lock_key = ?", lockKey).First(&existingLock)
       
       if existingLock.ExpireTime.Before(time.Now()):
         // 锁已过期 → 删除旧锁后重新获取
         db.Where("lock_key = ?", lockKey).Delete(&DistributedLock{})
         // 再次尝试 INSERT（同上述逻辑）
         retryResult := db.Create(&DistributedLock{...同上参数...})
         若 retryResult.Error == nil → 返回 (true, nil)
         若 retryResult.Error != nil → 返回 (false, nil)  // 极端并发: 另一个请求刚获取
       else:
         // 锁未过期且被他人持有 → 获取失败
         返回 (false, nil)
     else:
       // 其他DB错误（连接失败等）
       返回 (false, result.Error)
```

**异常流程**:

- **DB 连接失败**: 返回 (false, error)，调用方应处理获取锁失败的情况
- **锁已过期但仍存在**: 删除旧锁后重新获取（过期锁可被覆盖）
- **极端并发**: 删除旧锁后第二个 INSERT 仍失败 → 返回 (false, nil)

**边界情况**:

- **owner 参数**: 由调用方自行生成，通常为 `uuid.NewString()` 或有业务含义的字符串（如 `"deploy-flow5-redis-cluster-prod-a"`），用于 Release 时验证是本人释放
- **expireSeconds 与业务对齐**: deploy/drill 使用 7200秒(2小时)与最长轮询对齐；check 使用 300秒(5分钟)

#### DistributedLock.Release 详细逻辑流程

**输入**: `lockKey string`, `owner string`

**正常流程**:

```
1. DELETE FROM distributed_lock WHERE lock_key=? AND lock_owner=?
   result := db.Where("lock_key = ? AND lock_owner = ?", lockKey, owner).Delete(&DistributedLock{})
   
   若 result.RowsAffected == 0 → 锁不存在或owner不匹配 → 返回 error("锁不存在或非持有者")
   若 result.RowsAffected > 0 → 删除成功 → 返回 nil
```

**异常流程**:

- **owner 不匹配**: 不删除（防止误释放他人锁），返回错误
- **锁已不存在**: 可能已被过期清理删除，返回错误（调用方应容忍此情况：锁目的已完成）
- **DB 错误**: 返回 error

**边界情况**:

- **锁已被 StartCleanup 自动清理**: DELETE 返回 0 rowsAffected → 调用方应忽略此错误（任务完成后锁过期被清理是正常行为）
- **Release 建议做法**: 调用方在 defer 中释放锁，容忍 Release 返回的错误

#### DistributedLock.StartCleanup 详细逻辑流程

**输入**: `ctx context.Context`

**正常流程**:

```
goroutine 入口:
go func() {
    defer log.Printf("[DistributedLock] 清理goroutine退出")
    
    ticker := time.NewTicker(10 * time.Second)
    defer ticker.Stop()
    
    for {
        select {
        case <-ctx.Done():
            return  // 优雅退出
        case <-ticker.C:
        }
        
        // DELETE FROM distributed_lock WHERE expire_time < NOW()
        result := db.Where("expire_time < ?", time.Now()).Delete(&DistributedLock{})
        if result.Error != nil {
            log.Printf("[DistributedLock] 清理失败: %v", result.Error)
        } else if result.RowsAffected > 0 {
            log.Printf("[DistributedLock] 清理过期锁: %d条", result.RowsAffected)
        }
    }
}()
```

- 验收: `go test ./internal/database/... ./internal/cache/... ./internal/lock/...` 通过

### Step 1.5: Gin 中间件与 MinIO 客户端

- 文件: `internal/middleware/auth.go`
  - 函数签名: `func JWTAuth() gin.HandlerFunc`  — 解析JWT, 校验签名, 注入用户信息到context
- 文件: `internal/middleware/audit.go`
  - 函数签名: `func AuditLog(db *gorm.DB) gin.HandlerFunc` — 拦截请求, 记录操作人/时间/IP/接口/参数/结果到audit_log表
- 文件: `internal/middleware/ratelimit.go`
  - 函数签名: `func RateLimit(rps int) gin.HandlerFunc` — 令牌桶限流, 单节点内存计数

#### AuditLog() 详细逻辑流程

**输入**: `db *gorm.DB`（Gin 中间件工厂函数）

**正常流程**:

```
func AuditLog(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        // 1. 记录请求开始时间
        startTime := time.Now()
        
        // 2. 提取请求信息（在 handler 执行前）
        operator := ""
        // 从 JWTAuth 中间件注入的 context 中获取用户信息
        // JWTAuth 设置: c.Set("user_id", claims.UserID) 和 c.Set("user_role", claims.Role)
        if userID, exists := c.Get("user_id"); exists {
            operator = fmt.Sprintf("%v", userID)
        }
        // 若无 JWT 信息（如未认证接口）→ operator = "anonymous"
        
        operateIP := c.ClientIP()  // Gin 自动处理 X-Forwarded-For / X-Real-IP
        
        apiPath := c.Request.URL.Path
        method := c.Request.Method
        
        // 3. 记录请求参数（限制大小，防止大body写入DB）
        params := ""
        if method == "GET" {
            params = c.Request.URL.RawQuery
            if len(params) > 2000 {
                params = params[:2000] + "...(truncated)"
            }
        } else {
            // POST/PUT/DELETE: 从 c.Request.Body 读取
            // 注意: Body 是 ReadCloser，读完后需恢复给后续 handler
            bodyBytes, _ := io.ReadAll(c.Request.Body)
            if len(bodyBytes) > 2000 {
                params = string(bodyBytes[:2000]) + "...(truncated)"
            } else {
                params = string(bodyBytes)
            }
            // 恢复 Body 供后续 handler 读取
            c.Request.Body = io.NopCloser(bytes.NewBuffer(bodyBytes))
        }
        
        // 4. 执行后续 handler
        c.Next()
        
        // 5. 记录响应结果（handler 执行后）
        result := "SUCCESS"
        if c.Writer.Status() >= 400 {
            result = "FAIL"
        }
        
        // 6. 写入 audit_log 表（TableName() 动态返回按月分表名）
        audit := &model.AuditLog{
            Operator:    operator,
            OperateTime: startTime,
            OperateIP:   operateIP,
            APIPath:     apiPath,
            Method:      method,
            Params:      params,
            Result:      result,
        }
        
        if err := db.Create(audit).Error; err != nil {
            log.Printf("[AuditLog] 写入审计日志失败: %v", err)
            // 写入失败不影响业务流程（审计是辅助功能）
        }
    }
}
```

**异常流程**:

- **读取 Body 失败**: params=""，仍记录审计日志
- **DB 写入失败**: log.Printf 记录，不影响业务请求（审计日志写入失败不应阻塞业务）

**边界情况**:

- **Body 恢复**: 必须用 `io.NopCloser(bytes.NewBuffer(bodyBytes))` 恢复 Body，否则后续 handler 读不到 Body
- **参数截断**: 2000 字符截断，防止大 JSON body 写入 DB 的 text 字段占用过多空间
- **未认证接口**: operator="anonymous"，仍记录审计日志（IP、路径等信息仍有价值）
- **WebSocket 接口**: 不记录 WebSocket 连接为审计日志（长连接不适合 INSERT 每次消息）

#### AuditLog.TableName() 动态分表逻辑

```
func (a AuditLog) TableName() string {
    // 根据 OperateTime 的年月动态返回表名
    // 若 OperateTime 为零值（创建前未设置）→ 使用 time.Now()
    t := a.OperateTime
    if t.IsZero() {
        t = time.Now()
    }
    return fmt.Sprintf("audit_log_%s", t.Format("200601"))
    // 例: 2024年6月 → "audit_log_202406"
}
```

#### JWTAuth() 详细逻辑流程

**输入**: 无（Gin 中间件工厂函数）

**正常流程**:

```
func JWTAuth() gin.HandlerFunc {
    return func(c *gin.Context) {
        // 1. 从 Authorization Header 提取 token
        authHeader := c.GetHeader("Authorization")
        if authHeader == "" {
            c.AbortWithStatusJSON(401, response.FailBody("", errcode.ErrParamInvalid, "缺少Authorization头"))
            return
        }
        
        // 2. 解析 Bearer token 格式
        // Authorization: Bearer <token>
        parts := strings.SplitN(authHeader, 2)
        if len(parts) != 2 || parts[0] != "Bearer" {
            c.AbortWithStatusJSON(401, response.FailBody("", errcode.ErrParamInvalid, "Authorization格式非法"))
            return
        }
        tokenString := parts[1]
        
        // 3. 解析并校验 JWT token
        // Claims 结构: { user_id: uint64, role: string, exp: int64 }
        // 密钥从 os.Getenv("JWT_SECRET_KEY") 获取
        // 算法: HS256
        secretKey := os.Getenv("JWT_SECRET_KEY")
        if secretKey == "" {
            c.AbortWithStatusJSON(500, response.FailBody("", errcode.ErrInternalError, "JWT密钥未配置"))
            return
        }
        
        claims := &jwt.RegisteredClaims{}
        // 自定义 claims 结构:
        type CustomClaims struct {
            UserID   uint64 `json:"user_id"`
            Role     string `json:"role"`
            jwt.RegisteredClaims
        }
        
        parsedClaims, err := jwt.ParseWithClaims(tokenString, &CustomClaims{}, func(token *jwt.Token) (any, error) {
            return []byte(secretKey), nil
        })
        
        if err != nil {
            if errors.Is(err, jwt.ErrTokenExpired) {
                c.AbortWithStatusJSON(401, response.FailBody("", errcode.ErrParamInvalid, "token已过期"))
                return
            }
            c.AbortWithStatusJSON(401, response.FailBody("", errcode.ErrParamInvalid, "token无效: "+err.Error()))
            return
        }
        
        // 4. 校验 claims 有效性
        customClaims := parsedClaims.(*CustomClaims)
        if customClaims.UserID == 0 {
            c.AbortWithStatusJSON(401, response.FailBody("", errcode.ErrParamInvalid, "token缺少user_id"))
            return
        }
        
        // 5. 注入用户信息到 Gin context
        // 后续中间件(AuditLog)和业务handler通过 c.Get("user_id")/c.Get("user_role") 获取
        c.Set("user_id", customClaims.UserID)
        c.Set("user_role", customClaims.Role)
        
        // 6. 继续执行后续 handler
        c.Next()
    }
}
```

**异常流程**:

- **Authorization Header 为空**: 返回 401 + ErrParamInvalid "缺少Authorization头"
- **Authorization 格式错误**（非 Bearer 格式）: 返回 401 + ErrParamInvalid "Authorization格式非法"
- **JWT_SECRET_KEY 未配置**: 返回 500 + ErrInternalError "JWT密钥未配置"
- **token 过期**: 返回 401 + ErrParamInvalid "token已过期"
- **token 签名校验失败**: 返回 401 + ErrParamInvalid "token无效"
- **claims 缺少 user_id**: 返回 401 + ErrParamInvalid "token缺少user_id"

- **claims.Role 为空**: 不拒绝，允许空角色（某些接口可能不需要角色校验）

**边界情况**:

- **JWT_SECRET_KEY 环境变量**: 启动时检查，缺失则 log.Printf 警告但不阻塞启动（允许运维手动设置）
- **token 过期时间**: 8小时（CONSTRAINTS: JWT无状态8小时）
- **context key 命名**: 固定使用 `user_id` 和 `user_role`，AuditLog 中间件依赖这两个 key
- **未认证接口**: JWTAuth 中间件仅应用于需要认证的路由分组； 未认证接口（如健康检查）不使用此中间件
- **WebSocket 接口**: JWTAuth 不应用于 WebSocket 路由（WebSocket 使用独立认证机制）

#### RateLimit() 详细逻辑流程

**输入**: `rps int`（每秒允许请求数）

**正常流程**:

```
func RateLimit(rps int) gin.HandlerFunc {
    // 1. 创建令牌桶
    // burst=rps: 允许瞬间并发=rps（令牌桶容量=每秒速率，保证首次请求不排队）
    limiter := rate.NewLimiter(rate.Limit(rps), rps)
    
    return func(c *gin.Context) {
        // 2. 检查是否允许请求: limiter.Allow()返回true=有令牌=放行
        if limiter.Allow() {
            // 有令牌→放行请求
            c.Next()
            return
        }
        
        // 3. 无令牌→拒绝请求: 返回 429 Too Many Requests
        c.AbortWithStatusJSON(429, response.FailBody("", errcode.ErrInternalError, "请求过多，请稍后重试"))
    }
}
```

**异常流程**:

- **rps 为 0 或负数**: 创建 Limiter 时 panic 或返回错误； 应在中间件初始化时校验 rps > 0
- **limiter.Allow() 在并发高时可能返回 false**: 正确行为，返回 429

**边界情况**:

- **令牌桶模式**: 使用 `Allow()` 方法（非阻塞），不使用 `Wait()`（阻塞等待令牌）
- **burst=rps**: 令牌桶容量等于 rps，允许瞬间并发但不积累
- **单节点限流**: 这是进程内限流，不跨节点共享（分布式环境需用 DistributedLock 或 Redis 限流）
- **路由分组**: RateLimit 应应用于需要限流的 API 路由分组（如 /api/v1/），WebSocket 路由不使用

- 文件: `pkg/minio/client.go`
  - struct: `MinioClient` `{ client *minio.Client }`
  - 函数签名:
    ```go
    func NewMinioClient(cfg *config.MinioConfig) (*MinioClient, error)
    func (mc *MinioClient) Upload(bucket, objectName string, data []byte) error
    func (mc *MinioClient) Download(bucket, objectName string) ([]byte, error)
    func (mc *MinioClient) GetSignedURL(bucket, objectName string, expiry time.Duration) (string, error)  // 生成1小时临时链接
    func (mc *MinioClient) ReadLines(bucket, objectName string, startLine, lineCount int) ([]string, error)  // 分页按行读取
    ```

#### MinioClient.ReadLines 详细逻辑流程

**输入**: `bucket string`, `objectName string`, `startLine int`, `lineCount int`

**正常流程**:

```
1. 从 MinIO 下载完整对象到内存:
   obj, err := client.GetObject(bucket, objectName, minio.GetObjectOptions{})
   if err != nil → 返回 ([]string{}, ErrInternalError "MinIO获取文件失败")
   
   defer obj.Close()
   
   data, err := io.ReadAll(obj)
   if err != nil → 返回 ([]string{}, ErrInternalError "读取文件内容失败")

2. 按行分割:
   lines := strings.Split(string(data), "\n")
   // 清理: 移除最后一个空元素（文件末尾换行符产生的空字符串）
   if len(lines) > 0 && lines[len(lines)-1] == "" {
       lines = lines[:len(lines)-1]
   }
   // 清理: 每行末尾可能带 \r（Windows换行符 \r\n）
   for i := range lines {
       lines[i] = strings.TrimRight(lines[i], "\r")
   }
   
   totalLines := len(lines)

3. 检查 startLine 越界:
   若 startLine >= totalLines → 返回 ([]string{}, nil)  // 超出范围，返回空列表
   若 startLine < 0 → startLine = 0  // 修正为从头开始

4. 截取指定范围:
   endLine := startLine + lineCount
   若 endLine > totalLines → endLine = totalLines  // 不超出总行数
   
   result := lines[startLine:endLine]

5. 返回 (result, nil)
   // 返回值包含行内容（不含行号），调用方（前端）自行根据 startLine 计算行号
```

**异常流程**:

- **MinIO 对象不存在**: GetObject 返回错误 → 返回空列表 + 错误
- **文件内容为空**: lines=[] → startLine >= 0 越界 → 返回空列表

**边界情况**:

- **lineCount 参数**: 调用方固定传 100（CONSTRAINTS: 100行/页）
- **startLine 参数**: 前端传 (page-1)*100（第1页=0, 第2页=100, 第3页=200）
- **行号计算**: 返回的 `[]string` 中 index 0 对应原始文件的第 `startLine` 行
- **大文件（如部署日志 >10MB）**: io.ReadAll 全量加载到内存；日志文件通常 <1MB，可接受

- 验收: `go build ./internal/middleware/... ./pkg/minio/...` 编译成功

---

## Phase 2: 数据模型定义

**必须在 Phase 1 完成后执行**

### Step 2.1: 核心业务表模型

- 文件: `internal/model/flow.go` — 交付流程相关表
  ```go
  type DeliveryFlow struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      FlowName    string    `gorm:"size:128;not null"`
      IDCName     string    `gorm:"size:64;not null"`   // 机房名称
      Status      string    `gorm:"size:32;not null"`   // INIT/APPLYING/APPLIED/CHECKING/CHECKED/DEPLOYING/DEPLOYED/DRILLING/DRILLED/DONE
      Creator     string    `gorm:"size:64"`
      CreateTime  time.Time `gorm:"autoCreateTime"`
      UpdateTime  time.Time `gorm:"autoUpdateTime"`
  }
  
  type FlowPhase struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      FlowID      uint64    `gorm:"not null;index"`
      PhaseType   string    `gorm:"size:32;not null"`  // RESOURCE_APPLY/CHECK/MONITOR/DEPLOY/DRILL
      Status      string    `gorm:"size:32;not null"`  // PENDING/RUNNING/DONE/FAILED
      IsParallel  bool      `gorm:"default:false"`     // MONITOR/DEPLOY标记为并行
      FailReason  string    `gorm:"type:text"`         // FAILED时记录失败原因
      Sort        int       `gorm:"not null"`  // RESOURCE_APPLY=1, CHECK=2, MONITOR/DEPLOY=3(并行), DRILL=5
      StartTime   *time.Time
      EndTime     *time.Time
  }
  ```

- 文件: `internal/model/resource.go` — 资源申请相关表
  ```go
  type ResourceApply struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      FlowID      uint64    `gorm:"not null;index"`
      RefIDC      string    `gorm:"size:64;not null"`  // 参考机房名称
      Status      string    `gorm:"size:32;not null"`  // DRAFT/SUBMITTED/PARTIAL_SUBMITTED/SUBMIT_FAILED
      Creator     string    `gorm:"size:64"`
      CreateTime  time.Time `gorm:"autoCreateTime"`
  }
  
  type ResourceApplyItem struct {
      ID              uint64    `gorm:"primaryKey;autoIncrement"`
      ApplyID         uint64    `gorm:"not null;index"`
      ClusterName     string    `gorm:"size:128;not null;index"`
      MWType          string    `gorm:"size:64;not null"`  // 中间件类型: redis/kafka/zookeeper/nginx/minio/rocketmq
      IDC             string    `gorm:"size:64;not null"`
      Env             string    `gorm:"size:32;not null"`  // dev/test/prod
      NodeCount       int       `gorm:"not null"`
      CPU             string    `gorm:"size:32"`  // 如 "4C"
      Memory          string    `gorm:"size:32"`  // 如 "8G"
      Disk            string    `gorm:"size:32"`  // 如 "100G"
      IPs             string    `gorm:"type:text"`  // JSON数组, 已交付的IP列表
      DeliverStatus   string    `gorm:"size:32"`  // NONE/PARTIAL/FULL/SUBMIT_FAILED
       FailReason      string    `gorm:"type:text"`  // CMDB提交失败时记录具体原因
       Status          string    `gorm:"size:16;default:ENABLE"`  // ENABLE/DISABLE, 逻辑删除用
   }
  ```

- 文件: `internal/model/check.go` — 核查相关表
  ```go
  type CheckRule struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      RuleName    string    `gorm:"size:128;not null"`
      Scope       string    `gorm:"size:32;not null"`  // COMMON/MW_TYPE/CLUSTER
      MWType      string    `gorm:"size:64"`           // Scope=MW_TYPE时必填
      ClusterRegex string   `gorm:"size:256"`          // Scope=CLUSTER时必填, 正则表达式
      CheckType   string    `gorm:"size:32;not null"`  // SCRIPT/API
      CheckContent string   `gorm:"type:text"`         // 脚本内容或API配置JSON
      JudgeRule   string    `gorm:"type:text"`          // JSON: 判定规则配置
      Sort        int       `gorm:"not null"`
      Status      string    `gorm:"size:16;not null"`  // ENABLE/DISABLE
      CreateTime  time.Time `gorm:"autoCreateTime"`
      UpdateTime  time.Time `gorm:"autoUpdateTime"`
  }
  
  type CheckRecord struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      RuleID      uint64    `gorm:"not null;index"`
      FlowID      uint64    `gorm:"not null;index"`
      ClusterName string    `gorm:"size:128;not null;index"`
      Scope       string    `gorm:"size:32"`  // COMMON/MW_TYPE/CLUSTER
      ExecuteTime time.Time
      InputParams string    `gorm:"type:text"`  // JSON
      Result      string    `gorm:"size:16"`    // PASS/FAIL
      Detail      string    `gorm:"type:text"`  // JSON: 核查明细(含多节点结果)
      FailReason  string    `gorm:"type:text"`  // 失败时记录具体原因
      LogFilePath string    `gorm:"size:256"`   // MinIO日志文件路径
  }
  ```

- 文件: `internal/model/deploy.go` — 部署相关表
  ```go
  type DeployRecord struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      FlowID      uint64    `gorm:"not null;index"`
      ClusterName string    `gorm:"size:128;not null;index"`
      MWType      string    `gorm:"size:64;not null"`
      TaskID      string    `gorm:"size:128"`       // 部署服务返回的任务ID
      Status      string    `gorm:"size:32;not null"`  // PENDING/VALIDATING/DEPLOYING/VERIFYING/DONE/FAILED
      Params      string    `gorm:"type:text"`  // JSON: 部署参数
      RetryCount  int       `gorm:"default:0"`
      StartTime   *time.Time
      EndTime     *time.Time
  }
  
  type DeployStageLog struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      DeployID    uint64    `gorm:"not null;index"`
      Stage       string    `gorm:"size:32;not null"`  // VALIDATE/DEPLOY/VERIFY
      Status      string    `gorm:"size:32"`           // PENDING/RUNNING/DONE/FAILED — 每阶段独立状态
      LogFilePath string    `gorm:"size:256"`           // MinIO日志路径
      StartTime   *time.Time
      EndTime     *time.Time
  }
  ```

- 文件: `internal/model/monitor.go` — 监控相关表
  ```go
  type MonitorDeploy struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      FlowID      uint64    `gorm:"not null;index"`
      IPs         string    `gorm:"type:text"`  // JSON数组, 选中的机器IP
      DeployStatus string   `gorm:"size:32"`  // PENDING/RUNNING/DONE/FAILED
      DeployTaskID string   `gorm:"size:128"` // 监控部署服务返回的任务ID
      DeployLogPath string  `gorm:"size:256"`  // MinIO
      ConfigStatus string   `gorm:"size:32"`  // PENDING/RUNNING/DONE/FAILED
      ConfigTaskID string   `gorm:"size:128"` // 监控配置服务返回的任务ID
      ConfigLogPath string  `gorm:"size:256"`  // 配置日志MinIO路径
      StartTime   *time.Time
      EndTime     *time.Time
  }
  ```

- 文件: `internal/model/drill.go` — 演练相关表
  ```go
  type DrillScene struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      SceneName   string    `gorm:"size:128;not null"`
      Scope       string    `gorm:"size:32;not null"`  // COMMON/MW_TYPE/CLUSTER
      MWType      string    `gorm:"size:64"`           // Scope=MW_TYPE时必填
      ClusterRegex string   `gorm:"size:256"`          // Scope=CLUSTER时必填
      Steps       string    `gorm:"type:text"`         // JSON数组: [{name, type(SHELL/ANSIBLE/API), content, target}]
      Status      string    `gorm:"size:16"`           // ENABLE/DISABLE
      CreateTime  time.Time `gorm:"autoCreateTime"`
      UpdateTime  time.Time `gorm:"autoUpdateTime"`
  }
  
  type DrillRecord struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      SceneID     uint64    `gorm:"not null;index"`
      FlowID      uint64    `gorm:"not null;index"`
      ClusterName string    `gorm:"size:128;not null;index"`
      Scope       string    `gorm:"size:32"`  // COMMON/MW_TYPE/CLUSTER
      Status      string    `gorm:"size:32"`  // PENDING/RUNNING/DONE/FAILED
      StartTime   *time.Time
      EndTime     *time.Time
      LogFilePath string    `gorm:"size:256"`  // MinIO
      Result      string    `gorm:"type:text"` // JSON: 每步结果
  }
  ```

- 文件: `internal/model/admin.go` — 管理配置相关表
  ```go
  type DeployConfig struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      NameRegex   string    `gorm:"size:256;not null"`  // 集群名称正则
      MWType      string    `gorm:"size:64;not null"`
      Params      string    `gorm:"type:text"`  // JSON数组: [{name, default, widget_type}]
      Status      string    `gorm:"size:16"`  // ENABLE/DISABLE
      CreateTime  time.Time `gorm:"autoCreateTime"`
      UpdateTime  time.Time `gorm:"autoUpdateTime"`
  }
  ```

- 文件: `internal/model/sys.go` — 系统基础表
  ```go
  type SysConfig struct {
      ID          uint64    `gorm:"primaryKey;autoIncrement"`
      ConfigKey   string    `gorm:"size:128;not null;uniqueIndex:idx_key_group"`
      ConfigGroup string    `gorm:"size:64;not null;uniqueIndex:idx_key_group"`
      ConfigValue string    `gorm:"type:text"`
      IsSensitive bool      `gorm:"default:false"`
      Version     int       `gorm:"not null;default:1"`
      Status      string    `gorm:"size:16;default:ENABLE"`
      Operator    string    `gorm:"size:64"`
      CreateTime  time.Time `gorm:"autoCreateTime"`
      UpdateTime  time.Time `gorm:"autoUpdateTime"`
  }
  
  type SysConfigHistory struct {
      ID         uint64    `gorm:"primaryKey;autoIncrement"`
      ConfigID   uint64    `gorm:"not null;index"`
      ConfigKey  string    `gorm:"size:128"`
      OldValue   string    `gorm:"type:text"`
      NewValue   string    `gorm:"type:text"`
      Version    int       `gorm:"not null"`
      Operator   string    `gorm:"size:64"`
      OperateTime time.Time
  }
  
  type DistributedLock struct {
      LockKey    string    `gorm:"primaryKey;size:256"`
      LockOwner  string    `gorm:"size:64;not null"`
      LockTime   time.Time `gorm:"autoCreateTime"`
      ExpireTime time.Time `gorm:"not null"`
  }
  
   type AuditLog struct {
       ID          uint64    `gorm:"primaryKey;autoIncrement"`
       Operator    string    `gorm:"size:64;not null;index"`
       OperateTime time.Time `gorm:"not null;index"`
       OperateIP   string    `gorm:"size:64"`
       APIPath     string    `gorm:"size:256;not null"`
       Method      string    `gorm:"size:16"`
       Params      string    `gorm:"type:text"`
       Result      string    `gorm:"size:16"`  // SUCCESS/FAIL
   }
   ```
  
  #### SysConfig GORM Hook 详细逻辑 (加密/解密/脱敏)

  SysConfig 使用 GORM Hook 在写入DB时自动加密, 读取时自动脱敏。Hook 只处理 DB 层面的加密/解密, sync.Map 中始终存储解密后明文。

  **BeforeCreate Hook**:

  ```
  func (s *SysConfig) BeforeCreate(tx *gorm.DB) error {
      if s.IsSensitive && s.ConfigValue != "" {
          encrypted, err := aesEncrypt(s.ConfigValue)
          if err != nil {
              log.Printf("[SysConfig] BeforeCreate加密失败: key=%s, group=%s, err=%v", s.ConfigKey, s.ConfigGroup, err)
              return fmt.Errorf("敏感配置加密失败: %v", err)  // 加密失败则阻断创建
          }
          s.ConfigValue = encrypted  // DB存储加密值
      }
      if s.Status == "" {
          s.Status = "ENABLE"
      }
      return nil
  }
  ```

  **BeforeUpdate Hook**:

  ```
  func (s *SysConfig) BeforeUpdate(tx *gorm.DB) error {
      if s.IsSensitive && s.ConfigValue != "" {
          // 判断ConfigValue是否已经是加密值(加密值以base64编码的nonce开头)
          // 避免重复加密: 如果值不是合法的加密格式(无法按aesDecrypt解密), 说明是用户传入的新明文
          decrypted, err := aesDecrypt(s.ConfigValue)
          if err != nil {
              // 解密失败 → 说明ConfigValue是新传入的明文(尚未加密), 需要加密
              encrypted, encErr := aesEncrypt(s.ConfigValue)
              if encErr != nil {
                  log.Printf("[SysConfig] BeforeUpdate加密失败: key=%s, err=%v", s.ConfigKey, encErr)
                  return fmt.Errorf("敏感配置加密失败: %v", encErr)
              }
              s.ConfigValue = encrypted
          }
          // 解密成功 → 说明ConfigValue已经是加密值(如热更新拉取的DB记录), 不重复加密
      }
      return nil
  }
  ```

  **AfterFind Hook**:

  ```
  func (s *SysConfig) AfterFind(tx *gorm.DB) error {
      // AfterFind 仅用于脱敏显示, 不修改DB值
      // 注意: AfterFind修改的是s.ConfigValue(struct字段), 不会写回DB
      // 但此Hook会影响所有从DB读取SysConfig的路径, 包括:
      //   - ConfigCenter.Init: 不应脱敏(需真实值存入sync.Map)
      //   - ConfigCenter.StartHotReload: 不应脱敏(需真实值存入sync.Map)
      //   - ConfigCenter.Set: 查旧值时不应脱敏(需真实值写SysConfigHistory)
      //   - API查询: 应脱敏(不应暴露明文给前端)
      
      // 解决方案: 不使用AfterFind自动脱敏
      // 而在ConfigCenter.Get()方法中手动脱敏(返回"****")
      // ConfigCenter.Init/StartHotReload/Set中使用解密后的真实值
      // AfterFind中仅做解密处理:
      
      if s.IsSensitive && s.ConfigValue != "" {
          decrypted, err := aesDecrypt(s.ConfigValue)
          if err != nil {
              log.Printf("[SysConfig] AfterFind解密失败: key=%s, group=%s", s.ConfigKey, s.ConfigGroup)
              // 解密失败 → 保留加密值(后续GetRealValue()会返回错误)
          } else {
              s.ConfigValue = decrypted  // struct字段改为明文, 供后续代码使用
          }
      }
      return nil
  }
  ```

  **关键设计选择**:

  | 选择 | 理由 | 否决方案 |
  |------|------|---------|
  | BeforeCreate加密 + AfterFind解密 | DB永远存加密值, struct字段永远为明文, 所有代码只处理明文 | Service层手动加密(容易遗漏) |
  | BeforeUpdate判断是否已加密 | 避免"加密值被二次加密"导致数据损坏 | 每次更新都加密(热更新拉取的加密值会被二次加密) |
  | 不在AfterFind中脱敏 | 脱敏由ConfigCenter.Get()方法控制, 不同场景需要不同脱敏策略 | AfterFind返回"****"(Init/Set也需要真实值, 无法区分) |
  | 加密失败阻断操作 | 敏感配置明文写入DB是安全风险, 宁可阻断 | 加密失败继续(明文泄露风险) |

  **边界情况**:

  - **IsSensitive=false**: 三个Hook都不做任何处理, ConfigValue直接存明文
  - **ConfigValue为空字符串**: IsSensitive=true时也跳过加密/解密(空值无意义)
  - **AfterFind修改struct但不写回DB**: GORM AfterFind只修改struct字段, 不触发UPDATE; 读取后若调用db.Save()会触发BeforeUpdate(此时ConfigValue已是明文 → BeforeUpdate判断非加密值 → 加密后写入 → 正确)
  - **AES_SECRET_KEY为空**: aesEncrypt/aesDecrypt返回错误 → BeforeCreate阻断/BeforeUpdate阻断/AfterFind记录失败

  - 验收: `go build ./internal/model/...` 编译成功

### Step 2.2: AutoMigrate 与数据库初始化

- 文件: `internal/database/migrate.go`
  - 函数签名:
    ```go
    func AutoMigrate(db *gorm.DB) error  // 按顺序迁移所有表模型
    ```
  - 内部调用 `db.AutoMigrate()` 注册所有 struct
- 验收: `go test ./internal/database/... -run TestAutoMigrate` 通过（需要真实MySQL或用 SQLite 替代测试）

---

## Phase 3: 管理配置模块

**必须在 Phase 2 完成后执行**

### Step 3.1: 核查规则 CRUD

- 文件: `internal/admin/check_rule.go`
  - struct: `CheckRuleService` `{ db *gorm.DB }`
  - 函数签名:
    ```go
    func NewCheckRuleService(db *gorm.DB) *CheckRuleService
    func (s *CheckRuleService) Create(ctx context.Context, rule *model.CheckRule) error
      // ★ 详细字段校验见下方 "CheckRuleService Create/Update/Delete 字段校验" 章节
    func (s *CheckRuleService) Update(ctx context.Context, rule *model.CheckRule) error
      // 同 Create 校验规则，额外: 不可修改 ID/CreateTime; 允许修改 RuleName/Scope/MWType/ClusterRegex/CheckType/CheckContent/JudgeRule/Sort/Status
    func (s *CheckRuleService) Delete(ctx context.Context, id uint64) error  // 逻辑删除: Status→DISABLE
    func (s *CheckRuleService) List(ctx context.Context, scope, mwType string) ([]*model.CheckRule, error)
    func (s *CheckRuleService) Get(ctx context.Context, id uint64) (*model.CheckRule, error)
    func (s *CheckRuleService) MatchRules(clusterName, mwType string) ([]*model.CheckRule, error)
      // 三层匹配逻辑:
      // 1. 查scope=COMMON, Status=ENABLE的规则
      // 2. 查scope=MW_TYPE, mwType=参数, Status=ENABLE的规则
      // 3. 查scope=CLUSTER, regexp.MatchString(clusterRegex, clusterName), Status=ENABLE的规则
      // 三层合并返回, 按Scope+Sort排序
    ```
- 文件: `api/v1/admin.go` — 注册路由:
  ```go
  // GET    /api/v1/check-rules          → List
  // GET    /api/v1/check-rules/:id      → Get
  // POST   /api/v1/check-rules          → Create
  // PUT    /api/v1/check-rules/:id      → Update
  // DELETE /api/v1/check-rules/:id      → Delete
  // GET    /api/v1/check-rules/match?cluster=xxx&mw_type=xxx → MatchRules
  ```
- 验收: `go test ./internal/admin/... -run TestCheckRuleService_MatchRules` 通过

#### CheckRuleService Create/Update/Delete 字段校验

**Create 校验规则**:

```
1. 字段必填校验:
   - RuleName: 非空, 长度 ≤ 128 → 若为空 → ErrParamInvalid "规则名称不能为空"
   - Scope: 必须为 COMMON/MW_TYPE/CLUSTER 之一 → 若非法 → ErrParamInvalid "scope取值非法"
   - CheckType: 必须为 SCRIPT/API 之一 → 若非法 → ErrParamInvalid "check_type取值非法"
   - CheckContent: 非空 → 若为空 → ErrParamInvalid "核查内容不能为空"
   - JudgeRule: 非空, 且必须是合法 JSON → 若为空 → ErrParamInvalid "判定规则不能为空"
     JSON 格式校验: json.Unmarshal(rule.JudgeRule, &map[string]any{}) 成功即可
     mode 必须为 status_code/json_field/keyword/value_range 之一
   - Sort: ≥ 0 → 若 < 0 → ErrParamInvalid "排序值不能为负"

2. Scope 条件校验:
   若 Scope == MW_TYPE:
     - MWType 必须非空 → 若为空 → ErrParamInvalid "MW_TYPE范围必须指定中间件类型"
     - MWType 必须为合法值(nginx/zookeeper/kafka/rocketmq/minio/redis) → 若非法 → ErrParamInvalid
   若 Scope == CLUSTER:
     - ClusterRegex 必须非空 → 若为空 → ErrParamInvalid "CLUSTER范围必须指定集群正则"
     - ClusterRegex 必须是合法正则 → regexp.MustCompile 校验 → 若非法 → ErrParamInvalid "集群正则表达式非法"
   若 Scope == COMMON:
     - MWType 和 ClusterRegex 应为空 → 若非空 → 不报错, 但写入DB时置空

3. JudgeRule JSON Schema 校验（根据 mode）:
   解析 JudgeRule JSON → judgeMap:
   mode := judgeMap["mode"]
   
   若 mode == "status_code":
     必须有 "expected" 字段, 值必须为整数 → 若缺失或类型错误 → ErrParamInvalid
   
   若 mode == "json_field":
     必须有 "field_path" 和 "expected" → 若缺失 → ErrParamInvalid "json_field模式必须指定field_path和expected"
   
   若 mode == "keyword":
     必须有 "expected" → 若缺失 → ErrParamInvalid
   
   若 mode == "value_range":
     必须有 "field_path", "min", "max" → 若缺失 → ErrParamInvalid "value_range模式必须指定field_path, min, max"
     min 和 max 必须为数值 → 若类型错误 → ErrParamInvalid
     min <= max → 若 min > max → ErrParamInvalid "value_range的min不能大于max"

4. 创建记录:
   db.Create(rule)
   Status 默认值: 若 rule.Status == "" → rule.Status = "ENABLE"
```

**Update 校验规则**: 同 Create 全部校验规则，额外:
- 查询原记录确认存在: db.First(&existing, id) → 若不存在 → ErrCheckRuleNotFound
- 不可修改字段: ID, CreateTime（不允许更新）
- 允许修改字段: RuleName, Scope, MWType, ClusterRegex, CheckType, CheckContent, JudgeRule, Sort, Status
- db.Save(rule) 更新

**Delete 逻辑删除**:
- 查询原记录确认存在: db.First(&existing, id) → 若不存在 → ErrCheckRuleNotFound
- 更新 Status = DISABLE: db.Model(&existing).Update("status", "DISABLE")
- 不执行物理删除（遵守 CONSTRAINTS: 逻辑删除）

### Step 3.2: 演练场景 CRUD

- 文件: `internal/admin/drill_scene.go`
  - struct: `DrillSceneService` `{ db *gorm.DB }`
  - 函数签名:
    ```go
    func NewDrillSceneService(db *gorm.DB) *DrillSceneService
    func (s *DrillSceneService) Create(ctx context.Context, scene *model.DrillScene) error
    func (s *DrillSceneService) Update(ctx context.Context, scene *model.DrillScene) error
    func (s *DrillSceneService) Delete(ctx context.Context, id uint64) error
    func (s *DrillSceneService) List(ctx context.Context, scope, mwType string) ([]*model.DrillScene, error)
    func (s *DrillSceneService) Get(ctx context.Context, id uint64) (*model.DrillScene, error)
    func (s *DrillSceneService) MatchScenes(clusterName, mwType string) ([]*model.DrillScene, error)
      // 同三层匹配逻辑: COMMON → MW_TYPE → regexp(CLUSTER)
    ```
- 文件: `api/v1/admin.go` — 补充路由:
  ```go
  // GET    /api/v1/drill-scenes          → List
  // GET    /api/v1/drill-scenes/:id      → Get
  // POST   /api/v1/drill-scenes          → Create
  // PUT    /api/v1/drill-scenes/:id      → Update
  // DELETE /api/v1/drill-scenes/:id      → Delete
  // GET    /api/v1/drill-scenes/match?cluster=xxx&mw_type=xxx → MatchScenes
  ```
- 验收: `go test ./internal/admin/... -run TestDrillSceneService_MatchScenes` 通过

#### DrillSceneService Create/Update/Delete 字段校验

**Create 校验规则**:

```
1. 必填校验:
   - SceneName: 非空, ≤ 128
   - Scope: COMMON/MW_TYPE/CLUSTER
   - Steps: 非空, 合法 JSON 数组

2. Scope 条件校验: 同 CheckRule（MW_TYPE→MWType必填, CLUSTER→ClusterRegex必填+合法正则）
   若 Scope == MW_TYPE:
     - MWType 必须非空 → 若为空 → ErrParamInvalid "MW_TYPE范围必须指定中间件类型"
     - MWType 必须为合法值 → 若非法 → ErrParamInvalid
   若 Scope == CLUSTER:
     - ClusterRegex 必须非空 → 若为空 → ErrParamInvalid "CLUSTER范围必须指定集群正则"
     - ClusterRegex 必须是合法正则 → 若非法 → ErrParamInvalid "集群正则表达式非法"

3. Steps JSON 校验:
   解析为 []DrillStep:
   type DrillStep struct { Name string; Type string; Content string; Target string }
   
   每个 step:
   - Name: 非空 → 若为空 → ErrParamInvalid "步骤名称不能为空"
   - Type: 必须为 SHELL/ANSIBLE/API 之一 → 若非法 → ErrParamInvalid "步骤类型非法"
   - Content: 非空 → 若为空 → ErrParamInvalid "步骤内容不能为空"
   - Target: 可为空（空=全部节点执行）
     若非空 → 必须是合法 IP 或逗号分隔的 IP 列表
     校验: 每段必须匹配 regexp `^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$`
     若非法 → ErrParamInvalid "target字段IP格式非法"

4. Status 默认值: 若为空 → ENABLE
```

**Update/Delete**: 同 CheckRule 的模式（Update 同 Create 校验 + 不可改 ID/CreateTime；Delete 逻辑删除 Status=DISABLE）。

### Step 3.3: 部署配置 CRUD

- 文件: `internal/admin/deploy_config.go`
  - struct: `DeployConfigService` `{ db *gorm.DB }`
  - 函数签名:
    ```go
    func NewDeployConfigService(db *gorm.DB) *DeployConfigService
    func (s *DeployConfigService) Create(ctx context.Context, cfg *model.DeployConfig) error
    func (s *DeployConfigService) Update(ctx context.Context, cfg *model.DeployConfig) error
    func (s *DeployConfigService) Delete(ctx context.Context, id uint64) error
    func (s *DeployConfigService) List(ctx context.Context, mwType string) ([]*model.DeployConfig, error)
    func (s *DeployConfigService) Get(ctx context.Context, id uint64) (*model.DeployConfig, error)
    func (s *DeployConfigService) MatchConfig(clusterName string) (*model.DeployConfig, error)
      // 遍历所有ENABLE配置, regexp.MatchString(nameRegex, clusterName), 命中第一个返回
    ```
- 文件: `api/v1/admin.go` — 补充路由:
  ```go
  // GET    /api/v1/deploy-configs          → List
  // GET    /api/v1/deploy-configs/:id      → Get
  // POST   /api/v1/deploy-configs          → Create
  // PUT    /api/v1/deploy-configs/:id      → Update
  // DELETE /api/v1/deploy-configs/:id      → Delete
  ```
- 验收: `go test ./internal/admin/... -run TestDeployConfigService_MatchConfig` 通过

#### DeployConfigService Create/Update/Delete 字段校验

**Create 校验规则**:

```
1. 必填校验:
   - NameRegex: 非空, ≤ 256, 必须是合法正则 → regexp.MustCompile 校验 → 若非法 → ErrParamInvalid "名称正则表达式非法"
   - MWType: 非空, 必须为合法中间件类型枚举值 → 若非法 → ErrParamInvalid "中间件类型非法"
   - Params: 非空, 合法 JSON 数组 → 若非法 JSON → ErrParamInvalid "部署参数JSON格式非法"

2. Params JSON 校验:
   解析为 []DeployParamItem:
   type DeployParamItem struct { Name string; Default string; WidgetType string }
   
   每个 item:
   - Name: 非空 → 若为空 → ErrParamInvalid "参数名称不能为空"
   - WidgetType: 必须为 input/select/textarea/number 之一（前端渲染类型）→ 若非法 → ErrParamInvalid "参数控件类型非法"
   - Default: 可为空

3. Status 默认值: 若为空 → ENABLE
```

**Update/Delete**: 同 CheckRule 的模式（Update 同 Create 校验 + 不可改 ID/CreateTime；Delete 逻辑删除 Status=DISABLE）。

---

## Phase 4: 交付流程引擎

**必须在 Phase 3 完成后执行**

### Step 4.1: 流程 FSM 与状态管理

- 文件: `internal/flow/engine.go`
  - struct: `FlowEngine` `{ db *gorm.DB }`
  - 定义状态常量与合法流转:
    ```go
    const (
        PhaseResourceApply = "RESOURCE_APPLY"
        PhaseCheck         = "CHECK"
        PhaseMonitor       = "MONITOR"    // 与DEPLOY并行
        PhaseDeploy        = "DEPLOY"     // 与MONITOR并行
        PhaseDrill         = "DRILL"
        
        StatusPending  = "PENDING"
        StatusRunning  = "RUNNING"
        StatusDone     = "DONE"
        StatusFailed   = "FAILED"
    )
    ```
  - 函数签名:
    ```go
    func NewFlowEngine(db *gorm.DB) *FlowEngine
    func (e *FlowEngine) CreateFlow(ctx context.Context, flowName, idcName, creator string) (*model.DeliveryFlow, error)
      // 创建flow记录 + 5个FlowPhase记录:
      // RESOURCE_APPLY: IsParallel=false, Sort=1
      // CHECK: IsParallel=false, Sort=2
      // MONITOR: IsParallel=true, Sort=3 (与DEPLOY并行)
      // DEPLOY: IsParallel=true, Sort=3 (与MONITOR并行, 同Sort值)
      // DRILL: IsParallel=false, Sort=5
      // 创建操作在 db.Transaction 内完成(DeliveryFlow + 5个FlowPhase原子写入)
    func (e *FlowEngine) GetFlow(ctx context.Context, id uint64) (*model.DeliveryFlow, []*model.FlowPhase, error)
    func (e *FlowEngine) StartPhase(ctx context.Context, flowID uint64, phaseType string) error
      // ★ 详细逻辑流程见下方 "StartPhase 详细逻辑流程" 章节
    func (e *FlowEngine) CompletePhase(ctx context.Context, flowID uint64, phaseType string) error
    func (e *FlowEngine) FailPhase(ctx context.Context, flowID uint64, phaseType string, reason string) error
    func (e *FlowEngine) GetFlowStatus(ctx context.Context, id uint64) (*FlowStatusVO, error)
      // FlowStatusVO: { flow整体状态, 各phase状态, 各phase下集群维度明细状态 }
    ```

#### FlowStatusVO 结构体定义与聚合逻辑

```go
type FlowStatusVO struct {
    FlowID   uint64          `json:"flow_id"`
    FlowName string          `json:"flow_name"`
    IDCName  string          `json:"idc_name"`
    Status   string          `json:"status"`      // INIT/APPLYING/.../DONE
    Creator  string          `json:"creator"`
    CreateTime time.Time     `json:"create_time"`
    Phases   []*PhaseStatusVO `json:"phases"`     // 5个环节的状态
}

type PhaseStatusVO struct {
    PhaseType  string        `json:"phase_type"`  // RESOURCE_APPLY/CHECK/MONITOR/DEPLOY/DRILL
    Status     string        `json:"status"`      // PENDING/RUNNING/DONE/FAILED
    IsParallel bool          `json:"is_parallel"` // MONITOR/DEPLOY=true
    FailReason string        `json:"fail_reason"` // FAILED时有值
    Sort       int           `json:"sort"`
    StartTime  *time.Time    `json:"start_time"`
    EndTime    *time.Time    `json:"end_time"`
    Clusters   []*ClusterStatusVO `json:"clusters"` // 该环节下各集群的状态
}

type ClusterStatusVO struct {
    ClusterName string       `json:"cluster_name"`
    MWType      string       `json:"mw_type"`
    Status      string       `json:"status"`      // 该集群在此环节的状态(由业务模块的记录决定)
    Detail      string       `json:"detail"`       // JSON: 状态明细(核查结果/部署阶段/演练步骤等)
}
```

**GetFlowStatus 聚合逻辑**:

```
1. 查询 DeliveryFlow WHERE id=flowID → 基础信息
2. 查询 FlowPhase WHERE flow_id=flowID, ORDER BY sort → 5个环节

3. 对每个环节, 聚合集群维度明细:
   RESOURCE_APPLY:
     查 ResourceApplyItem(WHERE apply_id → ResourceApply WHERE flow_id, status != DISABLE)
     Clusters[].Status = item.DeliverStatus
     Clusters[].Detail = JSON{node_count, expected_count, actual_count, ips}

   CHECK:
     查 CheckRecord(WHERE flow_id, DISTINCT cluster_name)
     按cluster_name分组: 全部PASS→"PASS", 有FAIL→"FAIL"
     Clusters[].Status = 分组判定结果
     Clusters[].Detail = JSON{pass_count, fail_count, rule_count}

   MONITOR:
     查 MonitorDeploy WHERE flow_id(每flow只有1条)
     Clusters[].Status = DeployStatus/ConfigStatus(合并展示)
     Clusters[].Detail = JSON{deploy_status, config_status}

   DEPLOY:
     查 DeployRecord WHERE flow_id
     Clusters[].Status = record.Status(PENDING/VALIDATING/.../DONE/FAILED)
     Clusters[].Detail = JSON{task_id, stage_statuses:[{stage,status,start_time,end_time}]}

   DRILL:
     查 DrillRecord WHERE flow_id
     按cluster_name分组: 全部DONE→"DONE", 有FAILED→"FAILED"
     Clusters[].Status = 分组判定结果
     Clusters[].Detail = JSON{scene_count, pass_count, fail_count}

4. 构造 FlowStatusVO 并返回
```

- 验收: `go test ./internal/flow/... -run TestFlowEngine_StartPhase` 通过

#### StartPhase 详细逻辑流程

**输入**: `flowID`, `phaseType`（RESOURCE_APPLY/CHECK/MONITOR/DEPLOY/DRILL）

**前置条件**:
- DeliveryFlow 记录存在且 Status != DONE（流程未结束）
- FlowPhase 记录存在（flowID + phaseType 对应的记录）

**正常流程**:

```
1. 查询 DeliveryFlow WHERE id=flowID
   若不存在 → 返回错误 ErrParamInvalid "流程不存在"
   若 Status=DONE → 返回错误 ErrParamInvalid "流程已完成，不可操作"

2. 查询 FlowPhase WHERE flowID=参数 AND phaseType=参数
   若不存在 → 返回错误 ErrParamInvalid "环节不存在"
   若 Status=RUNNING → 返回错误 ErrParamInvalid "环节正在进行中，不可重复触发"
   若 Status=DONE → 返回错误 ErrParamInvalid "环节已完成，无需再次触发"

3. 前置依赖校验（根据phaseType执行不同规则）:

   RESOURCE_APPLY: 无前置依赖，任何状态都可触发
   
   CHECK:
     查询 FlowPhase WHERE flowID AND phaseType=RESOURCE_APPLY
     若 Status != DONE → 返回错误 "资源申请环节尚未完成，无法开始核查"
   
   MONITOR:
     无前置依赖（与DEPLOY并行）
     但至少 RESOURCE_APPLY=DONE（监控部署需要资源已交付）
     查询 FlowPhase WHERE flowID AND phaseType=RESOURCE_APPLY
     若 Status != DONE → 返回错误 "资源申请环节尚未完成，无法开始监控部署"
   
   DEPLOY:
     查询 FlowPhase WHERE flowID AND phaseType=CHECK
     若 Status != DONE → 返回错误 "核查环节尚未完成，无法开始服务部署"
   
   DRILL:
     查询 FlowPhase WHERE flowID AND phaseType=DEPLOY
     若 Status == PENDING → 返回错误 "服务部署环节尚未开始"
     若 Status == FAILED → 返回错误 "服务部署环节失败，无法开始演练"
     若 Status == RUNNING 或 DONE → 允许触发
     （放宽原因: DEPLOY正在进行时，部分集群可能已完成，允许对这些集群开始演练）

4. 更新 FlowPhase:
   - Status = RUNNING
   - StartTime = now

5. 更新 DeliveryFlow.Status = 对应的进行中状态（见下方映射表）

6. WebSocket.PushStatus(flowID, 环节启动通知)

7. 返回 nil（成功）
```

**DeliveryFlow.Status 映射表**:

```
RESOURCE_APPLY 开始 → DeliveryFlow.Status = APPLYING
CHECK 开始          → DeliveryFlow.Status = CHECKING
MONITOR 开始        → DeliveryFlow.Status = MONITORING
DEPLOY 开始         → DeliveryFlow.Status = DEPLOYING
DRILL 开始          → DeliveryFlow.Status = DRILLING

注意: MONITOR和DEPLOY并行时，Flow整体Status取两者中更靠后的阶段
例如: MONITOR先开始 → Status=MONITORING; DEPLOY后开始 → Status=DEPLOYING
这不影响MONITOR的运行，只是Flow整体展示值取"进度更靠后"的阶段
```

**异常流程**:

- **前置依赖未完成**: 返回具体错误信息（哪个环节未完成），不更新任何状态
- **环节已在RUNNING**: 返回"环节正在进行中，不可重复触发"，不重复更新StartTime
- **环节已完成DONE**: 返回"环节已完成，无需再次触发"
- **FlowPhase.Status=FAILED时允许重新触发**: FAILED视为"可以重新开始"，更新Status=RUNNING，重置StartTime

**边界情况**:

- **MONITOR和DEPLOY并行**: 互不依赖，都依赖CHECK=DONE，可各自独立触发StartPhase
- **DRILL的DEPLOY依赖放宽**: DEPLOY=RUNNING时允许触发DRILL（部分集群可能已完成部署）
- **同一个环节FAILED后重新触发**: 允许，Status从FAILED改为RUNNING
- **CompletePhase和StartPhase配合**: StartPhase仅标记开始，CompletePhase由用户手动触发

#### CompletePhase 详细逻辑流程

**输入**: `flowID`, `phaseType`

**正常流程**:

```
1. db.Transaction(func(tx *gorm.DB) error {
     a. 查询 FlowPhase WHERE flowID AND phaseType
        若 Status != RUNNING → 返回错误 "环节未在进行中"
     b. 更新 FlowPhase:
        - Status = DONE
        - EndTime = now
     c. 更新 DeliveryFlow.Status:
        - RESOURCE_APPLY完成 → 检查所有Phase, 取进度最靠后的状态
        - CHECK完成 → 若DEPLOY或MONITOR未开始则Status=CHECKED
        - MONITOR完成 → 同上逻辑(不影响DEPLOY进度)
        - DEPLOY完成 → 若DRILL未开始则Status=DEPLOYED
        - DRILL完成 → Status=DONE (流程全部完成)
     d. return nil
   })
2. WebSocket.PushStatus(flowID, 环节完成通知)
3. 返回 nil
```

**事务要求**: FlowPhase更新 + DeliveryFlow更新必须在同一事务内，保证原子性。

#### FailPhase 详细逻辑流程

**输入**: `flowID`, `phaseType`, `reason string`

**正常流程**:

```
1. db.Transaction(func(tx *gorm.DB) error {
     a. 查询 FlowPhase WHERE flowID AND phaseType
        若 Status != RUNNING → 返回错误
     b. 更新 FlowPhase:
        - Status = FAILED
        - FailReason = reason
        - EndTime = now
     c. DeliveryFlow.Status 不更新（保持当前进行中状态，允许用户重试触发）
     d. return nil
   })
2. WebSocket.PushStatus(flowID, 环节失败通知+reason)
3. 返回 nil
```
- **Flow整体Status优先级**: 始终取当前所有Phase中进度最靠后的状态

### Step 4.2: 流程 API 与 WebSocket 推送

- 文件: `api/v1/flow.go`
  ```go
  // POST   /api/v1/flows                    → CreateFlow
  // GET    /api/v1/flows/:id                 → GetFlowStatus
  // POST   /api/v1/flows/:id/phases/:type/start  → StartPhase
  // POST   /api/v1/flows/:id/phases/:type/complete → CompletePhase
  ```
- 文件: `internal/flow/ws.go`
  - struct: `FlowWebSocket` `{ hub *WSHub }`
  - 函数签名:
    ```go
    func NewFlowWebSocket() *FlowWebSocket
    func (ws *FlowWebSocket) HandleConnection(c *gin.Context)  // WebSocket连接处理
    func (ws *FlowWebSocket) PushStatus(flowID uint64, status any)  // 状态变更时推送
    ```

#### WebSocket Hub 详细逻辑流程

**Hub 结构体与运行机制**:

```
// WSHub 管理 WebSocket 连接集合和消息广播
type WSHub struct {
    clients    map[uint64]*WSClient  // key=flowID, value=WSClient连接
    register   chan *WSClient          // 新连接注册通道
    unregister chan *WSClient          // 连接注销通道
    broadcast chan *WSMessage          // 消息广播通道
    mu        sync.RWMutex              // 保护 clients map
}

type WSClient struct {
    flowID    uint64                  // 该连接订阅的流程ID
    conn      *websocket.Conn         // WebSocket连接
    sendCh    chan []byte             // 该连接的发送通道(缓冲100条)
}

type WSMessage struct {
    FlowID    uint64                  // 目标流程ID(0=广播给全部)
    Data      []byte                  // 消息内容(JSON编码)
}
```

**Hub 启动流程**:

```
func NewWSHub() *WSHub {
    hub := &WSHub{
        clients:    make(map[uint64]*WSClient),
        register:   make(chan *WSClient, 8),
        unregister: make(chan *WSClient, 8),
        broadcast:  make(chan *WSMessage, 256),
    }
    go hub.run()  // 启动 Hub 的消息循环处理 goroutine
    return hub
}

// Hub 的核心 goroutine: 处理注册/注销/广播
func (h *WSHub) run() {
    defer log.Printf("[WSHub] goroutine退出")
    
    for {
        select {
        case client := <-h.register:
            // 新连接注册: 添加到 clients map
            h.mu.Lock()
            h.clients[client.flowID] = client
            h.mu.Unlock()
            log.Printf("[WSHub] 新连接注册: flowID=%d", client.flowID)
        
        case client := <-h.unregister:
            // 连接注销: 从 clients map 移除, 关闭 sendCh
            h.mu.Lock()
            if existing, ok := h.clients[client.flowID]; ok {
                if existing == client {
                    delete(h.clients, client.flowID)
                }
            }
            h.mu.Unlock()
            close(client.sendCh)  // 关闭发送通道, 通知 send goroutine 退出
            log.Printf("[WSHub] 连接注销: flowID=%d", client.flowID)
        
        case msg := <-h.broadcast:
            // 消息广播: 根据 FlowID 定向发送, FlowID=0 则广播给全部
            h.mu.Lock()
            if msg.FlowID == 0 {
                // 广播给所有连接
                for _, client := range h.clients {
                    client.sendCh <- msg.Data  // 非阻塞写入通道(满则丢弃)
                }
            } else {
                // 定向发送给订阅该 flowID 的连接
                if client, ok := h.clients[msg.FlowID]; ok {
                    client.sendCh <- msg.Data  // 非阻塞写入
                }
            }
            h.mu.Unlock()
            log.Printf("[WSHub] 广播消息: flowID=%d, 数据长度=%d", msg.FlowID, len(msg.Data))
        }
    }
}
```

**HandleConnection 连接升级流程**:

```
func (ws *FlowWebSocket) HandleConnection(c *gin.Context) {
    // 1. WebSocket 连接升级
    conn, err := ws.hub.upgrader.Upgrade(c.Writer, c.Request, nil)
    if err != nil {
        log.Printf("[WebSocket] 连接升级失败: %v", err)
        return  // 升级失败不返回错误（客户端看到断开连接）
    }
    
    // 2. 从查询参数获取 flowID
    flowIDStr := c.Query("flow_id")
    flowID := uint64(0)
    if flowIDStr != "" {
        flowID, _ = strconv.ParseUint(flowIDStr, 64)
    }
    
    // 3. 创建 WSClient 并注册到 Hub
    client := &WSClient{
        flowID: flowID,
        conn:   conn,
        sendCh: make(chan []byte, 100),  // 缓冲100条消息
    }
    ws.hub.register <- client
    
    // 4. 启动发送 goroutine
    go func() {
        defer log.Printf("[WebSocket] 发送goroutine退出: flowID=%d", flowID)
        defer conn.Close()  // goroutine退出时关闭连接
        
        for data := range client.sendCh {
            // 从 sendCh 读取消息, 写入 WebSocket
连接
            err := conn.WriteMessage(websocket.TextMessage, data)
            if err != nil {
                log.Printf("[WebSocket] 写入失败: flowID=%d, err=%v", flowID, err)
                return  // 写入失败退出 goroutine
            }
        }
    }()
    
    // 5. 启动接收 goroutine (读取客户端消息, 主要是心跳和断开通知)
    go func() {
        defer log.Printf("[WebSocket] 接收goroutine退出: flowID=%d", flowID)
        defer func() { ws.hub.unregister <- client }  // goroutine退出时注销连接
        
        for {
            messageType, data, err := conn.ReadMessage()
            if err != nil {
                log.Printf("[WebSocket] 读取失败: flowID=%d, err=%v", flowID, err)
                return  // 读取失败退出 goroutine
            }
            // 客户端消息通常是心跳(ping)或断开通知
            // 目前不处理客户端消息, 仅保持连接存活
            log.Printf("[WebSocket] 收到客户端消息: flowID=%d, type=%d, data=%s", flowID, messageType, string(data))
        }
    }()
    
    log.Printf("[WebSocket] 连接建立: flowID=%d", flowID)
}
```

**PushStatus 綈息推送流程**:

```
func (ws *FlowWebSocket) PushStatus(flowID uint64, status any) {
    // 1. 序列化状态为 JSON
    data, err := json.Marshal(status)
    if err != nil {
        log.Printf("[WebSocket] 序列化失败: flowID=%d, err=%v", flowID, err)
        return
    }
    
    // 2. 构造广播消息
    msg := &WSMessage{
        FlowID: flowID,  // 指定目标流程; 0=广播给全部
        Data:   data,
    }
    
    // 3. 发送到 Hub 的 broadcast channel
    // 非阻塞写入: broadcast channel 缓冲256条, 满则丢弃(不阻塞业务逻辑)
    select {
    case ws.hub.broadcast <- msg:
        // 成功写入
    default:
        // channel 满, 丢弃消息(不阻塞业务)
        log.Printf("[WebSocket] 广播通道满, 丢弃消息: flowID=%d", flowID)
    }
}
```

**异常流程**:

- **WebSocket 升级失败**: 不返回错误（客户端看到断开连接），日志记录原因
- **flowID 解析失败**: flowID=0，连接仍建立但不订阅任何流程状态推送
- **conn.WriteMessage 失败**: 写入 goroutine 退出，连接关闭
- **conn.ReadMessage 失败**: 接收 goroutine 退出，连接注销
- **broadcast channel 满**: 丢弃消息，不阻塞业务逻辑（推送是辅助功能）
- **sendCh 满**: 非阻塞写入，满则丢弃（客户端可能错过几条状态更新）

**边界情况**:

- **flowID=0**: 连接不订阅任何特定流程，但仍保持存活（可用于管理界面查看所有流程）
- **多个连接订阅同一 flowID**: Hub 的 clients map 为 `map[uint64]*WSClient`，同一 flowID 只保留最新连接（旧连接被覆盖）
- **客户端断线**: 接收 goroutine 检测到 ReadMessage 错误 → 自动注销连接 → 发送 goroutine 退出 → 连接关闭
- **Hub goroutine 退出**: 仅在 main.go 优雅退出时发生（关闭 register/unregister/broadcast channel）
- **消息格式**: WebSocket TextMessage, 内容为 JSON 编码的状态数据
- **心跳机制**: 客户端可定期发送 ping 消息保持连接存活; 服务端不主动 ping, 但接收 goroutine 持续读取保持连接

- 验收: `go build ./internal/flow/... ./api/v1/...` 编译成功

---

## Phase 5: 业务模块 — 资源申请与核查

**必须在 Phase 4 完成后执行**

### Step 5.1: CMDB 适配器

- 文件: `internal/adapter/cmdb/client.go`
  - struct: `CMDBClient` `{ baseURL string; timeout time.Duration; retryCount int; retryInterval time.Duration }`
  - 函数签名:
    ```go
    func NewCMDBClient(cfg *config.CMDBConfig) *CMDBClient
    func (c *CMDBClient) QueryResources(idc, ownerGroup, opsGroup string) ([]*CMDBResource, error)
      // 调用CMDB GET接口, 超时30秒, 重试3次间隔5秒, 失败返回 ErrCMDBAPIFailed
    func (c *CMDBClient) SubmitResource(clusterName string, items []*ResourceApplyItem) error
      // 调用CMDB POST接口, 批量提交资源申请
    func (c *CMDBClient) QueryDeliveredResources(idc string) ([]*CMDBResource, error)
      // 查询已交付资源
    ```
  - type: `CMDBResource` `{ ClusterName, MWType, IDC, IPs []string, CPU, Memory, Disk }`

#### CMDBClient HTTP 调用详细逻辑

**通用模式**: CMDBClient 与其他适配器的关键差异: **GET和POST都有重试**（CMDB是只读查询+幂等提交, 重试安全; Deploy/Monitor/Ops的POST非幂等不重试）。

**http.Client 配置**:

```
// CMDBClient 内部共享一个 http.Client
httpClient := &http.Client{
    Timeout: 30 * time.Second,  // 连接+读写总超时30秒
}
```

**重试封装函数**:

```
// Retry: 通用重试封装, CMDB所有方法都使用重试
func (c *CMDBClient) Retry(fn func() (any, error), maxRetry int, interval time.Duration) (any, error) {
    var lastErr error
    for i := 0; i <= maxRetry; i++ {  // i=0是首次调用, i=1~maxRetry是重试
        result, err := fn()
        if err == nil {
            return result, nil
        }
        lastErr = err
        if i < maxRetry {
            log.Printf("[CMDB] 第%d次调用失败, %v秒后重试: %v", i+1, interval.Seconds(), err)
            time.Sleep(interval)
        }
    }
    return nil, fmt.Errorf("CMDB接口调用失败(重试%d次): %v", maxRetry, lastErr)
}
```

**QueryResources 详细逻辑**:

```
输入: idc, ownerGroup, opsGroup

1. 构造 GET 请求:
   values := url.Values{}
   values.Set("idc", idc)
   if ownerGroup != "" { values.Set("owner_group", ownerGroup) }
   if opsGroup != "" { values.Set("ops_group", opsGroup) }
   url := fmt.Sprintf("%s/api/cmdb/resources?%s", c.baseURL, values.Encode())
   req, _ := http.NewRequestWithContext(ctx, "GET", url, nil)

2. 带重试发送请求(重试3次间隔5秒):
   result, err := c.Retry(func() (any, error) {
       resp, err := c.httpClient.Do(req)
       若 err != nil → 返回 (nil, err)  // 超时/网络错误, 触发重试
       
       respBytes, _ := io.ReadAll(resp.Body)
       resp.Body.Close()
       
       若 resp.StatusCode == 200 → 解析为 []*CMDBResource → 返回 (resources, nil)
       若 resp.StatusCode == 400 → 返回 (nil, ErrParamInvalid "CMDB查询参数非法")  // 不重试(参数错误重试无意义)
       若 resp.StatusCode == 500 → 返回 (nil, ErrAPICallFailed "CMDB服务内部错误")  // 重试(服务可能暂时异常)
       其他 → 返回 (nil, ErrAPICallFailed fmt.Sprintf("CMDB返回异常状态码: %d", resp.StatusCode))
   }, 3, 5*time.Second)
   
   若 err != nil → 返回 (nil, ErrCMDBAPIFailed err.Error())

3. 返回 (result.([]*CMDBResource), nil)
```

**SubmitResource 详细逻辑**:

```
输入: clusterName, items

1. 构造 POST 请求体:
   requestBody := map[string]any{
       "cluster_name": clusterName,
       "items":        items,  // 序列化为JSON
   }
   bodyBytes, _ := json.Marshal(requestBody)

2. 构造 HTTP 请求:
   url := fmt.Sprintf("%s/api/cmdb/resources/submit", c.baseURL)
   req, _ := http.NewRequestWithContext(ctx, "POST", url, bytes.NewReader(bodyBytes))
   req.Header.Set("Content-Type", "application/json")

3. 带重试发送请求(重试3次间隔5秒):
   ★ CMDB的POST提交是幂等的(ON CONFLICT不报错), 因此重试安全
   ★ 这与Deploy/Monitor/Ops的POST不同(它们不重试)
   
   result, err := c.Retry(func() (any, error) {
       resp, err := c.httpClient.Do(req)
       若 err != nil → 返回 (nil, err)
       
       respBytes, _ := io.ReadAll(resp.Body)
       resp.Body.Close()
       
       若 resp.StatusCode == 200 → 返回 (nil, nil)  // 提交成功
       若 resp.StatusCode == 400 → 返回 (nil, ErrParamInvalid "CMDB提交参数非法")
       若 resp.StatusCode == 500 → 返回 (nil, ErrAPICallFailed "CMDB服务内部错误")  // 重试
       其他 → 返回 (nil, ErrAPICallFailed)
   }, 3, 5*time.Second)
   
   若 err != nil → 返回 err  // 提交失败

4. 返回 nil
```

**QueryDeliveredResources 详细逻辑**:

```
输入: idc

1. 构造 GET 请求:
   url := fmt.Sprintf("%s/api/cmdb/resources/delivered?idc=%s", c.baseURL, url.QueryEscape(idc))
   req, _ := http.NewRequestWithContext(ctx, "GET", url, nil)

2. 带重试发送请求(重试3次间隔5秒):
   result, err := c.Retry(func() (any, error) {
       resp, err := c.httpClient.Do(req)
       若 err != nil → 返回 (nil, err)
       
       respBytes, _ := io.ReadAll(resp.Body)
       resp.Body.Close()
       
       若 resp.StatusCode == 200 → 解析为 []*CMDBResource → 返回 (resources, nil)
       若 resp.StatusCode == 400 → 返回 (nil, ErrParamInvalid)
       若 resp.StatusCode == 500 → 返回 (nil, ErrAPICallFailed)  // 重试
       其他 → 返回 (nil, ErrAPICallFailed)
   }, 3, 5*time.Second)
   
   若 err != nil → 返回 (nil, ErrCMDBAPIFailed err.Error())

3. 返回 (result.([]*CMDBResource), nil)
```

**异常流程**:

- **http.Client.Do 超时(30秒)**: 触发重试(最多3次), 全部超时后返回 ErrCMDBAPIFailed
- **响应JSON解析失败**: 返回 ErrCMDBAPIFailed "响应格式非法"
- **baseURL 为空**: 初始化时校验, 空值则 NewCMDBClient 返回错误
- **400错误不重试**: 参数错误是调用方问题, 重试无意义, 直接返回 ErrParamInvalid
- **500错误重试**: 服务端临时异常, 重试可能恢复

**边界情况**:

- **CMDB与Deploy/Monitor/Ops的关键差异**: CMDB的POST(SubmitResource)是幂等的(ON CONFLICT不报错), 因此可以重试; Deploy/Monitor/Ops的POST是非幂等的(TriggerDeploy等每次创建新任务), **禁止重试**
- **ownerGroup/opsGroup为空**: 仍发送请求, CMDB接口可能不强制要求这两个参数
- **CMDB返回空列表**: QueryResources返回空[]*CMDBResource, 不视为错误
- **重试间隔5秒**: 每次重试前等待5秒, 给CMDB服务恢复时间

### Step 5.2: 资源申请模块

- 文件: `internal/resource/service.go`
  - struct: `ResourceService` `{ db *gorm.DB; cmdb *adapter.CMDBClient; configCenter *config.ConfigCenter }`
  - 函数签名:
    ```go
    func NewResourceService(db *gorm.DB, cmdb *adapter.CMDBClient, configCenter *config.ConfigCenter) *ResourceService
    func (s *ResourceService) InitApply(ctx context.Context, flowID uint64, refIDC string) ([]*model.ResourceApplyItem, error)
      // ★ 详细逻辑见下方 "InitApply 详细逻辑流程" 章节
    func (s *ResourceService) UpdateApplyItem(ctx context.Context, item *model.ResourceApplyItem) error
    func (s *ResourceService) DeleteApplyItem(ctx context.Context, itemID uint64) error
    func (s *ResourceService) AddApplyItem(ctx context.Context, item *model.ResourceApplyItem) error
    func (s *ResourceService) ConfirmAndSubmit(ctx context.Context, flowID uint64) (*ConfirmSubmitResult, error)
      // 详细逻辑见下方 "Step 5.2 详细逻辑流程" 章节
    ```
- 文件: `api/v1/resource.go`
  ```go
  // POST   /api/v1/flows/:id/resource/init       → InitApply
  // PUT    /api/v1/resource/items/:id              → UpdateApplyItem
  // DELETE /api/v1/resource/items/:id              → DeleteApplyItem
  // POST   /api/v1/flows/:id/resource/items        → AddApplyItem
  // POST   /api/v1/flows/:id/resource/submit       → ConfirmAndSubmit
  // GET    /api/v1/flows/:id/resource/items         → 查询资源申请列表
  ```
- 验收: `go test ./internal/resource/... -run TestResourceService_InitApply` 通过

#### Step 5.2: InitApply 详细逻辑流程

**输入**: `flowID uint64`, `refIDC string`

**前置条件**:
- 资源申请环节已触发（FlowPhase.RESOURCE_APPLY.Status = RUNNING）
- refIDC 参数非空

**正常流程**:

```
1. 校验:
   a. 查询 FlowPhase WHERE flowID=参数 AND phaseType=RESOURCE_APPLY
      若 Status != RUNNING → 返回错误 ErrParamInvalid "资源申请环节未启动"
   b. 查询 ResourceApply WHERE flowID=参数
      若已存在且 Status != DRAFT → 返回错误 ErrParamInvalid "资源申请已提交，不可重新初始化"
      若已存在且 Status = DRAFT → 返回错误 ErrParamInvalid "资源申请已初始化，请修改或提交"

2. 调用 CMDBClient.QueryResources(refIDC, ownerGroup, opsGroup)
   ownerGroup 和 opsGroup 从 ConfigCenter 获取:
   - ownerGroup = ConfigCenter.GetRealValue("default_owner_group", "resource")
   - opsGroup = ConfigCenter.GetRealValue("default_ops_group", "resource")
   若 ConfigCenter 中未配置 → 使用空字符串（CMDB 接口可能不强制要求）
   
   若 CMDB 调用失败 → 返回错误 ErrCMDBAPIFailed "查询参考机房资源失败"

3. 按 ClusterName 分组 CMDB 资源:
   grouped := map[string][]*CMDBResource{}  // key: ClusterName
   for _, res := range cmdbResources {
       grouped[res.ClusterName] = append(grouped[res.ClusterName], res)
   }
   // CMDB 返回的每条记录代表一个节点(IP)，同一集群下多个节点需合并为一条 ResourceApplyItem

4. 创建 ResourceApply 记录:
   apply := &model.ResourceApply{
       FlowID: flowID,
       RefIDC: refIDC,
       Status: DRAFT,        // 初始状态: 待确认
       Creator: operator,     // 从 JWT context 获取或从 API 参数传入
   }
   db.Create(apply)

5. 逐集群创建 ResourceApplyItem:
   items := []*model.ResourceApplyItem{}
   for clusterName, nodes := range grouped {
       // 从第一个节点取集群级别的通用字段（CMDB 返回的同集群节点这些字段相同）
       firstNode := nodes[0]
       
       // 合并所有节点的 IP
       ips := []string{}
       for _, node := range nodes {
           if node.IP != "" {
               ips = append(ips, node.IP)
           }
       }
       
       item := &model.ResourceApplyItem{
           ApplyID:       apply.ID,
           ClusterName:   clusterName,
           MWType:        firstNode.MWType,
           IDC:           firstNode.IDC,
           Env:           "prod",       // 默认"prod"，用户可修改
           NodeCount:     len(ips),     // IP 数量 = 申请节点数
           CPU:           firstNode.CPU,
           Memory:        firstNode.Memory,
           Disk:          firstNode.Disk,
           IPs:           "",           // 初始为空，提交后 CMDB 交付时回填
           DeliverStatus: "NONE",       // 尚未交付
           FailReason:    "",
       }
       
       db.Create(item)
       items = append(items, item)
   }

6. 返回 (items, nil)
```

**异常流程**:

- **CMDB 返回空列表**: 创建空的 ResourceApply（Status=DRAFT），无 ApplyItem → 返回空列表，前端提示"参考机房无资源数据"
- **CMDBClient 调用超时/重试3次失败**: 返回 ErrCMDBAPIFailed，不创建任何记录
- **DB 创建 ResourceApply 失败**: 返回错误，不创建 ApplyItem
- **ownerGroup/opsGroup 配置不存在**: ConfigCenter.GetRealValue 返回空字符串，CMDB 接口可能允许空值

**边界情况**:

- **同一集群有不同规格的节点**: 取第一个节点的 CPU/Memory/Disk（参考机房通常同集群规格统一），用户可在前端修改
- **NodeCount 可被用户修改**: InitApply 从参考机房取默认值，用户 UpdateApplyItem 可改为其他数量
- **IPs 字段**: InitApply 时为空字符串（尚未交付），提交后 CMDB 交付时回填 IP 列表

#### Step 5.2: ConfirmAndSubmit 详细逻辑流程

**输入**: `flowID`

**前置条件**:
- 资源申请环节已触发（FlowPhase.RESOURCE_APPLY.Status = RUNNING）
- ResourceApply 记录存在且 Status = DRAFT（待确认状态）
- ResourceApplyItem 中至少有1条记录

**正常流程**:

```
1. 查询 ResourceApply WHERE flowID=参数，确认 Status=DRAFT
   若 Status!=DRAFT → 返回错误 ErrParamInvalid，提示"申请已提交，不可重复提交"
2. 查询 ResourceApplyItem WHERE applyID=ResourceApply.ID，获取所有待提交的集群列表
3. 逐个集群提交到 CMDB:
   遍历 items 列表，对每个集群:
   a. 构造 CMDB 提交请求体:
      从 ResourceApplyItem 组装:
        {
          cluster_name: item.ClusterName,
          idc:          item.IDC,
          env:          item.Env,
          node_count:   item.NodeCount,
          cpu:          item.CPU,
          memory:      item.Memory,
          disk:         item.Disk,
          mw_type:     item.MWType
        }
   b. 调用 CMDBClient.SubmitResource(clusterName, item)
      超时30秒，重试3次间隔5秒
    c. 提交成功 → 更该 item.DeliverStatus = "SUBMITTED", item.FailReason = ""（清空旧失败原因）
    d. 提交失败 → 更该 item.DeliverStatus = "SUBMIT_FAILED"
       item.FailReason = err.Error()  // 记录具体失败原因到FailReason字段
       继续提交下一个集群（不中断，部分失败不阻塞后续）

4. 提交完成后汇总结果:
   - 全部成功 → ResourceApply.Status = SUBMITTED
   - 部分失败 → ResourceApply.Status = PARTIAL_SUBMITTED
   - 全部失败 → ResourceApply.Status = SUBMIT_FAILED（不回滚已成功的）
5. 若 ResourceApply.Status 为 SUBMITTED 或 PARTIAL_SUBMITTED:
   调用 FlowEngine.CompletePhase(flowID, RESOURCE_APPLY)
6. WebSocket PushStatus 推送流程状态更新
7. 返回提交结果汇总:
   {
     total: 5,
     success: 4,
     failed: 1,
     failed_clusters: [{cluster_name, reason}]
   }
```

**异常流程**:

- **单集群提交失败**: 标记该集群 SUBMIT_FAILED+失败原因，继续提交下一个集群（不中断）
- **CMDBClient.SubmitResource 调用超时/报错**: 重试3次后仍失败 → 标记 SUBMIT_FAILED，继续下一个
- **全部集群提交失败**: ResourceApply.Status = SUBMIT_FAILED，不调用 FlowEngine.CompletePhase（环节不推进）
- **部分集群提交失败**: ResourceApply.Status = PARTIAL_SUBMITTED，仍然调用 CompletePhase 推进环节
- **重复调用**（ResourceApply.Status != DRAFT）: 返回错误 ErrParamInvalid，提示"申请已提交，不可重复提交"

**边界情况**:

- **items列表为空**: 返回错误 ErrParamInvalid，提示"无集群数据，请先初始化资源申请"
- **用户对失败集群单独重试**: 独立接口 POST /api/v1/resource/items/:id/retry，仅重新提交该集群，成功后更新 DeliverStatus = SUBMITTED
- **幂等性**: cluster_name + idc 唯一索引防止重复创建；CMDB端幂等则重复提交无副作用

**执行后数据状态**:

- ResourceApply.Status: SUBMITTED / PARTIAL_SUBMITTED / SUBMIT_FAILED
- 每个 ResourceApplyItem.DeliverStatus: SUBMITTED 或 SUBMIT_FAILED
- FlowPhase(RESOURCE_APPLY).Status: DONE（至少部分提交成功时）
- WebSocket 已推送状态更新

**ResourceApply.Status 完整枚举**:
- `DRAFT`: 初始状态，用户可修改/删除/新增条目
- `SUBMITTED`: 全部集群提交成功，FlowPhase(RESOURCE_APPLY)推进到DONE
- `PARTIAL_SUBMITTED`: 部分集群成功+部分失败，FlowPhase(RESOURCE_APPLY)仍推进到DONE
- `SUBMIT_FAILED`: 全部集群提交失败，FlowPhase(RESOURCE_APPLY)不推进

#### UpdateApplyItem 详细逻辑流程

**输入**: `item *model.ResourceApplyItem`（含 ID 和要更新的字段）

**前置条件**:
- ResourceApply.Status = DRAFT（只有待确认状态才允许修改）

**正常流程**:

```
1. 查询 ResourceApplyItem WHERE ID = item.ID
   若不存在 → 返回 ErrParamInvalid "申请条目不存在"
2. 通过 item.ApplyID 查询 ResourceApply WHERE ID = item.ApplyID
   若 Status != DRAFT → 返回 ErrParamInvalid "申请已提交，不可修改"
3. 更新允许修改的字段:
   允许修改: ClusterName, MWType, IDC, Env, NodeCount, CPU, Memory, Disk
   不可修改: ApplyID, IPs(尚未交付), DeliverStatus, FailReason, Status
4. db.Save(item)
5. 返回 nil
```

**异常流程**:

- **ResourceApply.Status != DRAFT**: 返回 ErrParamInvalid "申请已提交，不可修改"
- **item.ID 为 0 或不存在**: 返回 ErrParamInvalid "申请条目不存在"

**边界情况**:

- **IPs 字段不允许修改**: IPs 由 CMDB 交付后回填，用户不可手动修改
- **DeliverStatus 不允许修改**: 系统自动管理，用户不可手动修改
- **Status 不允许修改**: ENABLE/DISABLE 由 DeleteApplyItem 控制

#### DeleteApplyItem 详细逻辑流程

**输入**: `itemID uint64`

**前置条件**:
- ResourceApply.Status = DRAFT（只有待确认状态才允许删除）

**正常流程**:

```
1. 查询 ResourceApplyItem WHERE ID = itemID
   若不存在 → 返回 ErrParamInvalid "申请条目不存在"
2. 通过 item.ApplyID 查询 ResourceApply WHERE ID = item.ApplyID
   若 Status != DRAFT → 返回 ErrParamInvalid "申请已提交，不可删除"
3. 逻辑删除: db.Model(item).Update("status", "DISABLE")
   ★ ResourceApplyItem 新增 Status 字段: `gorm:"size:16;default:ENABLE"`
   逻辑删除设 Status=DISABLE, 查询时过滤 Status!=DISABLE
4. 返回 nil
```

**异常流程**:

- **ResourceApply.Status != DRAFT**: 返回 ErrParamInvalid "申请已提交，不可删除"
- **itemID 不存在**: 返回 ErrParamInvalid "申请条目不存在"

**边界情况**:

- **逻辑删除而非物理删除**: 遵守 CONSTRAINTS "逻辑删除不物理删除"
- **查询时过滤**: 所有查询 ApplyItem 的方法需加 `WHERE status != 'DISABLE'` 条件
- **唯一索引冲突**: 删除后再新增相同 ClusterName+IDC 组合，DISABLE 记录的唯一索引不冲突(ENABLE记录才计入唯一索引)

#### AddApplyItem 详细逻辑流程

**输入**: `item *model.ResourceApplyItem`（不含 ID，含 ApplyID/ClusterName/MWType/IDC 等）

**前置条件**:
- ResourceApply.Status = DRAFT（只有待确认状态才允许新增条目）
- ClusterName + IDC 组合不重复（唯一索引 idx_cluster_idc）

**正常流程**:

```
1. 通过 item.ApplyID 查询 ResourceApply WHERE ID = item.ApplyID
   若 Status != DRAFT → 返回 ErrParamInvalid "申请已提交，不可新增条目"
2. 校验必填字段:
   ClusterName: 非空 → 若为空 → ErrParamInvalid "集群名称不能为空"
   MWType: 非空, 必须为合法枚举值 → 若非法 → ErrParamInvalid "中间件类型非法"
   IDC: 非空 → 若为空 → ErrParamInvalid "机房名称不能为空"
   NodeCount: > 0 → 若 ≤ 0 → ErrParamInvalid "节点数量必须大于0"
3. 设置默认值:
   Env: 若为空 → 默认 "prod"
   IPs: 初始为空字符串（尚未交付）
   DeliverStatus: 初始 "NONE"
   FailReason: 初始为空
   Status: 默认 "ENABLE"
4. db.Create(item)
   若 Duplicate entry → 返回 ErrParamInvalid "该集群+机房组合已存在"
5. 返回 nil
```

**异常流程**:

- **ResourceApply.Status != DRAFT**: 返回 ErrParamInvalid "申请已提交，不可新增条目"
- **唯一索引冲突**: 返回 ErrParamInvalid "该集群+机房组合已存在"
- **必填字段缺失**: 返回 ErrParamInvalid + 具体提示

**边界情况**:

- **新增条目的 ApplyID**: 必须与现有 ResourceApply.ID 对应（前端从 InitApply 返回的数据中获取）
- **新增条目的 IPs**: 初始为空，提交后 CMDB 交付时回填
- **删除后重新新增相同 ClusterName+IDC**: 旧记录 Status=DISABLE 不计入唯一索引，新记录可正常创建

### Step 5.3: 核查引擎模块

- 文件: `internal/check/service.go`
  - struct: `CheckService` `{ db *gorm.DB; pool *ants.Pool; ruleSvc *admin.CheckRuleService; minio *minio.MinioClient }`
  - 函数签名:
    ```go
    func NewCheckService(db *gorm.DB, pool *ants.Pool, ruleSvc *admin.CheckRuleService, minio *minio.MinioClient) *CheckService
    func (s *CheckService) QueryDeliverStatus(ctx context.Context, flowID uint64) ([]*DeliverStatusVO, error)
      // ★ 详细逻辑见下方 "QueryDeliverStatus 详细逻辑流程" 章节
    func (s *CheckService) ExecuteCheck(ctx context.Context, flowID uint64, clusterName string) ([]*model.CheckRecord, error)
      // ★ 详细逻辑流程见下方 "ExecuteCheck 详细逻辑流程" 章节
    func (s *CheckService) GetCheckDetail(ctx context.Context, flowID uint64, clusterName string) ([]*model.CheckRecord, error)
    func (s *CheckService) GetCheckLog(ctx context.Context, recordID uint64, startLine, lineCount int) ([]string, error)
      // 调用minio.ReadLines按行分页读取日志
    ```
- 文件: `api/v1/check.go`
  ```go
  // GET    /api/v1/flows/:id/check/deliver-status   → QueryDeliverStatus
  // POST   /api/v1/flows/:id/check/execute?cluster=xxx → ExecuteCheck
  // GET    /api/v1/flows/:id/check/detail?cluster=xxx   → GetCheckDetail
  // GET    /api/v1/check/records/:id/log?start=0&count=100 → GetCheckLog
  ```
- 验收: `go test ./internal/check/... -run TestCheckService_ExecuteCheck` 通过

#### QueryDeliverStatus 详细逻辑流程

**输入**: `flowID uint64`

**前置条件**:
- 资源申请环节已完成（FlowPhase.RESOURCE_APPLY.Status = DONE）

**正常流程**:

```
1. 查询 ResourceApplyItem（通过 ResourceApply 关联）:
   a. 先查 ResourceApply: db.Where("flow_id = ?", flowID).First(&apply)
   b. 再查 ApplyItem: db.Where("apply_id = ?", apply.ID).Find(&items)

2. 调用 CMDBClient.QueryDeliveredResources(apply.RefIDC)
   查询参考机房中已实际交付的资源
   若 CMDB 调用失败 → 返回错误 ErrCMDBAPIFailed

3. 构建已交付资源的查找索引:
   deliveredMap := map[string]*CMDBDeliveredInfo{}  // key: ClusterName+IDC
   for _, res := range deliveredResources {
       key := fmt.Sprintf("%s:%s", res.ClusterName, res.IDC)
       deliveredMap[key] = &CMDBDeliveredInfo{
           ActualNodeCount: len(res.IPs),  // 实际交付的节点数
           IPs:            res.IPs,         // 实际交付的 IP 列表
       }
   }

4. 对比每个 ResourceApplyItem 的交付状态:
   results := []*DeliverStatusVO{}
   for _, item := range items {
       key := fmt.Sprintf("%s:%s", item.ClusterName, item.IDC)
       
       var deliverStatus string
       var actualCount int
       var actualIPs []string
       
       if info, ok := deliveredMap[key]; ok {
           // 该集群有交付记录
           actualCount = info.ActualNodeCount
           actualIPs = info.IPs
           
           if actualCount >= item.NodeCount {
               deliverStatus = "FULL"      // 足量交付
           } else if actualCount > 0 {
               deliverStatus = "PARTIAL"   // 部分交付
           } else {
               deliverStatus = "NONE"      // 有记录但0节点（异常）
           }
       } else {
           // 该集群无交付记录
           deliverStatus = "NONE"
           actualCount = 0
       }
       
       // 更新 ResourceApplyItem 的交付信息
       if actualCount > 0 {
           item.IPs = toJSON(actualIPs)        // JSON数组: ["10.0.0.1","10.0.0.2"]
           item.DeliverStatus = deliverStatus
           db.Save(item)  // 更新 IPs 和 DeliverStatus
       }
       
       results = append(results, &DeliverStatusVO{
           ClusterName:    item.ClusterName,
           MWType:         item.MWType,
           IDC:            item.IDC,
           DeliverStatus:  deliverStatus,
           ExpectedCount:  item.NodeCount,
           ActualCount:    actualCount,
       })
   }

5. 返回 (results, nil)
```

**异常流程**:

- **CMDB 调用失败**: 返回 ErrCMDBAPIFailed，不更新任何 ApplyItem
- **ResourceApply 不存在**: 返回 ErrParamInvalid "资源申请不存在"
- **ApplyItem 为空**: 返回空列表（前端展示"无集群数据"）
- **部分集群无交付记录**: 该集群 DeliverStatus=NONE，不影响其他集群状态判定

**边界情况**:

- **实际交付数 > 申请数**: DeliverStatus=FULL（多交付不视为异常）
- **CMDB 返回空列表**: 所有集群 DeliverStatus=NONE
- **IPs JSON 格式**: `[\"10.0.0.1\",\"10.0.0.2\",\"10.0.0.3\"]"` — 存入 ResourceApplyItem.IPs 字段，后续 ExecuteCheck 和 ExecuteDrill 从此字段解析 IP 列表

**DeliverStatus 完整枚举**:
- `NONE`: 无交付记录或0节点交付
- `PARTIAL`: 实际交付节点数 < 申请节点数
- `FULL`: 实际交付节点数 >= 申请节点数
- `SUBMIT_FAILED`: CMDB 提交失败（从 ConfirmAndSubmit 设置）

#### ExecuteCheck 详细逻辑流程

**输入**: `flowID`, `clusterName`

**前置条件**:
- 资源核查环节已触发（FlowPhase.CHECK.Status = RUNNING）
- 该集群有对应的 ResourceApplyItem 记录（含 MWType 字段）
- OpsClient SSH连接凭据:
  - ssh_user: 从 ConfigCenter.Get("ssh_user", "ops") 获取
  - ssh_private_key: 从 ConfigCenter.Get("ssh_private_key", "ops") 获取
  - 连接前先校验凭据非空, 空则返回 ErrSSHAuthFailed
  - 每次连接重新读取(支持运行时更换密钥)

**正常流程**:

```
1. 从 ResourceApplyItem 表查询 flowID=参数 且 clusterName=参数 的记录，获取 mwType 和 IPs(已交付IP列表)
2. 调用 CheckRuleService.MatchRules(clusterName, mwType)，获取三层规则列表
   返回: COMMON规则[] + MW_TYPE规则[] + CLUSTER规则[]（按 Scope+Sort 排序）
3. DELETE check_record WHERE flowID=参数 AND clusterName=参数（允许重新核查，覆盖旧结果）
4. 串行执行三层规则，层间顺序严格: COMMON → MW_TYPE → CLUSTER
   每层内部也串行执行，按 Sort 字段排序
   
   对每条规则:
   a. 创建 CheckRecord 记录，Status=RUNNING, Result=""
   b. 根据 CheckType 分发执行:
       - API类型:
         从 CheckContent JSON 解析: {url, method, headers, body, params}
         构造 HTTP 请求发送，超时30秒
         根据 JudgeRule JSON 判定结果（4种mode，见下方 JudgeRule JSON Schema）:

JudgeRule JSON Schema:
```json
{
  "mode": "status_code | json_field | keyword | value_range",
  // mode=status_code:
  "expected": 200,
  // mode=json_field:
  "field_path": "data.status",    // 支持嵌套路径: data.status, result.code
  "expected": "ok",
  // mode=keyword:
  "expected": "connection refused",  // 响应体包含此关键字则FAIL
  // mode=value_range:
  "field_path": "data.cpu_usage",
  "min": 0,
  "max": 80
}
```

      - SCRIPT类型:
         从 CheckContent JSON 解析: {script_type(shell/python), script_content}
         从 ResourceApplyItem.IPs JSON数组获取全部节点IP
         若IPs为空 → 该规则Result=FAIL, Detail="no available nodes for script execution"
         
         遍历全部IPs, 在每个节点上SSH执行脚本:
         a. SSH连接: ip + ConfigCenter.Get("ssh_user","ops") + ConfigCenter.Get("ssh_private_key","ops")
         b. 设置60秒超时: session.SetDeadline(time.Now().Add(60*time.Second))
         c. 执行: session.Run(scriptContent)
         d. 收集: stdout + stderr
         e. 单节点结果判定(同JudgeRule 4种mode):
            - status_code: 不适用于SCRIPT(固定视为200, 除非SSH连接失败)
            - json_field: 解析stdout为JSON, 取field_path值与expected对比
            - keyword: stdout包含expected关键字则PASS
            - value_range: 解析stdout为JSON, 取field_path值在[min,max]内则PASS
         f. 记录到 nodeResults[]: [{ip, result(PASS/FAIL), output, error}]
         
         全部节点执行完毕后汇总:
         - 全部节点PASS → 规则Result=PASS
         - 任意节点FAIL → 规则Result=FAIL
         - Detail = JSON: {nodes: [{ip, result, output, error}], overall_result}
   c. 更新 CheckRecord:
      - Result = PASS 或 FAIL
      - Detail = JSON: 判定详情(实际值 vs 期望值; 多节点时记录每个节点结果)
      - LogFilePath = MinIO路径(check/{flowID}/{clusterName}_{ruleID}_{timestamp}.log)
      - ExecuteTime = now
   d. 将完整执行日志(API响应内容/脚本stdout+stderr)上传到 MinIO log-bucket
   
5. 汇总所有 CheckRecord，返回结果列表
```

**异常流程**:

- **单条规则FAIL**: 记录Result=FAIL，**继续执行后续规则**（不中断，不跳过本层后续，不跳过下一层）
- **单条规则执行报错**（SSH连接失败、HTTP请求超时等）: 记录Result=FAIL，Detail记录错误原因，继续执行后续规则
- **SCRIPT类型60秒超时**: SSH Session设置Deadline(now+60s)，超时后该节点Result=FAIL，Detail="script execution timeout after 60s"，继续执行其他节点
- **SCRIPT类型节点执行**: 在全部节点上分别执行；某节点FAIL不影响其他节点继续执行；汇总后任意节点FAIL→规则FAIL
- **某层规则列表为空**（MW_TYPE层或CLUSTER层无匹配规则）: 直接跳过该层，进入下一层
- **COMMON层规则列表为空**: 仍然继续执行MW_TYPE层和CLUSTER层
- **JudgeRule JSON格式错误**: Result=FAIL，Detail="invalid judge_rule format"

**边界情况**:

- **重复触发**: DELETE旧CheckRecord后重新执行全部规则（允许重新核查，覆盖旧结果）
- **clusterName无匹配的ResourceApplyItem**: 返回错误 ErrParamInvalid，提示"集群不存在"
- **核查全部规则PASS**: 前端根据CheckRecord判断该集群核查通过
- **核查有任意规则FAIL**: 前端判断该集群核查不通过；不影响其他集群的核查
- **SCRIPT类型目标节点为空**（IPs列表为空，即资源尚未交付）: 该规则Result=FAIL，Detail="no available nodes for script execution"

**执行后数据状态**:

- CheckRecord表: 每条规则1条记录，含Scope/Result/Detail/LogFilePath/ExecuteTime
- MinIO log-bucket: 每条规则1个日志文件
- 旧的CheckRecord已被删除（重新核查覆盖）

---

## Phase 6: 业务模块 — 部署与监控

**必须在 Phase 5 完成后执行（核查模块是部署的前置依赖）**

### Step 6.1: 中间件部署适配器

- 文件: `internal/adapter/deploy/client.go`
  - struct: `DeployClient` `{ baseURL string; timeout time.Duration }`
  - 函数签名:
    ```go
    func NewDeployClient(cfg *config.DeployServiceConfig) *DeployClient
    func (c *DeployClient) TriggerDeploy(clusterName, mwType string, ips []string, params map[string]any) (taskID string, error)
      // POST到中间件部署服务, 返回任务ID
    func (c *DeployClient) GetDeployStatus(taskID string) (*DeployStatusResult, error)
      // GET查询部署状态(VALIDATING/DEPLOYING/VERIFYING/DONE/FAILED)
    func (c *DeployClient) GetDeployStageLog(taskID string, stage string) ([]byte, error)
      // GET获取某阶段日志内容
    func (c *DeployClient) RetryDeploy(taskID string) error
    ```
  - type: `DeployStatusResult` `{ TaskID, Status, Stages []StageStatus }`

#### DeployClient HTTP 调用详细逻辑

**通用模式**: DeployClient 所有 HTTP 方法遵循统一模式: http.Client 超时控制 + 无重试(非幂等POST不重试) + 错误码映射

**http.Client 配置**:

```
// DeployClient 内部共享一个 http.Client
httpClient := &http.Client{
    Timeout: 30 * time.Second,  // 连接+读写总超时30秒
}
```

**TriggerDeploy 详细逻辑**:

```
输入: clusterName, mwType, ips, params

1. 构造请求体:
   requestBody := map[string]any{
       "cluster_name": clusterName,
       "mw_type":      mwType,
       "ips":           ips,
       "params":        params,
   }
   bodyBytes, _ := json.Marshal(requestBody)

2. 构造 HTTP 请求:
   url := fmt.Sprintf("%s/api/deploy/trigger", c.baseURL)
   req, _ := http.NewRequestWithContext(ctx, "POST", url, bytes.NewReader(bodyBytes))
   req.Header.Set("Content-Type", "application/json")

3. 发送请求(无重试, POST非幂等):
   resp, err := c.httpClient.Do(req)
   若 err != nil → 返回 ("", ErrAPICallFailed "部署触发接口调用失败: " + err.Error())
   
4. 读取响应:
   respBytes, _ := io.ReadAll(resp.Body)
   resp.Body.Close()

5. 状态码映射:
   若 resp.StatusCode == 200 → 解析响应JSON, 获取 taskID 字段 → 返回 (taskID, nil)
   若 resp.StatusCode == 400 → 返回 ("", ErrParamInvalid "部署参数非法")
   若 resp.StatusCode == 500 → 返回 ("", ErrAPICallFailed "部署服务内部错误")
   其他状态码 → 返回 ("", ErrAPICallFailed fmt.Sprintf("部署服务返回异常状态码: %d", resp.StatusCode))
```

**GetDeployStatus 详细逻辑**:

```
输入: taskID

1. 构造 HTTP 请求:
   url := fmt.Sprintf("%s/api/deploy/status/%s", c.baseURL, taskID)
   req, _ := http.NewRequestWithContext(ctx, "GET", url, nil)

2. 发送请求(GET幂等, 允许重试但本平台轮询间隔10秒已覆盖):
   resp, err := c.httpClient.Do(req)
   若 err != nil → 返回 (nil, ErrAPICallFailed "查询部署状态失败: " + err.Error())
   
3. 解析响应:
   若 resp.StatusCode != 200 → 返回 (nil, ErrAPICallFailed "查询部署状态返回非200")
   解析为 DeployStatusResult: {TaskID, Status, Stages[]}
   → 返回 (result, nil)
```

**GetDeployStageLog 详细逻辑**:

```
输入: taskID, stage

1. url := fmt.Sprintf("%s/api/deploy/status/%s/log?stage=%s", c.baseURL, taskID, stage)
2. GET请求, 30秒超时
3. 若 resp.StatusCode != 200 → 返回 (nil, ErrAPICallFailed)
4. 返回 (io.ReadAll(resp.Body), nil) — 日志内容为原始字节
```

**RetryDeploy 详细逻辑**:

```
输入: taskID

1. url := fmt.Sprintf("%s/api/deploy/retry/%s", c.baseURL, taskID)
2. POST请求, 无重试(非幂等)
3. 若 resp.StatusCode != 200 → 返回 ErrAPICallFailed
4. 返回 nil
```

**异常流程**:

- **http.Client.Do 超时**: 30秒内无响应 → 返回 ErrAPICallFailed "接口调用超时"
- **响应JSON解析失败**: 返回 ErrAPICallFailed "响应格式非法"
- **baseURL 为空**: 初始化时校验, 空值则 NewDeployClient 返回错误

**边界情况**:

- **POST请求不重试**: TriggerDeploy/RetryDeploy 为非幂等POST, 调用失败直接返回错误(用户手动重试)
- **GET请求可容忍短暂失败**: 轮询goroutine中GetDeployStatus失败时不标记FAILED, 10秒后重试
- **所有状态码都映射为错误码**: 不允许弱模型自行判断200/404等, 必须按上述映射表处理

### Step 6.2: 服务部署模块

- 文件: `internal/deploy/service.go`
  - struct: `DeployService` `{ db *gorm.DB; deployClient *adapter.DeployClient; configSvc *admin.DeployConfigService; activeTasks sync.Map }`
  - 函数签名:
    ```go
    func NewDeployService(db *gorm.DB, dc *adapter.DeployClient, cs *admin.DeployConfigService) *DeployService
    func (s *DeployService) GetCheckedClusters(ctx context.Context, flowID uint64, mwType string) ([]*ClusterDeployVO, error)
      // 查核查通过的集群, 按mwType筛选, 返回集群列表+部署参数(从DeployConfig匹配)
      // "核查通过"定义: 该集群所有CheckRecord.Result均为PASS（无FAIL记录）
    func (s *DeployService) TriggerDeploy(ctx context.Context, flowID uint64, clusterName string) error
      // ★ 详细逻辑流程见下方 "TriggerDeploy 详细逻辑流程" 章节
    func (s *DeployService) RetryDeploy(ctx context.Context, deployID uint64) error
    func (s *DeployService) GetDeployDetail(ctx context.Context, flowID uint64, clusterName string) (*DeployDetailVO, error)
      // 返回三阶段状态 + 各阶段日志MinIO路径
    func (s *DeployService) GetStageLog(ctx context.Context, deployID uint64, stage string, startLine, lineCount int) ([]string, error)
    ```

#### DeployDetailVO 结构体定义与查询逻辑

```go
type DeployDetailVO struct {
    DeployID    uint64           `json:"deploy_id"`
    FlowID      uint64           `json:"flow_id"`
    ClusterName string           `json:"cluster_name"`
    MWType      string           `json:"mw_type"`
    TaskID      string           `json:"task_id"`
    Status      string           `json:"status"`       // PENDING/VALIDATING/.../DONE/FAILED
    Params      string           `json:"params"`       // JSON: 部署参数
    RetryCount  int              `json:"retry_count"`
    StartTime   *time.Time       `json:"start_time"`
    EndTime     *time.Time       `json:"end_time"`
    Stages      []*DeployStageVO `json:"stages"`       // 三阶段状态
}

type DeployStageVO struct {
    Stage       string           `json:"stage"`         // VALIDATE/DEPLOY/VERIFY
    Status      string           `json:"status"`        // PENDING/RUNNING/DONE/FAILED
    LogFilePath string           `json:"log_file_path"` // MinIO日志路径
    StartTime   *time.Time       `json:"start_time"`
    EndTime     *time.Time       `json:"end_time"`
    SignedURL   string           `json:"signed_url"`    // MinIO签名链接(1小时有效), 前端可直接下载
}
```

**GetDeployDetail 查询逻辑**:

```
1. 查询 DeployRecord WHERE flow_id=flowID AND cluster_name=clusterName
   若不存在 → 返回 (nil, ErrParamInvalid "部署记录不存在")

2. 查询 DeployStageLog WHERE deploy_id=record.ID, ORDER BY stage
   3条记录: VALIDATE, DEPLOY, VERIFY

3. 对每条 StageLog:
   若 LogFilePath 非空 → 生成MinIO签名链接:
   signedURL, err := minioClient.GetSignedURL("log-bucket", stageLog.LogFilePath, 1*time.Hour)
   若生成失败 → signedURL="" (不阻断主流程)

4. 构造 DeployDetailVO:
   - 从 DeployRecord 取基础字段
   - Stages[] 从 DeployStageLog 构造, 含 signedURL

5. 返回 (vo, nil)
```

**GetStageLog 查询逻辑**:

```
1. 查询 DeployStageLog WHERE deploy_id=deployID AND stage=stage
   若不存在 → 返回 ([]string{}, ErrParamInvalid "阶段日志不存在")

2. 若 LogFilePath 为空 → 返回 ([]string{}, nil)  // 该阶段尚未开始

3. 调用 MinioClient.ReadLines("log-bucket", stageLog.LogFilePath, startLine, lineCount)
   lineCount 固定传 100 (CONSTRAINTS: 日志分页100行/页)

4. 返回 (lines, nil)
```

- 文件: `api/v1/deploy.go`
  ```go
  // GET    /api/v1/flows/:id/deploy/clusters?mw_type=xxx     → GetCheckedClusters
  // POST   /api/v1/flows/:id/deploy/trigger?cluster=xxx       → TriggerDeploy
  // POST   /api/v1/deploy/:id/retry                            → RetryDeploy
  // GET    /api/v1/flows/:id/deploy/detail?cluster=xxx         → GetDeployDetail
  // GET    /api/v1/deploy/:id/log?stage=xxx&start=0&count=100  → GetStageLog
  ```
- 验收: `go test ./internal/deploy/... -run TestDeployService_TriggerDeploy` 通过

#### TriggerDeploy 详细逻辑流程

**输入**: `flowID`, `clusterName`

**前置条件**:
- 服务部署环节已触发（FlowPhase.DEPLOY.Status = RUNNING）
- 该集群核查通过（至少存在CheckRecord且全部Result=PASS）
- 该集群有对应的 ResourceApplyItem（含 IPs 和 MWType）

**正常流程**:

```
1. 查询 ResourceApplyItem WHERE flowID=参数 AND clusterName=参数，获取 IPs 和 MWType
2. 查询是否已存在 DeployRecord WHERE flowID AND clusterName AND Status NOT IN (FAILED, PENDING)
   若存在 → 返回错误 ErrDeployRetrying，提示"集群正在部署中，不可重复触发"
3. 调用 DeployConfigService.MatchConfig(clusterName) 匹配部署参数配置
   获取 DeployConfig.Params JSON，解析为参数列表 [{name, default, widget_type}]
   若无匹配 → 使用空参数 {} 提交（中间件部署服务有默认参数，不阻塞）
4. 创建 DeployRecord:
   - FlowID = 参数, ClusterName = 参数, MWType = item.MWType
   - Status = PENDING, Params = 参数JSON, StartTime = now
5. 创建 3条 DeployStageLog:
   - Stage=VALIDATE/DEPLOY/VERIFY, DeployID=上述记录ID, Status=PENDING
6. 调用 DeployClient.TriggerDeploy(clusterName, mwType, IPs, params)
   返回 taskID
 7. 将 taskID 存入 DeployRecord（TaskID 字段）
 8. 启动后台 goroutine 轮询部署状态:

    goroutine入口:
    go func() {
        defer func() {
            if r := recover(); r != nil {
                log.Printf("[DEPLOY] goroutine panic: flowID=%d, cluster=%s, panic=%v", flowID, clusterName, r)
                // 更新DeployRecord.Status=FAILED, FailReason=panic信息, EndTime=now
                // 上传panic堆栈到MinIO
                // WebSocket.PushStatus(flowID, "部署异常中断")
            }
        }()
        defer s.activeTasks.Delete(fmt.Sprintf("%d-%s", flowID, clusterName))
        
        ctx, cancel := context.WithCancel(context.Background())
        s.activeTasks.Store(fmt.Sprintf("%d-%s", flowID, clusterName), cancel)
        
        maxPollCount = 360, pollInterval = 10s, 总最长等待1小时
   
    for i := 0; i < maxPollCount; i++ {
      // 每次循环前检查是否被取消
      select { case <-ctx.Done(): return; default: }
      
      result := DeployClient.GetDeployStatus(taskID)
     
     result.Status == "VALIDATING":
       DeployRecord.Status = VALIDATING
       DeployStageLog(VALIDATE).StartTime = now
     
     result.Status == "DEPLOYING":
       DeployRecord.Status = DEPLOYING
       DeployStageLog(VALIDATE).EndTime = now, Status = DONE
       DeployStageLog(DEPLOY).StartTime = now
       logContent := DeployClient.GetDeployStageLog(taskID, "VALIDATE")
       Minio.Upload(log-bucket, "deploy/{flowID}/{clusterName}_validate_{taskID}.log", logContent)
       DeployStageLog(VALIDATE).LogFilePath = MinIO路径
     
     result.Status == "VERIFYING":
       DeployRecord.Status = VERIFYING
       DeployStageLog(DEPLOY).EndTime = now, Status = DONE
       DeployStageLog(VERIFY).StartTime = now
       logContent := DeployClient.GetDeployStageLog(taskID, "DEPLOY")
       Minio.Upload(log-bucket, "deploy/{flowID}/{clusterName}_deploy_{taskID}.log", logContent)
       DeployStageLog(DEPLOY).LogFilePath = MinIO路径
     
     result.Status == "DONE":
       DeployRecord.Status = DONE, EndTime = now
       DeployStageLog(VERIFY).EndTime = now, Status = DONE
       logContent := DeployClient.GetDeployStageLog(taskID, "VERIFY")
       Minio.Upload(log-bucket, "deploy/{flowID}/{clusterName}_verify_{taskID}.log", logContent)
       DeployStageLog(VERIFY).LogFilePath = MinIO路径
       WebSocket.PushStatus(flowID, 状态更新)
       return
     
     result.Status == "FAILED":
       DeployRecord.Status = FAILED, EndTime = now
       当前所在StageLog.Status = FAILED
       上传当前阶段日志到MinIO
       FlowEngine.FailPhase(flowID, DEPLOY, "deploy failed: " + taskID)
       WebSocket.PushStatus(flowID, 状态更新)
       return
     
     网络错误(err != nil): 跳过本次，10秒后重试（不标记失败）
     WebSocket.PushStatus(flowID, 部署进度更新)
     time.Sleep(pollInterval)
   }
   
   超时(maxPollCount耗尽):
     DeployRecord.Status = FAILED
     FlowEngine.FailPhase(flowID, DEPLOY, "deploy polling timeout after 1 hour")
     WebSocket.PushStatus(flowID, 超时通知)

9. 立即返回 DeployRecord（Status=PENDING，后台轮询异步更新）
```

**异常流程**:

- **DeployClient.TriggerDeploy 调用失败**: DeployRecord.Status = FAILED，返回错误给用户
- **DeployClient.GetDeployStatus 网络错误**: 不标记失败，跳过本次轮询，10秒后重试
- **部署服务返回 FAILED**: DeployRecord.Status=FAILED，上传失败阶段日志到MinIO，FailPhase，WebSocket推送
- **轮询超时**（1小时360次耗尽）: DeployRecord.Status=FAILED，FailPhase("deploy polling timeout")
- **MatchConfig 无匹配**: 使用空参数{}提交，不阻塞

**边界情况**:

- **DeployRecord.Status=FAILED时允许重新触发**: 删除旧DeployRecord+DeployStageLog，创建新记录重新触发
- **每阶段完成时立即上传日志到MinIO**: 前端可实时查看已完成阶段的日志，不等全部完成
- **MinIO日志路径**: deploy/{flowID}/{clusterName}_{stage}_{taskID}.log

**执行后数据状态**:

- DeployRecord: Status根据部署进度动态更新(PENDING→VALIDATING→DEPLOYING→VERIFYING→DONE/FAILED)
- DeployStageLog: 3条记录，每条随进度更新StartTime/EndTime/Status/LogFilePath
- MinIO log-bucket: 每阶段完成时上传1个日志文件（最多3个）
- WebSocket: 每次状态变更时推送进度更新

#### TriggerDeploy 重启恢复逻辑

**触发时机**: main.go启动时, 数据库初始化完成后

```
1. 查询未完成的部署任务:
   SELECT * FROM deploy_record WHERE status IN ('PENDING','VALIDATING','DEPLOYING','VERIFYING')
2. 对每条记录:
   a. 若 TaskID 为空 → Status=FAILED, FailReason="task not submitted before restart"
   b. 若 TaskID 非空 → 重新启动后台轮询goroutine (同TriggerDeploy第8步)
      传入已有的taskID, 继续轮询直到完成或超时
3. 记录恢复日志: "恢复部署任务: flowID=%d, cluster=%s, taskID=%s, 当前status=%s"
```

#### GetCheckedClusters 详细逻辑流程

**输入**: `flowID uint64`, `mwType string`（可选筛选）

**前置条件**:
- 核查环节已完成（FlowPhase.CHECK.Status = DONE）

**正常流程**:

```
1. 查询 ResourceApplyItem (通过 ResourceApply 关联 flowID):
   a. 查 ResourceApply: db.Where("flow_id = ?", flowID).First(&apply)
   b. 查 ApplyItem: db.Where("apply_id = ? AND status != 'DISABLE'", apply.ID).Find(&items)
   
   若 mwType != "" → 在查询 ApplyItem 时加条件: db.Where("mw_type = ?", mwType)

2. 对每个 item, 判定该集群核查是否通过:
   "核查通过"定义: 该集群所有 CheckRecord.Result 均为 PASS（无 FAIL 记录）
   
   ★ 推荐方案: 子查询(单次DB查询更高效):
   
   // 查询该 flowID 下所有存在 FAIL 记录的集群名称
   failClusterNames := []string{}
   db.Model(&model.CheckRecord{}).
     Where("flow_id = ? AND result = 'FAIL'", flowID).
     Distinct("cluster_name").
     Pluck("cluster_name", &failClusterNames)
   
   // 过滤掉核查失败的集群
   for _, item := range items {
     if !contains(failClusterNames, item.ClusterName) {
       passedItems = append(passedItems, item)
     }
   }
   
   ★ 逐集群查询方案(简单但DB查询多, 不推荐):
   for each item:
     failCount := db.Model(&CheckRecord{}).
       Where("flow_id = ? AND cluster_name = ? AND result = 'FAIL'", flowID, item.ClusterName).Count()
     若 failCount > 0 → 该集群核查不通过, 跳过
     若 failCount == 0 → 该集群核查通过

3. 对核查通过的集群, 匹配部署参数:
   for each passedItem:
     deployConfig := DeployConfigService.MatchConfig(passedItem.ClusterName)
     若匹配到 → params = deployConfig.Params
     若无匹配 → params = "{}"（空参数, 部署服务有默认值）

4. 构造返回 VO:
   ClusterDeployVO:
   - ClusterName: item.ClusterName
   - MWType: item.MWType
   - NodeCount: item.NodeCount
   - IPs: item.IPs（已交付IP列表JSON）
   - DeployConfigID: deployConfig.ID（若有匹配, 0表示无匹配）
   - Params: deployConfig.Params（部署参数JSON, 若无匹配则为 "{}"）

5. 返回 (voList, nil)
```

**异常流程**:

- **ResourceApply 不存在**: 返回 ErrParamInvalid "资源申请不存在"
- **ApplyItem 为空**: 返回空列表
- **mwType筛选后无匹配集群**: 返回空列表

**边界情况**:

- **全部集群核查都不通过**: 返回空列表（前端提示"无核查通过的集群"）
- **部分集群核查通过**: 只返回通过的集群
- **DeployConfig无匹配**: Params="{}", 前端展示"使用默认参数"
- **核查通过的判定**: 该集群**所有** CheckRecord.Result=PASS 才算通过；只要有1条FAIL就不通过

#### RetryDeploy 详细逻辑流程

**输入**: `deployID uint64`（DeployRecord.ID）

**前置条件**:
- DeployRecord 存在且 Status = FAILED（只有失败记录才允许重试）

**正常流程**:

```
1. 查询 DeployRecord WHERE ID = deployID
   若不存在 → 返回 ErrParamInvalid "部署记录不存在"
   若 Status != FAILED → 返回 ErrParamInvalid "只有失败的部署才允许重试"

2. 判断 taskID 是否存在:
   a. 若 TaskID 非空 → 调用外部服务的重试API:
      - 调用 DeployClient.RetryDeploy(taskID)
      ★ RetryDeploy 调用外部服务的重试API(非本地重新触发)
      外部服务保留原有 taskID, 从失败点继续执行
      若调用失败 → DeployRecord.Status=FAILED, 返回 ErrAPICallFailed
      
      - 更新 DeployRecord:
        RetryCount = RetryCount + 1
        Status = PENDING（重置为待处理）
        StartTime = now
      
      - 更新 DeployStageLog (3条记录):
        Status = PENDING（重置每阶段状态）
        StartTime = nil, EndTime = nil（重置时间）
        LogFilePath = ""（清空旧日志路径）
      
      - 启动后台轮询 goroutine（同 TriggerDeploy 第8步）:
        使用原有 taskID 继续轮询
        maxPollCount = 360, pollInterval = 10s
        goroutine生命周期管理同TriggerDeploy(context+activeTasks+panic recovery)
      
      - WebSocket.PushStatus(flowID, "部署重试已触发")
      
   b. 若 TaskID 为空 → 从头重新触发(本地重新TriggerDeploy):
      ★ taskID为空说明部署服务未返回任务ID就失败了(如TriggerDeploy调用失败)
      此时不能调用RetryDeploy(外部服务无任务记录), 需要重新触发
      
      - 删除旧 DeployRecord + DeployStageLog:
        db.Where("deploy_id = ?", deployID).Delete(&DeployStageLog{})
        db.Delete(&DeployRecord{}, deployID)
      
      - 调用 TriggerDeploy(flowID, clusterName) 从头重新触发
      ★ TriggerDeploy 会创建新的 DeployRecord + DeployStageLog + 调用外部服务
      
      - 返回 TriggerDeploy 的结果

3. 返回 nil
```

**异常流程**:

- **DeployRecord.Status 不是 FAILED**: 返回 ErrParamInvalid "只有失败的部署才允许重试"
- **DeployClient.RetryDeploy 调用失败**: 返回 ErrAPICallFailed
- **TriggerDeploy 调用失败(taskID为空场景)**: 返回 TriggerDeploy 的错误
- **RetryCount 上限**: 不设硬上限, 允许用户多次重试（每次重试递增RetryCount）

**边界情况**:

- **taskID非空 → RetryDeploy**: 外部服务从失败点继续, 保留原taskID
- **taskID为空 → 重新TriggerDeploy**: 从头开始, 生成新taskID
- **两个路径的区别**:
  RetryDeploy: 外部服务保留原有进度, 从失败阶段继续
  TriggerDeploy: 外部服务全新任务, 从头开始三阶段
- **RetryCount 只在 RetryDeploy 路径递增**: TriggerDeploy 路径创建新记录, RetryCount=0

### Step 6.3: 监控部署适配器

- 文件: `internal/adapter/monitor/client.go`
  - struct: `MonitorClient` `{ baseURL string; timeout time.Duration; httpClient *http.Client }`
  - 函数签名:
    ```go
    func NewMonitorClient(cfg *config.MonitorServiceConfig) *MonitorClient
    func (c *MonitorClient) TriggerDeploy(ips []string) (taskID string, error)
    func (c *MonitorClient) GetDeployStatus(taskID string) (*MonitorDeployResult, error)
    func (c *MonitorClient) GetDeployLog(taskID string) ([]byte, error)
    func (c *MonitorClient) TriggerConfig(clusterNames []string, mwType string) (taskID string, error)
    func (c *MonitorClient) GetConfigStatus(taskID string) (*MonitorConfigResult, error)
    func (c *MonitorClient) GetConfigDetail(taskID string) ([]byte, error)
    ```

#### MonitorClient HTTP 调用详细逻辑

**通用模式**: 与 DeployClient 完全一致: http.Client{Timeout: 30s} + POST不重试 + GET可容忍短暂失败 + 状态码映射

**TriggerDeploy 详细逻辑**:

```
输入: ips []string

1. 构造请求体: requestBody := map[string]any{"ips": ips}
2. url := fmt.Sprintf("%s/api/monitor/deploy/trigger", c.baseURL)
3. POST请求, 30秒超时, 无重试(非幂等)
4. 若 resp.StatusCode == 200 → 解析JSON获取taskID → 返回 (taskID, nil)
5. 其他状态码 → 返回 ("", ErrAPICallFailed + 状态码信息)
```

**TriggerConfig 详细逻辑**:

```
输入: clusterNames []string, mwType string

1. 构造请求体: requestBody := map[string]any{"cluster_names": clusterNames, "mw_type": mwType}
2. url := fmt.Sprintf("%s/api/monitor/config/trigger", c.baseURL)
3. POST请求, 30秒超时, 无重试(非幂等)
4. 若 resp.StatusCode == 200 → 解析JSON获取taskID → 返回 (taskID, nil)
5. 其他状态码 → 返回 ("", ErrAPICallFailed + 状态码信息)
```

**GetDeployStatus / GetConfigStatus 详细逻辑**:

```
输入: taskID

1. url := fmt.Sprintf("%s/api/monitor/status/%s", c.baseURL, taskID)
2. GET请求, 30秒超时
3. 若 resp.StatusCode != 200 → 返回 (nil, ErrAPICallFailed)
4. 解析为 MonitorDeployResult / MonitorConfigResult → 返回 (result, nil)
```

**GetDeployLog / GetConfigDetail 详细逻辑**:

```
输入: taskID

1. url := fmt.Sprintf("%s/api/monitor/log/%s", c.baseURL, taskID)
2. GET请求, 30秒超时
3. 若 resp.StatusCode != 200 → 返回 (nil, ErrAPICallFailed)
4. 返回 (io.ReadAll(resp.Body), nil)
```

**异常流程**: 同 DeployClient — http.Client超时返回ErrAPICallFailed, POST不重试, GET可容忍

**边界情况**: MonitorClient的两个触发方法(TriggerDeploy/TriggerConfig)分别对应两个独立的轮询链路, HTTP调用模式完全对称

### Step 6.4: 监控部署模块

- 文件: `internal/monitor/service.go`
  - struct: `MonitorService` `{ db *gorm.DB; mc *adapter.MonitorClient; minio *minio.MinioClient; activeTasks sync.Map }`
  - 函数签名:
    ```go
    func NewMonitorService(db *gorm.DB, mc *adapter.MonitorClient, minio *minio.MinioClient) *MonitorService
    func (s *MonitorService) TriggerDeploy(ctx context.Context, flowID uint64, ips []string) error
      // ★ 详细逻辑流程见下方 "MonitorService 详细逻辑流程" 章节
    func (s *MonitorService) TriggerConfig(ctx context.Context, flowID uint64, clusterNames []string) error
      // ★ 同上
    func (s *MonitorService) GetDeployStatus(ctx context.Context, flowID uint64) (*MonitorDeployVO, error)
    func (s *MonitorService) GetConfigStatus(ctx context.Context, flowID uint64) (*MonitorConfigVO, error)
    func (s *MonitorService) GetDeployLog(ctx context.Context, flowID uint64, startLine, lineCount int) ([]string, error)
    func (s *MonitorService) GetConfigDetail(ctx context.Context, flowID uint64) ([]byte, error)
    ```
- 文件: `api/v1/monitor.go`
  ```go
  // POST   /api/v1/flows/:id/monitor/deploy   → TriggerDeploy (body: {ips: []})
  // POST   /api/v1/flows/:id/monitor/config    → TriggerConfig (body: {clusters: []})
  // GET    /api/v1/flows/:id/monitor/status     → GetDeployStatus + GetConfigStatus
  // GET    /api/v1/flows/:id/monitor/log?start=0&count=100  → GetDeployLog
  ```
- 验收: `go test ./internal/monitor/... -run TestMonitorService_TriggerDeploy` 通过

#### MonitorService 详细逻辑流程 (TriggerDeploy / TriggerConfig)

**TriggerDeploy 输入**: `flowID`, `ips []string`

**TriggerConfig 输入**: `flowID`, `clusterNames []string`

**前置条件**:
- 监控部署环节已触发（FlowPhase.MONITOR.Status = RUNNING）
- TriggerDeploy: ips不为空
- TriggerConfig: clusterNames不为空，且这些集群在DeployRecord中Status=DONE（已部署完成才能配置监控）

**TriggerDeploy 正常流程**:

```
1. 查询 MonitorDeploy WHERE flowID=参数
   若 DeployStatus IN (RUNNING, PENDING) → 返回错误，提示"监控部署正在进行中，不可重复触发"
   若 DeployStatus = DONE 或 FAILED → 允许重新触发（覆盖旧记录）
2. 创建/更新 MonitorDeploy 记录:
   - FlowID = 参数, IPs = JSON(ips参数), DeployStatus = PENDING, StartTime = now
3. 调用 MonitorClient.TriggerDeploy(ips)
   返回 deployTaskID
4. 将 deployTaskID 存入 MonitorDeploy（新增 DeployTaskID 字段）
 5. 启动后台 goroutine 轮询部署状态:

    goroutine入口:
    go func() {
        defer func() {
            if r := recover(); r != nil {
                log.Printf("[MONITOR-DEPLOY] panic: flowID=%d, panic=%v", flowID, r)
                MonitorDeploy.DeployStatus = FAILED, EndTime = now
                WebSocket.PushStatus(flowID, "监控部署异常中断")
            }
        }()
        defer s.activeTasks.Delete(fmt.Sprintf("monitor-deploy-%d", flowID))
        
        ctx, cancel := context.WithCancel(context.Background())
        s.activeTasks.Store(fmt.Sprintf("monitor-deploy-%d", flowID), cancel)
        
    maxPollCount = 180, pollInterval = 10s, 总最长等待30分钟
   
    for i := 0; i < maxPollCount; i++ {
      // 每次循环前检查是否被取消
      select { case <-ctx.Done(): return; default: }
      
      result := MonitorClient.GetDeployStatus(deployTaskID)
     
     result.Status == "RUNNING":
       MonitorDeploy.DeployStatus = RUNNING
     
     result.Status == "DONE":
       MonitorDeploy.DeployStatus = DONE, EndTime = now
       logContent := MonitorClient.GetDeployLog(deployTaskID)
       Minio.Upload(log-bucket, "monitor/{flowID}/deploy_{deployTaskID}.log", logContent)
       MonitorDeploy.DeployLogPath = MinIO路径
       WebSocket.PushStatus(flowID, 监控部署完成)
       return
     
     result.Status == "FAILED":
       MonitorDeploy.DeployStatus = FAILED, EndTime = now
       logContent := MonitorClient.GetDeployLog(deployTaskID)
       Minio.Upload(log-bucket, ...) // 保存失败日志
       WebSocket.PushStatus(flowID, 监控部署失败)
       return
     
     网络错误: 跳过，10秒后重试（不标记失败）
     WebSocket.PushStatus(flowID, 进度更新)
     time.Sleep(pollInterval)
   }
   
   超时(maxPollCount耗尽):
     MonitorDeploy.DeployStatus = FAILED
     WebSocket.PushStatus(flowID, 超时通知)

6. 立即返回 MonitorDeploy（DeployStatus=PENDING）
```

**TriggerConfig 正常流程**:

```
1. 查询 MonitorDeploy WHERE flowID=参数
   若 ConfigStatus IN (RUNNING, PENDING) → 返回错误，提示"监控配置正在进行中"
   若 ConfigStatus = DONE 或 FAILED → 允许重新触发（覆盖）
2. 校验: clusterNames中的每个集群在DeployRecord中Status=DONE
   若有集群未部署完成 → 返回错误，提示"集群XX尚未部署完成，无法配置监控"
3. 校验: MonitorDeploy.DeployStatus = DONE（监控服务必须先部署完成）
   若 DeployStatus != DONE → 返回错误，提示"请先完成监控服务部署"
4. 更新 MonitorDeploy.ConfigStatus = PENDING
5. 调用 MonitorClient.TriggerConfig(clusterNames, mwType)
   返回 configTaskID
6. 将 configTaskID 存入 MonitorDeploy（新增 ConfigTaskID 字段）
 7. 启动后台 goroutine 轮询配置状态:

    goroutine入口:
    go func() {
        defer func() {
            if r := recover(); r != nil {
                log.Printf("[MONITOR-CONFIG] panic: flowID=%d, panic=%v", flowID, r)
                MonitorDeploy.ConfigStatus = FAILED
                WebSocket.PushStatus(flowID, "监控配置异常中断")
            }
        }()
        defer s.activeTasks.Delete(fmt.Sprintf("monitor-config-%d", flowID))
        
        ctx, cancel := context.WithCancel(context.Background())
        s.activeTasks.Store(fmt.Sprintf("monitor-config-%d", flowID), cancel)
    
    maxPollCount = 180, pollInterval = 10s, 总最长等待30分钟
   
    for i := 0; i < maxPollCount; i++ {
      // 每次循环前检查是否被取消
      select { case <-ctx.Done(): return; default: }
      
      result := MonitorClient.GetConfigStatus(configTaskID)
     
     result.Status == "RUNNING":
       MonitorDeploy.ConfigStatus = RUNNING
     
     result.Status == "DONE":
       MonitorDeploy.ConfigStatus = DONE
       WebSocket.PushStatus(flowID, 监控配置完成)
       return
     
     result.Status == "FAILED":
       MonitorDeploy.ConfigStatus = FAILED
       WebSocket.PushStatus(flowID, 监控配置失败)
       return
     
     网络错误: 跳过，10秒后重试
     WebSocket.PushStatus(flowID, 进度更新)
     time.Sleep(pollInterval)
   }
   
   超时:
     MonitorDeploy.ConfigStatus = FAILED
     WebSocket.PushStatus(flowID, 超时通知)

8. 立即返回（ConfigStatus=PENDING）
```

**异常流程**:

- **MonitorClient调用失败**: MonitorDeploy对应Status=FAILED，返回错误
- **GetDeployStatus/GetConfigStatus网络错误**: 跳过本次，不标记失败，10秒后重试
- **外部服务返回FAILED**: 上传失败日志到MinIO，Status=FAILED，WebSocket推送
- **轮询超时**（30分钟180次耗尽）: Status=FAILED，WebSocket推送超时通知
- **重复触发**: RUNNING/PENDING状态时拒绝；DONE/FAILED状态时允许覆盖重新触发

**边界情况**:

- **TriggerDeploy和TriggerConfig独立触发**: DeployStatus和ConfigStatus分别管理，互不影响
- **TriggerConfig必须在TriggerDeploy完成之后**: 校验MonitorDeploy.DeployStatus=DONE才能触发配置
- **MonitorDeploy每个flow只有1条记录**: DeployStatus和ConfigStatus共用一条记录，分别更新各自字段
- **MinIO日志路径**: monitor/{flowID}/deploy_{taskID}.log 和 monitor/{flowID}/config_{taskID}.log
- **TriggerConfig的clusterNames参数**: 可为该flow下全部已部署集群统一配置，也可只选部分集群

**执行后数据状态**:

- MonitorDeploy: DeployStatus/ConfigStatus分别动态更新(PENDING→RUNNING→DONE/FAILED)
- MinIO log-bucket: 部署日志和配置日志各1个文件
- WebSocket: 每次状态变更推送

**DeployStatus/ConfigStatus 完整枚举**:
- `PENDING`: 已创建记录, 尚未调用外部服务
- `RUNNING`: 外部服务正在执行
- `DONE`: 执行成功
- `FAILED`: 执行失败或超时
- 两个状态独立管理: DeployStatus和ConfigStatus互不影响, 可同时处于不同状态

#### MonitorService 重启恢复逻辑

**触发时机**: main.go启动时, 数据库初始化完成后(与DeployService恢复同步执行)

```
1. 查询未完成的监控任务:
   SELECT * FROM monitor_deploy WHERE deploy_status IN ('PENDING','RUNNING')
      OR config_status IN ('PENDING','RUNNING')
2. 对每条记录:
   a. deploy_status未完成 + DeployTaskID非空 → 重新启动Deploy轮询goroutine
   b. deploy_status未完成 + DeployTaskID为空 → deploy_status=FAILED
   c. config_status未完成 + ConfigTaskID非空 → 重新启动Config轮询goroutine
       d. config_status未完成 + ConfigTaskID为空 → config_status=FAILED
3. 记录恢复日志
```

#### MonitorDeployVO / MonitorConfigVO 结构体定义

```go
// MonitorDeployVO — 监控部署状态返回
type MonitorDeployVO struct {
    FlowID        uint64      `json:"flow_id"`
    IPs           string      `json:"ips"`           // JSON数组: 选中的机器IP列表
    DeployStatus  string      `json:"deploy_status"` // PENDING/RUNNING/DONE/FAILED
    DeployTaskID  string      `json:"deploy_task_id"` // 部署任务ID
    DeployLogPath string      `json:"deploy_log_path"` // 部署日志MinIO路径
    StartTime     *time.Time  `json:"start_time"`
    EndTime       *time.Time  `json:"end_time"`
}

// MonitorConfigVO — 监控配置状态返回
type MonitorConfigVO struct {
    FlowID        uint64      `json:"flow_id"`
    ConfigStatus  string      `json:"config_status"`  // PENDING/RUNNING/DONE/FAILED
    ConfigTaskID  string      `json:"config_task_id"` // 配置任务ID
    ConfigLogPath string      `json:"config_log_path"` // 配置日志MinIO路径
    ConfigDetail  string      `json:"config_detail"`  // JSON: 配置结果详情(哪些集群完成了配置)
}
```

#### GetDeployStatus 详细逻辑流程

**输入**: `flowID uint64`

**正常流程**:

```
1. 查询 MonitorDeploy WHERE flowID = flowID
   若不存在 → 返回 (nil, ErrParamInvalid "监控部署记录不存在")
2. 构造 MonitorDeployVO:
   - FlowID = record.FlowID
   - IPs = record.IPs
   - DeployStatus = record.DeployStatus
   - DeployTaskID = record.DeployTaskID
   - DeployLogPath = record.DeployLogPath
   - StartTime = record.StartTime
   - EndTime = record.EndTime
3. 返回 (vo, nil)
```

**异常流程**:

- **MonitorDeploy 不存在**: 返回 ErrParamInvalid "监控部署记录不存在"

**边界情况**:

- **DeployStatus=PENDING且DeployTaskID为空**: 触发尚未完成, 前端展示"等待部署服务响应"
- **DeployStatus=FAILED**: 前端展示失败原因+重试按钮

#### GetConfigStatus 详细逻辑流程

**输入**: `flowID uint64`

**正常流程**:

```
1. 查询 MonitorDeploy WHERE flowID = flowID
   若不存在 → 返回 (nil, ErrParamInvalid "监控部署记录不存在")
2. 构造 MonitorConfigVO:
   - FlowID = record.FlowID
   - ConfigStatus = record.ConfigStatus
   - ConfigTaskID = record.ConfigTaskID
   - ConfigLogPath = record.ConfigLogPath
   - ConfigDetail = ""（需从MinIO读取配置日志或从MonitorClient.GetConfigDetail获取）
     若 ConfigLogPath 非空 → 从MinIO读取配置详情日志, 解析后填入ConfigDetail
     若 ConfigLogPath 为空 → ConfigDetail = ""
3. 返回 (vo, nil)
```

**异常流程**:

- **MonitorDeploy 不存在**: 返回 ErrParamInvalid "监控部署记录不存在"
- **MinIO读取失败**: ConfigDetail="", 不返回错误（配置详情是辅助信息）

**边界情况**:

- **ConfigStatus=PENDING且ConfigTaskID为空**: 触发尚未完成
- **ConfigDetail来源**: 从MinIO日志文件解析, 或调用MonitorClient.GetConfigDetail(configTaskID)获取
  ★ 推荐方案: 从MinIO读取(避免额外外部服务调用)

---

## Phase 7: 业务模块 — 演练与推送

**必须在 Phase 6 完成后执行**

### Step 7.1: 基础运维服务适配器

- 文件: `internal/adapter/ops/client.go`
  - struct: `OpsClient` `{ baseURL string; timeout time.Duration; configCenter *config.ConfigCenter }`
  - 函数签名:
    ```go
    func NewOpsClient(cfg *config.OpsServiceConfig, cc *config.ConfigCenter) *OpsClient
    func (c *OpsClient) ExecuteServiceAction(ip, serviceName, action string) error
      // 调用基础运维服务: 启动/停止/重启
    func (c *OpsClient) ExecuteScript(ip string, scriptType, scriptContent string) (output string, error)
      // 执行脚本: Shell/Ansible, SSH连接凭据从ConfigCenter.Get("ssh_user","ops")和Get("ssh_private_key","ops")获取
      // 60秒超时, 凭据为空时返回ErrSSHAuthFailed
    func (c *OpsClient) CallAPI(apiURL, method string, params map[string]any) (result map[string]any, error)
    ```

#### OpsClient.ExecuteScript SSH 连接详细逻辑流程

**输入**: `ip string`, `scriptType string`（shell/python/ansible), `scriptContent string`

**前置条件**:
- SSH凭据已配置: ConfigCenter中 `ops:ssh_user` 和 `ops:ssh_private_key` 非空
- 目标IP可达: 网络连通性由调用方保证（CheckService/DrillService调用前不校验）

**正常流程**:

```
func (c *OpsClient) ExecuteScript(ip, scriptType, scriptContent string) (string, error) {
    // 1. 从 ConfigCenter 动态获取 SSH 凭据（每次连接重新读取, 支持运行时更换密钥）
    sshUser, err1 := c.configCenter.GetRealValue("ssh_user", "ops")
    if err1 != nil || sshUser == "" {
        return "", fmt.Errorf("SSH用户名未配置: %v", err1)  // → ErrSSHAuthFailed(1004)
    }
    
    sshPrivateKey, err2 := c.configCenter.GetRealValue("ssh_private_key", "ops")
    if err2 != nil || sshPrivateKey == "" {
        return "", fmt.Errorf("SSH私钥未配置: %v", err2)  // → ErrSSHAuthFailed(1004)
    }
    
    // 2. 解析 SSH 私钥
    signer, err := ssh.ParsePrivateKey([]byte(sshPrivateKey))
    if err != nil {
        return "", fmt.Errorf("SSH私钥解析失败: %v", err)  // → ErrSSHAuthFailed(1004)
    }
    
    // 3. 创建 SSH 客户端配置
    sshConfig := &ssh.ClientConfig{
        User:            sshUser,
        Auth:            []ssh.AuthMethod{ssh.PublicKeys(signer)},
        HostKeyCallback: ssh.InsecureIgnoreHostKey(),  // 生产环境应替换为已知主机密钥校验
        Timeout:         30 * time.Second,               // SSH连接超时30秒(不含脚本执行)
    }
    
    // 4. 建立SSH连接
    // 端口默认22, 若需要可从ConfigCenter读取
    sshPort := 22
    portStr, _ := c.configCenter.GetRealValue("ssh_port", "ops")
    if portStr != "" {
        if p, err := strconv.Atoi(portStr); err == nil {
            sshPort = p
        }
    }
    
    addr := fmt.Sprintf("%s:%d", ip, sshPort)
    client, err := ssh.Dial("tcp", addr, sshConfig)
    if err != nil {
        return "", fmt.Errorf("SSH连接失败(ip=%s): %v", ip, err)  // → ErrCheckFailed(2202) / ErrDrillFailed(2401)
    }
    defer client.Close()
    
    // 5. 创建SSH Session
    session, err := client.NewSession()
    if err != nil {
        return "", fmt.Errorf("SSH Session创建失败: %v", err)
    }
    defer session.Close()
    
    // 6. 设置脚本执行超时: 60秒
    // CONSTRAINTS: 脚本核查超时60秒
    session.SetDeadline(time.Now().Add(60 * time.Second))
    
    // 7. 执行脚本
    // scriptType 仅用于日志记录, 执行逻辑相同(都是SSH执行命令)
    // ansible类型: scriptContent为playbook YAML, 需通过ansible-playbook命令执行
    // 但本平台SSH执行统一使用session.Run(), ansible类型由OpsService端处理
    
    var stdout, stderr []byte
    if scriptType == "ansible" {
        // ansible: 通过ansible-playbook执行playbook
        // playbook内容通过stdin传入或临时文件
        cmd := fmt.Sprintf("echo '%s' > /tmp/playbook.yml && ansible-playbook /tmp/playbook.yml", 
            strings.ReplaceAll(scriptContent, "'", "'\\''"))
        stdout, err = session.CombinedOutput(cmd)
    } else {
        // shell/python: 直接执行脚本内容
        stdout, err = session.CombinedOutput(scriptContent)
    }
    
    // 8. 处理执行结果
    output := string(stdout)
    if err != nil {
        // 超时或执行失败
        if strings.Contains(err.Error(), "deadline") || strings.Contains(err.Error(), "timeout") {
            return output, fmt.Errorf("脚本执行超时(60秒): ip=%s", ip)  // → ErrCheckFailed
        }
        return output + "\n" + string(stderr), fmt.Errorf("脚本执行失败: ip=%s, err=%v", ip, err)
    }
    
    // 9. 返回执行输出
    return output, nil
}
```

**异常流程**:

- **ssh_user未配置**: 返回 ErrSSHAuthFailed(1004) "SSH用户名未配置"
- **ssh_private_key未配置**: 返回 ErrSSHAuthFailed(1004) "SSH私钥未配置"
- **私钥解析失败**: 返回 ErrSSHAuthFailed(1004) "SSH私钥解析失败"
- **SSH连接失败**: 返回 ErrCheckFailed(2202)/ErrDrillFailed(2401) "SSH连接失败"
- **Session创建失败**: 返回连接级错误
- **脚本执行超时**(60秒): session.SetDeadline 触发, 返回 ErrCheckFailed/ErrDrillFailed "脚本执行超时"
- **脚本执行失败**(exit code != 0): 返回 stdout+stderr+错误信息
- **ansible-playbook不存在**: CombinedOutput返回错误, 调用方应确保目标机器安装ansible

- **SSH连接超时**(30秒): ssh.ClientConfig.Timeout 触发, 返回连接级错误

**边界情况**:

- **每次连接重新读取凭据**: ConfigCenter.GetRealValue 每次调用都从sync.Map读取(热更新5秒内生效), 支持运行时更换密钥
- **ssh_port自定义**: 默认22, 可从ConfigCenter `ops:ssh_port` 读取自定义端口
- **ansible脚本执行**: playbook内容先写入临时文件再执行ansible-playbook; 临时文件路径 `/tmp/playbook.yml`
- **HostKeyCallback**: 当前使用 InsecureIgnoreHostKey(不校验主机密钥), 生产环境应替换为 known_hosts 校验
- **CombinedOutput**: stdout和stderr合并输出, 调用方需自行解析stdout中的JSON/关键字
- **单节点执行**: ExecuteScript 每次只在一个IP上执行; CheckService/DrillService 调用时逐节点遍历调用
- **并发SSH连接**: 不同节点并行执行时各自建立独立SSH连接; ants协程池控制并发数

- **连接复用**: 当前每次ExecuteScript建立新连接并关闭; 高频调用场景可考虑连接池(但CONSTRAINTS禁止"聪明代码")暂不实现)

#### OpsClient.CallAPI 详细逻辑流程

**输入**: `apiURL string`, `method string`(GET/POST/PUT/DELETE), `params map[string]any`

**前置条件**:
- apiURL 非空且为合法 HTTP URL
- method 为标准 HTTP 方法

**正常流程**:

```
func (c *OpsClient) CallAPI(apiURL, method string, params map[string]any) (map[string]any, error) {
    // 1. 创建 http.Client (与 ExecuteScript 共享, 但超时不同)
    // API调用30秒超时(不含SSH, 纯HTTP)
    client := &http.Client{
        Timeout: 30 * time.Second,
    }
    
    // 2. 构造 HTTP 请求
    var req *http.Request
    var err error
    
    switch method {
    case "GET":
        // GET请求: params作为URL query参数
        // 构造带query的URL:
        if len(params) > 0 {
            values := url.Values{}
            for k, v := range params {
                values.Set(k, fmt.Sprintf("%v", v))
            }
            apiURL = apiURL + "?" + values.Encode()
        }
        req, err = http.NewRequest("GET", apiURL, nil)
        
    case "POST", "PUT", "DELETE":
        // POST/PUT/DELETE: params作为JSON Body
        bodyBytes, marshalErr := json.Marshal(params)
        if marshalErr != nil {
            return nil, fmt.Errorf("请求参数序列化失败: %v", marshalErr)
        }
        req, err = http.NewRequest(method, apiURL, bytes.NewReader(bodyBytes))
        req.Header.Set("Content-Type", "application/json")
    
    default:
        return nil, fmt.Errorf("不支持的方法: %s", method)  // → ErrParamInvalid
    }
    
    if err != nil {
        return nil, fmt.Errorf("构造请求失败: %v", err)  // → ErrAPICallFailed
    }
    
    // 3. 发送请求(无重试, API调用结果用于判定, 重试可能导致误判)
    resp, err := client.Do(req)
    if err != nil {
        return nil, fmt.Errorf("API调用失败: %v", err)  // → ErrAPICallFailed(1003)
    }
    defer resp.Body.Close()
    
    // 4. 读取响应
    respBytes, err := io.ReadAll(resp.Body)
    if err != nil {
        return nil, fmt.Errorf("读取响应失败: %v", err)  // → ErrAPICallFailed
    }
    
    // 5. 解析响应为 map[string]any
    result := map[string]any{}
    if len(respBytes) > 0 {
        if err := json.Unmarshal(respBytes, &result); err != nil {
            // 响应不是合法JSON → 返回原始字符串供调用方做keyword匹配
            result = map[string]any{
                "raw_response": string(respBytes),
                "status_code":  resp.StatusCode,
            }
        }
    }
    
    // 6. 注入 status_code 到 result (供 JudgeRule.status_code 模式使用)
    result["status_code"] = resp.StatusCode
    
    // 7. 返回 (result, nil)
    // 调用方(CheckService/DrillService)根据 JudgeRule 对 result 进行判定:
    // - status_code模式: 检查 result["status_code"]
    // - json_field模式: 检查 result[field_path]
    // - keyword模式: 检查 result["raw_response"]
    // - value_range模式: 检查 result[field_path] 的数值范围
    return result, nil
}
```

**异常流程**:

- **http.Client.Do 超时(30秒)**: 返回 ErrAPICallFailed "API调用超时"
- **HTTP方法不支持**: 返回 ErrParamInvalid "不支持的方法"
- **params序列化失败**: 返回 ErrAPICallFailed "请求参数序列化失败"
- **响应非200状态码**: 不视为错误, 将status_code注入result供JudgeRule判定(如期望200但返回500→JudgeRule判定FAIL)
- **响应JSON解析失败**: 不视为错误, 将原始字符串存入result["raw_response"]供keyword匹配
- **网络错误(DNS解析失败/连接拒绝)**: 返回 ErrAPICallFailed

**边界情况**:

- **API调用无重试**: 与CMDB不同(CMDB重试3次), CallAPI不重试。原因: API调用结果用于JudgeRule判定, 重试可能掩盖真实服务问题
- **GET请求params编码为URL query**: POST/PUT/DELETE编码为JSON Body, 这是标准HTTP约定
- **响应JSON解析失败时保留raw_response**: keyword模式的JudgeRule需要原始字符串做关键字匹配
- **status_code始终注入result**: 无论HTTP状态码是什么, 都注入到result中, JudgeRule.status_code模式直接读取
- ** DrillService ExecuteDrill中API步骤使用CallAPI**: 步骤类型=API时, 从Steps JSON解析url+method+params后调用CallAPI; 200状态码→步骤PASS, 非200→步骤FAIL(简化判定, 无JudgeRule)

### Step 7.2: 演练引擎模块

- 文件: `internal/drill/service.go`
  - struct: `DrillService` `{ db *gorm.DB; pool *ants.Pool; sceneSvc *admin.DrillSceneService; opsClient *adapter.OpsClient; minio *minio.MinioClient }`
  - 函数签名:
    ```go
    func NewDrillService(db *gorm.DB, pool *ants.Pool, ss *admin.DrillSceneService, oc *adapter.OpsClient, mc *minio.MinioClient) *DrillService
    func (s *DrillService) GetDeployedClusters(ctx context.Context, flowID uint64, mwType string) ([]*ClusterDrillVO, error)
      // 查部署完成的集群, 按mwType筛选
    func (s *DrillService) ExecuteDrill(ctx context.Context, flowID uint64, clusterName string, sceneIDs []uint64) ([]*model.DrillRecord, error)
      // ★ 详细逻辑流程见下方 "ExecuteDrill 详细逻辑流程" 章节
    func (s *DrillService) RetryDrill(ctx context.Context, drillID uint64) error
    func (s *DrillService) GetDrillDetail(ctx context.Context, flowID uint64, clusterName string) ([]*model.DrillRecord, error)
    func (s *DrillService) GetDrillLog(ctx context.Context, recordID uint64, startLine, lineCount int) ([]string, error)
    ```

#### ClusterDrillVO 结构体定义与查询逻辑

```go
type ClusterDrillVO struct {
    ClusterName string  `json:"cluster_name"`
    MWType      string  `json:"mw_type"`
    NodeCount   int     `json:"node_count"`    // 集群节点数(从ResourceApplyItem取)
    DeployStatus string `json:"deploy_status"` // DONE(固定, 因为只返回部署完成的)
    DrillStatus  string `json:"drill_status"`  // 该集群的演练汇总状态: NONE/PARTIAL/ALL_DONE/FAILED
    SceneCount   int    `json:"scene_count"`   // 该集群应演练的场景数(从MatchScenes获取)
    DoneCount    int    `json:"done_count"`    // 已完成的场景数
    FailCount    int    `json:"fail_count"`    // 失败的场景数
}
```

**GetDeployedClusters 查询逻辑**:

```
1. 查询 DeployRecord WHERE flow_id=flowID AND status='DONE'
   → 部署完成的集群列表

2. 若 mwType != "" → 过滤: 仅保留 MWType=mwType 的记录

3. 对每个已部署完成的集群, 查询演练状态:
   查 DrillRecord WHERE flow_id=flowID AND cluster_name=集群名
   
   汇总判定:
   - 无 DrillRecord → DrillStatus="NONE"(尚未演练)
   - 全部 Status=DONE → DrillStatus="ALL_DONE"
   - 有 DONE 有 FAILED → DrillStatus="FAILED"(部分失败)
   - 全部 Status=FAILED → DrillStatus="FAILED"

4. 从 ResourceApplyItem 取 NodeCount(补充节点数信息)

5. 构造 ClusterDrillVO 列表并返回
```

**GetDrillDetail 查询逻辑**:

```
1. 查询 DrillRecord WHERE flow_id=flowID AND cluster_name=clusterName
   按 scope+scene_id 排序(COMMON→MW_TYPE→CLUSTER)

2. 若不存在 → 返回空列表 ([]*model.DrillRecord{}, nil)

3. 直接返回 DrillRecord 列表(模型已含全部字段: SceneID/Scope/Status/Result/LogFilePath)
   ★ 不需要额外VO, DrillRecord本身就是明细
```

**GetDrillLog 查询逻辑**:

```
1. 查询 DrillRecord WHERE ID=recordID
   若不存在 → 返回 ([]string{}, ErrParamInvalid "演练记录不存在")

2. 若 LogFilePath 为空 → 返回 ([]string{}, nil)

3. 调用 MinioClient.ReadLines("log-bucket", record.LogFilePath, startLine, lineCount)
   lineCount 固定传 100

4. 返回 (lines, nil)
```

- 文件: `api/v1/drill.go`
  ```go
  // GET    /api/v1/flows/:id/drill/clusters?mw_type=xxx      → GetDeployedClusters
  // POST   /api/v1/flows/:id/drill/execute?cluster=xxx        → ExecuteDrill (body: {scene_ids: []} 或空=全部)
  // POST   /api/v1/drill/:id/retry                             → RetryDrill
  // GET    /api/v1/flows/:id/drill/detail?cluster=xxx          → GetDrillDetail
  // GET    /api/v1/drill/records/:id/log?start=0&count=100     → GetDrillLog
  ```
- 验收: `go test ./internal/drill/... -run TestDrillService_ExecuteDrill` 通过

#### ExecuteDrill 详细逻辑流程

**输入**: `flowID`, `clusterName`, `sceneIDs []uint64`

**前置条件**:
- 演练环节已触发（FlowPhase.DRILL.Status = RUNNING）
- 该集群的 DeployRecord.Status = DONE（部署完成才能演练）
- 该集群有对应的 ResourceApplyItem 记录（含 MWType 和 IPs）

**正常流程**:

```
1. 从 ResourceApplyItem 表查询该 clusterName 的记录，获取 mwType 和 IPs
2. 获取演练场景列表:
   - 若 sceneIDs 非空 → 按 sceneIDs 从 DB 查询 DrillScene（WHERE id IN sceneIDs AND status=ENABLE）
   - 若 sceneIDs 为空 → 调用 DrillSceneService.MatchScenes(clusterName, mwType)
     获取三层全部场景: COMMON场景[] + MW_TYPE场景[] + CLUSTER场景[]
3. DELETE drill_record WHERE flowID=参数 AND clusterName=参数 AND sceneID IN (本次执行的sceneIDs)
   （允许重新演练，覆盖旧结果）
4. 串行执行三层场景，层间顺序严格: COMMON → MW_TYPE → CLUSTER
   每层内部也串行执行，按 DB 中的自然顺序
   
   对每个场景:
   a. 创建 DrillRecord 记录，Status=RUNNING, SceneID=场景ID, Scope=场景的Scope
    b. 从 DrillScene.Steps JSON 解析步骤列表:

Steps JSON Schema:
```json
[
  {
    "name": "步骤名称(前端展示)",
    "type": "SHELL | ANSIBLE | API",
    "content": "脚本内容/ansible playbook/API请求配置JSON",
    "target": ""  // 可选: 指定执行目标
  }
]
```

target字段规则:
- 空字符串或不填 → 在集群全部IPs上执行
- 填写IP地址(如"10.0.0.1") → 仅在该IP上执行
- 填写IP列表(如"10.0.0.1,10.0.0.2") → 仅在这些IP上执行(逗号分隔)
- SHELL和ANSIBLE步骤使用target; API步骤不使用target(直接调用URL)
   c. 串行执行每个步骤:
       - SHELL步骤:
         a. 解析target字段, 获取目标IP列表:
            - target为空 → 使用ResourceApplyItem.IPs全部IP
            - target非空 → 按逗号分割得到IP列表
         b. 遍历目标IP列表, 逐节点SSH执行:
            - SSH连接: ip + ConfigCenter.Get("ssh_user","ops") + ConfigCenter.Get("ssh_private_key","ops")
            - 设置60秒超时: session.SetDeadline(time.Now().Add(60*time.Second))
            - 执行: session.Run(content)
            - 收集stdout + stderr
         c. 单节点结果记录: {ip, result(PASS/FAIL), output, error, execute_time}
         d. 全部节点执行完毕后汇总:
            - 全部节点执行成功(exit code=0, 无SSH错误) → 步骤PASS
            - 任意节点失败 → 步骤FAIL, 但其他节点继续执行
         e. Result JSON记录每节点结果: {nodes: [{ip, result, output, error}]}
       - ANSIBLE步骤:
         a. content为ansible playbook内容(YAML格式)
         b. target字段规则同SHELL: 空→全部IPs, 非空→指定IPs
         c. 通过OpsClient.ExecuteScript在目标IPs上执行:
            - scriptType = "ansible"
            - 逐节点SSH连接并执行playbook
         d. 每节点60秒超时
         e. 全部节点执行完毕后汇总:
            - 全部节点成功 → 步骤PASS
            - 任意节点失败 → 步骤FAIL
         f. 与SHELL步骤的区别: type仅用于前端展示区分, 执行逻辑相同(都是SSH执行脚本)
       - API步骤:
         a. 从content JSON解析: {url, method, headers, body, params}
         b. target字段不适用(API步骤不按节点执行)
         c. 通过OpsClient.CallAPI调用: CallAPI(url, method, params)
         d. 调用结果: 200状态码 → PASS; 非200 → FAIL
         e. Result JSON: {url, status_code, response_body, error}
   d. 步骤执行结果判定:
      - 所有步骤全部执行成功(无报错+返回符合预期) → 场景PASS
      - 任意步骤执行失败 → 场景FAIL，但后续步骤继续执行（不中断）
   e. 更新 DrillRecord:
      - Status = DONE 或 FAILED
       - Result = JSON: 每个步骤的执行结果

DrillRecord.Result JSON Schema:
```json
{
  "steps": [
    {
      "step_name": "步骤名称",
      "status": "PASS | FAIL",
      "type": "SHELL | ANSIBLE | API",
      "nodes": [                    // SHELL/ANSIBLE步骤有此字段
        {
          "ip": "10.0.0.1",
          "result": "PASS",
          "output": "stdout内容",
          "error": "",
          "execute_time": "2024-06-01T10:00:00Z"
        }
      ],
      "api_result": {               // API步骤有此字段
        "url": "http://...",
        "status_code": 200,
        "response_body": "...",
        "error": ""
      },
      "execute_time": "2024-06-01T10:00:00Z"
    }
  ],
  "overall_result": "PASS | FAIL"
}
```
      - LogFilePath = MinIO路径(drill/{flowID}/{clusterName}_{sceneID}_{timestamp}.log)
      - EndTime = now
   f. 将完整执行日志上传到 MinIO log-bucket

 5. 汇总所有 DrillRecord，返回结果列表

汇总规则:
- 每个场景独立判定PASS/FAIL(取决于该场景内所有步骤的汇总)
- 场景之间互不影响(一个场景FAIL不阻止下一个场景执行)
- 最终DrillRecord列表: 每个场景1条, 含Status/Result/LogFilePath
- 前端按 COMMON→MW_TYPE→CLUSTER 顺序展示三层场景结果
```

**异常流程**:

- **单个步骤FAIL**: 记录该步骤Result=FAIL，继续执行同场景后续步骤（不中断）
- **单个步骤执行报错**（SSH连接失败、API调用超时等）: 记录步骤Result=FAIL+错误原因，继续执行后续步骤
- **SHELL/ANSIBLE步骤节点执行失败**: 某节点FAIL不影响其他节点继续执行；汇总后任意节点FAIL→步骤FAIL
- **某层场景列表为空**: 直接跳过该层，进入下一层
- **API步骤调用失败**: 记录FAIL+错误详情，继续后续步骤

**边界情况**:

- **重复触发**: DELETE旧DrillRecord后重新执行（允许重新演练，覆盖旧结果）
- **sceneIDs包含不存在的ID**: 忽略不存在的ID，仅执行DB中查到的场景
- **sceneIDs包含DISABLE状态的场景**: 跳过DISABLE场景，仅执行ENABLE的
- **集群未部署完成**（DeployRecord.Status != DONE）: 返回错误 ErrDeployFailed，提示"集群未部署完成，无法演练"
- **演练步骤中target字段为空**: SHELL步骤在集群全部IPs上执行；ANSIBLE步骤在全部IPs上执行
- **演练步骤中target字段指定特定IP**: 仅在指定IP上执行
- **场景Steps JSON为空**（没有步骤）: DrillRecord.Status=DONE, Result={}, 直接标记完成

**执行后数据状态**:

- DrillRecord表: 每个场景1条记录，含SceneID/Scope/Status/Result/LogFilePath
- MinIO log-bucket: 每个场景1个日志文件
- 旧的DrillRecord已被删除（重新演练覆盖）

#### RetryDrill 详细逻辑流程

**输入**: `drillID uint64`（DrillRecord.ID）

**前置条件**:
- DrillRecord 存在且 Status = FAILED（只有失败记录才允许重试）

**正常流程**:

```
1. 查询 DrillRecord WHERE ID = drillID
   若不存在 → 返回 ErrParamInvalid "演练记录不存在"
   若 Status != FAILED → 返回 ErrParamInvalid "只有失败的演练才允许重试"

2. 查询 DrillScene WHERE ID = record.SceneID
   若不存在 → 返回 ErrParamInvalid "演练场景不存在"
   若 Status = DISABLE → 返回 ErrParamInvalid "演练场景已禁用, 无法重试"

3. 删除旧 DrillRecord:
   db.Delete(&DrillRecord{}, drillID)
   ★ RetryDrill = 删除旧记录 + 重新执行单场景
   物理删除(不是逻辑删除, 因为会创建新记录替代)

4. 调用 ExecuteDrill(flowID, clusterName, []uint64{record.SceneID})
   ★ 仅重新执行该场景, 不执行全部场景
   ExecuteDrill 内部会:
   - DELETE旧DrillRecord WHERE flowID AND clusterName AND sceneID=record.SceneID (已在步骤3删除)
   - 创建新的 DrillRecord
   - 执行该场景的全部Steps
   - 上传日志到MinIO

5. 返回 nil（新的 DrillRecord 由 ExecuteDrill 创建）
```

**异常流程**:

- **DrillRecord.Status != FAILED**: 返回 ErrParamInvalid "只有失败的演练才允许重试"
- **DrillScene 已被 DISABLE**: 返回 ErrParamInvalid "演练场景已禁用, 无法重试"
- **DrillScene 不存在**: 返回 ErrParamInvalid "演练场景不存在"
- **ExecuteDrill 执行失败**: 返回错误（新 DrillRecord.Status=FAILED）

**边界情况**:

- **RetryDrill 只重试单个场景**: 不影响其他场景的 DrillRecord
- **旧 DrillRecord 物理删除**: 不是逻辑删除, 因为会创建新记录替代旧记录
- **场景被修改后重试**: 使用当前 DrillScene 的 Steps（可能已变更），不使用旧版本
- **场景Steps为空**: DrillRecord.Status=DONE, Result={}, 直接标记完成

---

## Phase 8: 前端（Vue3）

**在 Phase 4 完成后可与 Phase 5-7 并行启动**

### Step 8.1: 前端项目初始化

- 使用 `npm create vue@latest` 初始化 Vue3 + TypeScript + Vite 项目
- 安装依赖: `element-plus`, `axios`, `pinia`, `vue-router`, `@vueuse/core`
- 目录结构:
  ```
  web/
  ├── src/
  │   ├── views/
  │   │   ├── FlowList.vue          # 交付流程列表
  │   │   ├── FlowDetail.vue        # 流程总览（5环节状态）
  │   │   ├── ResourceApply.vue     # 资源申请环节
  │   │   ├── CheckView.vue         # 核查环节
  │   │   ├── MonitorView.vue       # 监控部署环节
  │   │   ├── DeployView.vue        # 服务部署环节
  │   │   ├── DrillView.vue         # 演练环节
  │   │   └── Admin.vue             # 管理配置
  │   ├── components/
  │   │   ├── PhaseCard.vue         # 单个环节状态卡片
  │   │   ├── ClusterTable.vue      # 集群列表表格
  │   │   ├── CheckDetail.vue       # 核查结果明细
  │   │   ├── DeployProgress.vue    # 部署三阶段进度条
  │   │   ├── DrillProgress.vue     # 演练进度
  │   │   └── LogViewer.vue         # 日志分页查看器
  │   ├── stores/
  │   │   ├── flow.ts               # 流程状态store
  │   │   └── websocket.ts          # WebSocket连接管理
  │   ├── api/
  │   │   ├── request.ts            # axios封装
  │   │   ├── flow.ts
  │   │   ├── resource.ts
  │   │   ├── check.ts
  │   │   ├── monitor.ts
  │   │   ├── deploy.ts
  │   │   ├── drill.ts
  │   │   └── admin.ts
  │   └── router/index.ts
  ├── package.json
  └── vite.config.ts
  ```
- 验收: `npm run dev` 启动成功, 页面可访问

### Step 8.2: 流程总览页与 WebSocket

- 文件: `web/src/views/FlowDetail.vue`
  - 展示5个环节卡片（PhaseCard组件），MONITOR和DEPLOY并行排列
  - 每个卡片显示环节状态，用户可点击触发 startPhase
  - WebSocket连接: 连接后自动接收状态推送, 更新store
- 文件: `web/src/stores/websocket.ts`
  - 管理 WebSocket 连接/断线重连/消息分发
- 验收: 打开流程总览页, 可看到5个环节卡片, WebSocket可连接

### Step 8.3: 各环节页面实现

- 逐环节实现: ResourceApply → CheckView → MonitorView → DeployView → DrillView
- 每个页面调用对应API, 展示集群列表/状态/明细/日志
- LogViewer组件: 分页读取MinIO日志, 每页100行, 支持行号定位
- 验收: 每个环节页面可正常展示数据, 触发操作有响应

### Step 8.4: 管理配置页面

- Admin.vue: 三个Tab（核查规则/演练场景/部署配置）
- 每个Tab支持增删改查表格, 演练场景支持步骤编辑器
- 验收: 管理页面可正常CRUD操作

---

## 全局验收

所有 Phase 完成后:

```bash
# 后端
go build ./cmd/server/          # 编译成功
go test ./...                    # 全部测试通过

# 前端
cd web && npm run build          # 构建成功
```
