# Frontend Specification — Phase 8

> 本文件为弱模型可逐步执行的前端实现蓝图。覆盖 Vue3 前端的每个页面交互流程、API调用序列、状态管理、组件数据流、WebSocket处理逻辑。

## 1. 技术栈与全局配置

| 项目 | 版本/配置 |
|------|---------|
| Vue | 3.4+ (Composition API, `<script setup>`) |
| TypeScript | 5.x |
| Vite | 5.x |
| Element Plus | 2.7+ (全局注册) |
| Pinia | 2.x (状态管理) |
| Vue Router | 4.x |
| axios | 1.x (拦截器封装) |
| @vueuse/core | 10.x (WebSocket/动画等工具) |
| gorilla/websocket | 后端推送 |

**全局配置**:

- Vite proxy: 开发环境 `/api` → `http://localhost:8080`, `/ws` → `ws://localhost:8080`
- Element Plus: `ElMessage` 替代 alert, `ElMessageBox.confirm` 替代 confirm
- axios 拦截器: 自动注入 reqID, 统一错误处理, JWT token 注入
- 路由守卫: 检查 localStorage 中 token, 无 token → 跳转登录页

## 2. API 请求封装

### `web/src/api/request.ts`

```
// axios 实例封装, 所有 API 调用通过此模块
const apiClient = axios.create({
    baseURL: '/api/v1',
    timeout: 30000,  // 30秒超时(与后端对齐)
})

// 请求拦截器: 注入 JWT token + reqID
apiClient.interceptors.request.use((config) => {
    const token = localStorage.getItem('jwt_token')
    if (token) {
        config.headers.Authorization = `Bearer ${token}`
    }
    // reqID: 前端生成, 用于日志追踪
    config.headers['X-Req-ID'] = `fe_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
    return config
})

// 响应拦截器: 统一错误处理
apiClient.interceptors.response.use(
    (response) => {
        // 后端统一响应格式: {code, msg, req_id, data, timestamp}
        const body = response.data
        if (body.code === 0) {
            return body.data  // ★ 成功时直接返回 data, 不返回整个 body
        }
        // 业务错误
        ElMessage.error(body.msg || '操作失败')
        return Promise.reject(body)
    },
    (error) => {
        if (error.response?.status === 401) {
            // JWT过期或无效 → 清除token → 跳转登录页
            localStorage.removeItem('jwt_token')
            router.push('/login')
            ElMessage.error('登录已过期，请重新登录')
        } else if (error.response?.status === 429) {
            ElMessage.warning('请求过于频繁，请稍后重试')
        } else {
            ElMessage.error(error.response?.data?.msg || '网络错误')
        }
        return Promise.reject(error)
    }
)
```

### API 模块文件清单

每个模块文件遵循统一模式: `export const xxxApi = { method: (params) => apiClient.httpMethod(url, data) }`

| 文件 | API方法 |
|------|--------|
| `api/flow.ts` | createFlow, getFlowStatus, startPhase, completePhase |
| `api/resource.ts` | initApply, getApplyItems, updateApplyItem, deleteApplyItem, addApplyItem, confirmAndSubmit |
| `api/check.ts` | queryDeliverStatus, executeCheck, getCheckDetail, getCheckLog |
| `api/deploy.ts` | getCheckedClusters, triggerDeploy, retryDeploy, getDeployDetail, getStageLog |
| `api/monitor.ts` | triggerDeploy, triggerConfig, getDeployStatus, getConfigStatus, getDeployLog |
| `api/drill.ts` | getDeployedClusters, executeDrill, retryDrill, getDrillDetail, getDrillLog |
| `api/admin.ts` | checkRule CRUD, drillScene CRUD, deployConfig CRUD, matchRules, matchScenes |

## 3. 状态管理 (Pinia)

### `stores/flow.ts` — 流程状态核心

```typescript
interface FlowState {
    currentFlowID: number | null        // 当前查看的流程ID
    flowStatus: FlowStatusVO | null     // FlowStatusVO完整数据
    loading: boolean                    // 加载状态
    phases: PhaseStatusVO[]             // 5个环节状态
}

// Actions:
const useFlowStore = defineStore('flow', {
    state: (): FlowState => ({...}),
    actions: {
        // 加载流程状态(页面初始化时调用)
        async loadFlowStatus(flowID: number) {
            this.loading = true
            this.currentFlowID = flowID
            this.flowStatus = await flowApi.getFlowStatus(flowID)
            this.phases = this.flowStatus.phases
            this.loading = false
        },
        
        // 触发环节(用户点击"开始"按钮)
        async startPhase(phaseType: string) {
            await flowApi.startPhase(this.currentFlowID!, phaseType)
            // 重新加载状态(后端已更新)
            await this.loadFlowStatus(this.currentFlowID!)
        },
        
        // 完成环节(用户点击"完成"按钮)
        async completePhase(phaseType: string) {
            await flowApi.completePhase(this.currentFlowID!, phaseType)
            await this.loadFlowStatus(this.currentFlowID!)
        },
        
        // ★ WebSocket推送时更新状态(不重新请求API)
        updateFromWS(wsData: any) {
            if (wsData.flow_id === this.currentFlowID) {
                // 根据推送数据更新对应环节的状态
                // wsData格式: {flow_id, phase_type, status, cluster_name, detail}
                const phase = this.phases.find(p => p.phase_type === wsData.phase_type)
                if (phase) {
                    phase.status = wsData.status
                    if (wsData.clusters) {
                        phase.clusters = wsData.clusters
                    }
                }
            }
        },
        
        // 清空状态(切换流程时)
        clearFlow() {
            this.currentFlowID = null
            this.flowStatus = null
            this.phases = []
        }
    }
})
```

### `stores/websocket.ts` — WebSocket连接管理

```typescript
interface WSState {
    connected: boolean                  // 连接状态
    reconnectCount: number              // 重连次数
    flowID: number | null               // 当前订阅的流程ID
}

const useWSStore = defineStore('websocket', {
    state: (): WSState => ({ connected: false, reconnectCount: 0, flowID: null }),
    actions: {
        // 连接WebSocket(进入流程详情页时调用)
        connect(flowID: number) {
            this.flowID = flowID
            const wsURL = `ws://${window.location.host}/ws?flow_id=${flowID}`
            
            // ★ 使用 @vueuse/core 的 useWebSocket 封装
            // 或手动管理连接:
            this.ws = new WebSocket(wsURL)
            
            this.ws.onopen = () => {
                this.connected = true
                this.reconnectCount = 0
            }
            
            this.ws.onmessage = (event) => {
                // 解析推送消息 → 更新 flow store
                const data = JSON.parse(event.data)
                const flowStore = useFlowStore()
                flowStore.updateFromWS(data)
            }
            
            this.ws.onclose = () => {
                this.connected = false
                // 自动重连: 3秒后重试, 最多5次
                if (this.reconnectCount < 5) {
                    this.reconnectCount++
                    setTimeout(() => this.connect(this.flowID!), 3000)
                }
            }
            
            this.ws.onerror = () => {
                this.connected = false
            }
        },
        
        // 断开连接(离开流程详情页时调用)
        disconnect() {
            if (this.ws) {
                this.ws.close()
                this.ws = null
            }
            this.connected = false
            this.flowID = null
            this.reconnectCount = 0
        }
    }
})
```

**WebSocket 消息格式**(后端推送):

```json
{
    "flow_id": 1,
    "phase_type": "DEPLOY",
    "status": "RUNNING",
    "cluster_name": "redis-prod-a",
    "detail": {
        "deploy_status": "DEPLOYING",
        "stage": "DEPLOY",
        "progress": "60%"
    },
    "timestamp": 1717234800
}
```

**前端处理逻辑**:
- 收到消息 → 解析 JSON → `useFlowStore().updateFromWS(data)` → Vue 响应式更新视图
- 连接断开 → 自动重连(3秒间隔,最多5次) → 重连成功后重新加载流程状态(可能有更新)
- 离开页面 → `disconnect()` 断开连接

## 4. 路由配置

### `router/index.ts`

```typescript
const routes = [
    { path: '/login', component: LoginView, meta: { requiresAuth: false } },
    { path: '/', redirect: '/flows' },
    { path: '/flows', component: FlowList, meta: { requiresAuth: true } },
    { path: '/flows/:id', component: FlowDetail, meta: { requiresAuth: true } },
    { path: '/admin', component: AdminView, meta: { requiresAuth: true } },
]

// 路由守卫: 检查JWT token
router.beforeEach((to, from, next) => {
    const token = localStorage.getItem('jwt_token')
    if (to.meta.requiresAuth && !token) {
        next('/login')
    } else {
        next()
    }
})
```

**页面与路由对应**:

| 路由 | 页面 | 入口参数 |
|------|------|---------|
| `/flows` | FlowList.vue | 无(列表页) |
| `/flows/:id` | FlowDetail.vue | flowID=路由参数 |
| `/admin` | AdminView.vue | 无(管理配置) |
| `/login` | LoginView.vue | 无 |

## 5. 页面交互流程

### 5.1 FlowList.vue — 交付流程列表页

**功能**: 展示所有交付流程列表, 支持创建新流程

**交互流程**:

```
页面初始化:
1. 调用 GET /api/v1/flows (列表接口) → 展示流程卡片列表
2. 每个卡片显示: flow_name, idc_name, status, create_time
3. 点击卡片 → 路由跳转 /flows/:id

创建新流程:
1. 用户点击"新建流程"按钮 → 弹出 ElDialog
2. Dialog 表单: flow_name(必填), idc_name(必填), creator(可选)
3. 用户填写 → 点击"确认" → 调用 POST /api/v1/flows
4. 成功 → ElMessage.success → 刷新列表 → 路跳转到新流程详情页
5. 失败 → ElMessage.error(后端返回的msg)
```

**组件结构**:

```
FlowList.vue
  ├── 新建流程按钮 → ElDialog(CreateFlowForm)
  ├── 流程卡片列表 → ElCard × N
  │     └── 卡片内容: flow_name + idc_name + status标签 + create_time
  │     └── 点击 → router.push(`/flows/${flow.id}`)
  └── 分页组件 → ElPagination
```

### 5.2 FlowDetail.vue — 流程总览页（核心页面）

**功能**: 展示5环节状态, 支持手动触发推进, 实时WebSocket推送

**交互流程**:

```
页面初始化:
1. 从路由参数获取 flowID = route.params.id
2. useFlowStore().loadFlowStatus(flowID) → 加载流程完整状态
3. useWSStore().connect(flowID) → 建立WebSocket连接

环节触发:
1. 用户查看5个PhaseCard, 每个显示: phase_type, status, start_time, end_time
2. PENDING状态的环节 → 显示"开始"按钮
3. RUNNING状态的环节 → 显示"进行中"标签(不可点击)
4. DONE状态的环节 → 显示"已完成"标签
5. FAILED状态的环节 → 显示"失败+重试"按钮
6. 用户点击"开始" → ElMessageBox.confirm("确认开始XX环节?")
7. 确认 → useFlowStore().startPhase(phaseType)
8. 成功 → 状态更新 + WebSocket推送 → 卡片自动刷新
9. 失败 → ElMessage.error(错误信息, 如"前置依赖未完成")

环节详情:
1. 用户点击PhaseCard → 展开详情面板(或切换到对应Tab)
2. 详情面板展示: 该环节下各集群的状态表格(ClusterTable)
3. 不同环节显示不同详情:
   - RESOURCE_APPLY: ResourceApplyPanel
   - CHECK: CheckViewPanel
   - MONITOR: MonitorViewPanel
   - DEPLOY: DeployViewPanel
   - DRILL: DrillViewPanel

WebSocket实时更新:
1. 收到推送 → useFlowStore().updateFromWS(data)
2. Vue响应式 → PhaseCard自动更新状态
3. 集群表格 → 对应cluster的status/detail自动更新
4. 不需要手动刷新页面

页面离开:
1. 路由离开 → useWSStore().disconnect() → 断开WebSocket
2. useFlowStore().clearFlow() → 清空状态
```

**组件结构与布局**:

```
FlowDetail.vue
  ├── 顶部: 流程基本信息(flow_name, idc_name, status, creator)
  ├── 主体: 5个PhaseCard纵向排列
  │     ├── PhaseCard(RESOURCE_APPLY, Sort=1)
  │     ├── PhaseCard(CHECK, Sort=2)
  │     ├── 并行行: PhaseCard(MONITOR, Sort=3) | PhaseCard(DEPLOY, Sort=3)  ★ 并行排列
  │     ├── PhaseCard(DRILL, Sort=5)
  │     └── 每个PhaseCard:
  │           ├── 状态标签: ElTag(color按status)
  │           ├── 触发按钮: ElButton(按status显示不同按钮)
  │           ├── 失败原因: ElText(FAILED时显示fail_reason)
  │           └── 展开详情: ElCollapse → 对应环节的详情面板
  ├── WebSocket连接状态指示器(右上角小图标)
  │     ├── 绿点=已连接, 红点=断开, 黄点=重连中
```

### 5.3 ResourceApplyPanel — 资源申请环节面板

**功能**: 初始化资源申请、修改/删除/新增条目、确认提交

**交互流程**:

```
初始化资源申请:
1. 用户点击"初始化"按钮 → 弹出Dialog输入refIDC
2. 调用 POST /api/v1/flows/:id/resource/init {ref_idc: input}
3. 成功 → 返回items列表 → 渲染到表格
4. 失败 → ElMessage.error

修改条目:
1. 表格中每行有"编辑"按钮 → 弹出ElDialog编辑表单
2. 允许修改: ClusterName, MWType(下拉选择), IDC, Env, NodeCount, CPU, Memory, Disk
3. 不可修改: IPs, DeliverStatus, FailReason (灰显)
4. 修改完成 → 调用 PUT /api/v1/resource/items/:id
5. 成功 → 刷新列表

删除条目:
1. 表格中每行有"删除"按钮 → ElMessageBox.confirm("确认删除?")
2. 确认 → 调用 DELETE /api/v1/resource/items/:id
3. 成功 → 行从表格消失(逻辑删除, 后端返回成功即可)

新增条目:
1. 用户点击"新增"按钮 → 弹出ElDialog新增表单
2. 必填: ClusterName, MWType(下拉选择), IDC, NodeCount
3. 可选: CPU, Memory, Disk, Env(默认prod)
4. 提交 → 调用 POST /api/v1/flows/:id/resource/items
5. 成功 → 刷新列表

确认提交:
1. 用户点击"确认提交"按钮 → ElMessageBox.confirm("确认提交所有资源申请?")
2. 确认 → 调用 POST /api/v1/flows/:id/resource/submit
3. 成功 → 显示提交结果汇总(total/success/failed)
4. 若有部分失败 → 显示失败集群列表+失败原因 → 用户可单独重试失败集群
5. 全部成功 → flowStore.completePhase('RESOURCE_APPLY')
```

**表格列定义**:

| 列名 | 字段 | 编辑 | 说明 |
|------|------|------|------|
| 集群名称 | cluster_name | 可编辑 | |
| 中间件类型 | mw_type | 可编辑(下拉) | 枚举值 |
| 机房 | idc | 可编辑 | |
| 环境 | env | 可编辑(下拉) | dev/test/prod |
| 节点数 | node_count | 可编辑 | >0 |
| CPU | cpu | 可编辑 | 如"4C" |
| 内存 | memory | 可编辑 | 如"8G" |
| 磁盘 | disk | 可编辑 | 如"100G" |
| 交付状态 | deliver_status | 不可编辑 | 标签展示 |
| 交付IP | ips | 不可编辑 | JSON数组展示 |
| 失败原因 | fail_reason | 不可编辑 | 仅SUBMIT_FAILED时显示 |
| 操作 | — | — | 编辑/删除按钮 |

**状态与按钮关系**:

| ResourceApply.Status | 表格操作按钮 | 提交按钮 |
|---------------------|------------|---------|
| DRAFT | 编辑/删除/新增 | 显示"确认提交" |
| SUBMITTED | 无(灰显) | 隐藏 |
| PARTIAL_SUBMITTED | 无(灰显) | 隐藏, 但显示失败集群重试按钮 |
| SUBMIT_FAILED | 无(灰显) | 显示"重新提交" |

### 5.4 CheckViewPanel — 核查环节面板

**功能**: 查询交付状态、执行核查、查看核查结果明细、查看日志

**交互流程**:

```
查询交付状态:
1. 用户点击"查询交付状态"按钮
2. 调用 GET /api/v1/flows/:id/check/deliver-status
3. 返回 → 展示交付状态表格(cluster_name, deliver_status, expected_count, actual_count)
4. DeliverStatus标签颜色: FULL=绿, PARTIAL=黄, NONE=红, SUBMIT_FAILED=灰

执行核查:
1. 用户在表格中选择一个集群 → 点击"执行核查"按钮
2. 调用 POST /api/v1/flows/:id/check/execute?cluster=xxx
3. 成功 → 返回check_records → 展示核查结果
4. 失败 → ElMessage.error
5. ★ 核查可能耗时较长(SSH执行脚本), 前端显示loading状态
6. WebSocket推送核查完成 → 自动更新结果

查看核查明细:
1. 点击集群行的"查看明细" → 展开核查结果子表格
2. 调用 GET /api/v1/flows/:id/check/detail?cluster=xxx
3. 展示每条CheckRecord: rule_name, scope, check_type, result(PASS/FAIL标签), execute_time

查看核查日志:
1. 点击某条CheckRecord的"查看日志" → 打开LogViewer弹窗
2. 调用 GET /api/v1/check/records/:id/log?start=0&count=100
3. LogViewer分页展示(100行/页)
```

**核查结果表格列**:

| 列名 | 字段 | 说明 |
|------|------|------|
| 集群名称 | cluster_name | |
| 交付状态 | deliver_status | 标签(FULL/PARTIAL/NONE) |
| 申请节点 | expected_count | |
| 已交付节点 | actual_count | |
| 核查结果 | check_result | 全部PASS=绿标签, 有FAIL=红标签 |
| 操作 | — | 执行核查/查看明细 |

### 5.5 DeployViewPanel — 部署环节面板

**功能**: 查看可部署集群、触发部署、查看三阶段进度、重试失败部署、查看日志

**交互流程**:

```
查看可部署集群:
1. 面板初始化 → 调用 GET /api/v1/flows/:id/deploy/clusters
2. 展示核查通过的集群列表(含部署参数)

触发部署:
1. 用户选择集群 → 点击"触发部署"按钮
2. 弹出参数确认Dialog: 展示DeployConfig的参数(可修改默认值)
3. 确认 → 调用 POST /api/v1/flows/:id/deploy/trigger?cluster=xxx
4. 成功 → 部署状态变为PENDING/VALIDATING → DeployProgress组件展示
5. WebSocket推送 → DeployProgress自动更新进度

查看部署进度(DeployProgress组件):
1. 三阶段进度条: 校验(VALIDATE) → 部署(DEPLOY) → 验证(VERIFY)
2. 每阶段状态: PENDING(灰色)/RUNNING(蓝色动画)/DONE(绿色)/FAILED(红色)
3. WebSocket推送 → 阶段状态自动更新

重试失败部署:
1. FAILED状态的集群 → 显示"重试"按钮
2. 点击 → 调用 POST /api/v1/deploy/:id/retry
3. 成功 → 进度重置为PENDING → DeployProgress重新开始

查看部署日志:
1. 点击某阶段的"查看日志" → 打开LogViewer
2. 调用 GET /api/v1/deploy/:id/log?stage=xxx&start=0&count=100
3. LogViewer分页展示
```

**DeployProgress 组件**:

```
<DeployProgress :deployDetail="detail">
  ├── 三个阶段卡片(ElStep组件)
  │     ├── VALIDATE: icon=校验, status=PENDING/RUNNING/DONE/FAILED
  │     ├── DEPLOY:  icon=部署, status=...
  │     ├── VERIFY:  icon=验证, status=...
  ├── 每个阶段卡片:
  │     ├── 状态图标: ElIcon(根据status变色)
  │     ├── 开始/结束时间
  │     ├── 查看日志按钮(LogFilePath非空时显示)
  │     └── 失败原因(FAILED时显示)
  └── 部署记录信息(deploy_id, task_id, retry_count)
```

### 5.6 MonitorViewPanel — 监控环节面板

**功能**: 部署监控服务、配置监控、查看状态和日志

**交互流程**:

```
触发监控部署:
1. 用户选择IP列表(从交付状态中获取可用的IP)
2. 点击"部署监控"按钮 → 调用 POST /api/v1/flows/:id/monitor/deploy {ips: [...]}
3. 成功 → DeployStatus=PENDING/RUNNING → WebSocket推送更新

触发监控配置:
1. ★ 前提: DeployStatus=DONE (前端校验, 不显示按钮直到部署完成)
2. 用户选择集群 → 点击"配置监控" → 调用 POST /api/v1/flows/:id/monitor/config {clusters: [...]}
3. 成功 → ConfigStatus=PENDING/RUNNING → WebSocket推送更新

查看监控状态:
1. 面板实时展示两个状态卡片:
   - DeployStatus卡片: PENDING/RUNNING/DONE/FAILED + 日志链接
   - ConfigStatus卡片: PENDING/RUNNING/DONE/FAILED + 配置详情
2. WebSocket推送 → 两个卡片独立更新

查看监控日志:
1. 点击"查看部署日志" → LogViewer → GET /api/v1/flows/:id/monitor/log?start=0&count=100

查看配置详情:
1. ConfigStatus=DONE时 → 显示"查看配置详情"按钮
2. 调用 GET /api/v1/flows/:id/monitor/status → 获取ConfigDetail JSON
3. 展示配置结果: 哪些集群完成了哪些监控配置
```

**监控状态展示布局**:

```
MonitorViewPanel
  ├── DeployStatus卡片(ElCard)
  │     ├── 状态标签: PENDING/RUNNING/DONE/FAILED
  │     ├── IPs列表(JSON数组展示)
  │     ├── TaskID
  │     ├── 开始/结束时间
  │     ├── 触发部署按钮(PENDING/FAILED时显示)
  │     └── 查看日志按钮(DONE/FAILED时显示)
  ├── ConfigStatus卡片(ElCard)
  │     ├── 状态标签: PENDING/RUNNING/DONE/FAILED
  │     ├── TaskID
  │     ├── 触发配置按钮(DeployStatus=DONE且ConfigStatus非RUNNING时显示)
  │     └── 查看配置详情按钮(ConfigStatus=DONE时显示)
```

### 5.7 DrillViewPanel — 演练环节面板

**功能**: 查看可演练集群、执行演练(全场景/指定场景)、查看结果、重试失败、查看日志

**交互流程**:

```
查看可演练集群:
1. 面板初始化 → 调用 GET /api/v1/flows/:id/drill/clusters
2. 展示部署完成(DONE)的集群列表 + 各集群演练状态(NONE/PARTIAL/ALL_DONE/FAILED)

执行全场景演练:
1. 用户选择集群 → 点击"一键演练"按钮
2. ElMessageBox.confirm("确认执行全部演练场景?")
3. 确认 → 调用 POST /api/v1/flows/:id/drill/execute?cluster=xxx (body: {} 或 scene_ids为空)
4. 成功 → 返回drill_records → 展示演练进度

执行指定场景演练:
1. 用户点击"选择场景演练" → 弹出Dialog展示匹配的场景列表
2. 场景列表: 从matchScenes获取 COMMON/MW_TYPE/CLUSTER 三层场景
3. 用户勾选场景 → 确认 → 调用 POST /api/v1/flows/:id/drill/execute?cluster=xxx {scene_ids: [1,3,5]}
4. 成功 → 展示指定场景的演练结果

查看演练结果(DrillProgress组件):
1. 每个场景一个结果卡片: scene_name, scope, status(PASS/FAIL标签)
2. 点击卡片 → 展开步骤结果: 每步的执行详情(nodes/api_result)

重试失败演练:
1. FAILED状态的场景 → 显示"重试"按钮
2. 点击 → 调用 POST /api/v1/drill/:id/retry
3. 成功 → 重新执行该场景

查看演练日志:
1. 点击某场景的"查看日志" → LogViewer → GET /api/v1/drill/records/:id/log?start=0&count=100
```

### 5.8 AdminView.vue — 管理配置页

**功能**: 三个Tab管理核查规则/演练场景/部署配置

**交互流程**:

```
核查规则Tab:
1. 列表: GET /api/v1/check-rules?scope=xxx&mw_type=xxx → ElTable
2. 创建: 点击"新增规则" → 弹出Dialog
   - 表单: RuleName, Scope(下拉COMMON/MW_TYPE/CLUSTER), MWType(条件显示), ClusterRegex(条件显示)
   - CheckType(下拉SCRIPT/API), CheckContent(文本区)
   - JudgeRule: 根据mode动态显示不同字段
     - status_code: Expected(数字输入)
     - json_field: FieldPath(文本) + Expected(文本)
     - keyword: Expected(文本)
     - value_range: FieldPath(文本) + Min(数字) + Max(数字)
   - Sort(数字)
3. 提交 → POST /api/v1/check-rules → 刷新列表
4. 编辑/删除: 行操作按钮

演练场景Tab:
1. 列表: GET /api/v1/drill-scenes → ElTable
2. 创建: 弹出Dialog
   - 表单: SceneName, Scope, MWType, ClusterRegex(同上条件)
   - Steps编辑器: ★ 关键组件
     每个Step: Name(文本), Type(下拉SHELL/ANSIBLE/API), Content(文本区), Target(IP输入, 可空)
     支持添加/删除/排序步骤
3. 提交 → POST /api/v1/drill-scenes → 刷新列表

部署配置Tab:
1. 列表: GET /api/v1/deploy-configs → ElTable
2. 创建: 弹出Dialog
   - 表单: NameRegex(正则), MWType(下拉)
   - Params编辑器: 每个Param: Name(文本), Default(文本), WidgetType(下拉input/select/textarea/number)
     支持添加/删除参数
3. 提交 → POST /api/v1/deploy-configs → 刷新列表
```

**JudgeRule 动态表单逻辑**:

```
// ★ 弱模型最容易出错的地方: JudgeRule有4种mode, 每种需要不同字段
// 前端必须根据mode动态切换表单

<JudgeRuleForm v-model="rule.judge_rule">
  ├── Mode选择: ElSelect(status_code/json_field/keyword/value_range)
  ├── mode=status_code:
  │     └── Expected: ElInputNumber(整数)
  ├── mode=json_field:
  │     ├── FieldPath: ElInput(如"data.status")
  │     └── Expected: ElInput(如"ok")
  ├── mode=keyword:
  │     └── Expected: ElInput(如"connection refused")
  ├── mode=value_range:
  │     ├── FieldPath: ElInput(如"data.cpu_usage")
  │     ├── Min: ElInputNumber
  │     └── Max: ElInputNumber
  └── 最终构造JSON: {mode: selectedMode, ...对应字段}
```

**Steps 编辑器组件**:

```
<StepsEditor v-model="scene.steps">
  ├── 步骤列表(ElDraggable排序):
  │     └── 每行: StepName(ElInput) + Type(ElSelect:SHELL/ANSIBLE/API) 
  │                + Content(ElInput textarea) + Target(ElInput, placeholder="空=全部节点")
  │                + 删除按钮
  ├── 添加步骤按钮 → 新增一行空步骤
  ├── Target字段提示: "空=全部节点执行, 单IP=指定节点, 多IP逗号分隔"
```

## 6. 公共组件

### 6.1 PhaseCard.vue — 环节状态卡片

**Props**:

```typescript
interface PhaseCardProps {
    phaseType: string       // RESOURCE_APPLY/CHECK/MONITOR/DEPLOY/DRILL
    status: string          // PENDING/RUNNING/DONE/FAILED
    isParallel: boolean     // MONITOR/DEPLOY标记并行
    failReason: string      // FAILED时有值
    sort: number            // 排序号
    startTime: string | null
    endTime: string | null
    clusters: ClusterStatusVO[]  // 该环节集群维度明细
}
```

**Emits**:

```typescript
interface PhaseCardEmits {
    (e: 'start', phaseType: string): void    // 用户点击"开始"按钮
    (e: 'complete', phaseType: string): void // 用户点击"完成"按钮
    (e: 'retry', phaseType: string): void    // 用户点击"重试"按钮(FAILED→重新触发)
    (e: 'detail', phaseType: string): void   // 用户点击查看详情
}
```

**渲染逻辑**:

```
1. 卡片头部: phaseType中文名 + 状态标签(ElTag, color按status)
2. PENDING → 显示"开始"按钮(ElButton primary)
3. RUNNING → 显示"进行中..."标签(ElTag warning) + 禁用按钮
4. DONE → 显示"已完成"标签(ElTag success) + "查看详情"按钮
5. FAILED → 显示"失败"标签(ElTag danger) + 失败原因文本 + "重试"按钮
6. 时间信息: startTime~endTime 或 "尚未开始"
7. 集群明细: 集群数量 + 通过/失败统计
```

**PhaseType中文名映射**:

```typescript
const phaseNameMap = {
    RESOURCE_APPLY: '资源申请',
    CHECK: '资源核查',
    MONITOR: '监控部署',
    DEPLOY: '服务部署',
    DRILL: '自动演练',
}
```

**Status颜色映射**:

```typescript
const statusColorMap = {
    PENDING: 'info',    // 灰色
    RUNNING: 'warning', // 黄色
    DONE: 'success',    // 绿色
    FAILED: 'danger',   // 红色
}
```

### 6.2 LogViewer.vue — 日志分页查看器

**Props**:

```typescript
interface LogViewerProps {
    title: string          // 日志标题(如"部署日志-VALIDATE阶段")
    apiUrl: string         // API URL(如"/api/v1/deploy/1/log")
    pageSize: number       // 固定100行/页
}
```

**交互流程**:

```
1. 组件初始化 → 调用 apiUrl + ?start=0&count=100 → 获取第1页
2. 渲染日志内容(ElScrollbar包裹, 每行带行号)
3. 行号计算: 第1页行号1~100, 第2页101~200
4. 分页: ElPagination(total=总行数, pageSize=100)
5. 切换页码 → 调用 apiUrl + ?start=(page-1)*100&count=100
6. 总行数: 从后端响应的headers或metadata获取(后端可返回totalLines)
   ★ 如果后端不返回totalLines → 前端持续请求直到返回空列表来确定总页数
```

**渲染格式**:

```
<div class="log-viewer">
  <ElScrollbar height="400px">
    <div v-for="(line, index) in lines" :key="index" class="log-line">
      <span class="line-number">{{ startLine + index + 1 }}</span>
      <span class="line-content">{{ line }}</span>
    </div>
  </ElScrollbar>
  <ElPagination 
    :total="totalLines" 
    :page-size="100"
    @current-change="onPageChange"
  />
</div>
```

### 6.3 ClusterTable.vue — 集群列表表格

**Props**:

```typescript
interface ClusterTableProps {
    clusters: ClusterStatusVO[]   // 集群数据
    columns: TableColumnConfig[]  // 列配置(不同环节不同列)
    loading: boolean              // 加载状态
}
```

**通用列定义**:

| 环节 | 额外列 |
|------|--------|
| RESOURCE_APPLY | mw_type, node_count, cpu, memory, disk, deliver_status, ips |
| CHECK | mw_type, deliver_status, check_result(PASS/FAIL汇总) |
| DEPLOY | mw_type, deploy_status, deploy_progress(三阶段) |
| MONITOR | deploy_status, config_status |
| DRILL | mw_type, drill_status, scene_count, done_count, fail_count |

## 7. 页面生命周期与数据流

### FlowDetail.vue 生命周期

```
mounted():
  1. flowStore.loadFlowStatus(route.params.id)
  2. wsStore.connect(route.params.id)

unmounted():
  1. wsStore.disconnect()
  2. flowStore.clearFlow()

watch(route.params.id):
  1. 若flowID变化 → flowStore.loadFlowStatus(newID)
  2. wsStore.disconnect() → wsStore.connect(newID)
```

### WebSocket → UI 更新链路

```
后端事件 → WebSocket推送 → wsStore.onmessage → flowStore.updateFromWS → Vue响应式 → PhaseCard自动重渲染

完整链路:
DeployService.TriggerDeploy → 后台轮询更新DB → WebSocket.PushStatus
→ ws.send(JSON) → wsStore.ws.onmessage → JSON.parse(data)
→ flowStore.updateFromWS(data) → phases[DEPLOY].status = data.status
→ PhaseCard(Deploy).status = 'RUNNING' → ElTag颜色自动变黄
```

## 8. 错误处理与边界情况

### 前端错误处理统一模式

| 场景 | 处理 |
|------|------|
| API返回code!=0 | ElMessage.error(body.msg) |
| 401 JWT过期 | 清除token → 路跳转/login |
| 429 限流 | ElMessage.warning("请求频繁") |
| 网络错误(超时/DNS) | ElMessage.error("网络错误") |
| 前置依赖未完成 | ElMessage.error(后端msg, 如"核查环节尚未完成") |
| WebSocket断开 | 自动重连(3秒间隔,最多5次) → 右上角状态指示器 |
| WebSocket重连超过5次 | 指示器显示红点+提示"连接断开, 请刷新页面" |
| 参数校验失败 | ElForm校验 + 红色提示(不调用API) |

### 前端边界情况

| 场景 | 处理 |
|------|------|
| 流程列表为空 | 显示空状态ElEmpty("暂无交付流程, 点击新建") |
| 集群列表为空 | 显示空状态ElEmpty("暂无数据") |
| 部署三阶段未开始 | DeployProgress显示3个PENDING灰色图标 |
| 核查结果全PASS | 标签绿色 + 显示"核查通过"汇总 |
| 核查结果有FAIL | 标签红色 + 展示失败规则明细 |
| 监控Deploy未完成时Config按钮 | 隐藏配置按钮(前端校验DeployStatus=DONE才显示) |
| 演练场景为空Steps | DrillRecord直接标记DONE, 前端显示"无步骤" |
| JudgeRule不同mode | 动态表单切换(见5.8节) |
| Scope条件显示(MW_TYPE→MWType必填) | 动态表单切换 |
| 长时间操作(SSH脚本执行) | 显示loading + 提示"执行中, 请等待" |
| 日志文件为空 | LogViewer显示"暂无日志内容" |
| 部署重试(taskID空/非空) | 前端统一调用retry API, 后端处理不同路径 |

## 9. CSS与设计规范

**配色方案**:

| 状态 | ElementPlus Tag type | 额外说明 |
|------|---------------------|---------|
| PENDING | info(灰) | 尚未开始 |
| RUNNING | warning(黄) | 进行中, 可加闪烁动画 |
| DONE | success(绿) | 完成 |
| FAILED | danger(红) | 失败 |

**布局规范**:
- 页面宽度: 1200px 居中
- PhaseCard宽度: 100%, MONITOR和DEPLOY各占50%并排
- 表格默认高度: 400px(ElScrollbar)
- Dialog宽度: 600px(创建/编辑), 800px(日志查看)

## 10. TypeScript 类型定义

> 所有接口与后端VO对齐，字段名使用snake_case（JSON序列化与后端一致）。弱模型实现时必须使用这些类型，不得自行定义替代类型。

### 10.1 核心VO接口

```typescript
// ★ 流程总览VO — 对应后端 FlowStatusVO (Step 4.1)
interface FlowStatusVO {
  flow_id: number
  flow_name: string
  idc_name: string
  status: string            // INIT/APPLYING/APPLIED/CHECKING/CHECKED/MONITORING/DEPLOYING/DEPLOYED/DRILLING/DRILLED/DONE
  creator: string
  create_time: string       // ISO8601格式
  phases: PhaseStatusVO[]
}

// ★ 环节状态VO — 对应后端 PhaseStatusVO (Step 4.1)
interface PhaseStatusVO {
  phase_type: PhaseType
  status: PhaseStatus
  is_parallel: boolean
  fail_reason: string
  sort: number
  start_time: string | null
  end_time: string | null
  clusters: ClusterStatusVO[]
}

// ★ 集群状态VO — 对应后端 ClusterStatusVO (Step 4.1)
interface ClusterStatusVO {
  cluster_name: string
  mw_type: string
  status: string            // 由业务模块决定: PASS/FAIL/DONE/FAILED/各模块自有状态枚举
  detail: string            // JSON字符串, 各环节明细不同
}
```

### 10.2 资源申请VO接口

```typescript
// ★ 交付状态VO — 对应后端 DeliverStatusVO (Step 5.3)
interface DeliverStatusVO {
  cluster_name: string
  mw_type: string
  idc: string
  deliver_status: DeliverStatus
  expected_count: number
  actual_count: number
}

// ★ ResourceApplyItem — 前端展示版, 对应后端 model.ResourceApplyItem (Step 2.1)
interface ResourceApplyItem {
  id: number
  apply_id: number
  cluster_name: string
  mw_type: MWType
  idc: string
  env: string               // dev/test/prod
  node_count: number
  cpu: string               // 如 "4C"
  memory: string            // 如 "8G"
  disk: string              // 如 "100G"
  ips: string               // JSON数组字符串, 已交付IP列表
  deliver_status: DeliverStatus
  fail_reason: string       // CMDB提交失败原因
  status: string            // ENABLE/DISABLE, 逻辑删除标记
}
```

### 10.3 部署VO接口

```typescript
// ★ 可部署集群VO — 对应后端 ClusterDeployVO (Step 6.2)
interface ClusterDeployVO {
  cluster_name: string
  mw_type: MWType
  node_count: number
  ips: string               // JSON数组字符串
  deploy_config_id: number  // 匹配的DeployConfig.ID, 0=无匹配
  params: string            // JSON字符串: 部署参数
}

// ★ 部署详情VO — 对应后端 DeployDetailVO (Step 6.2)
interface DeployDetailVO {
  deploy_id: number
  flow_id: number
  cluster_name: string
  mw_type: string
  task_id: string
  status: DeployStatus
  params: string            // JSON字符串: 部署参数
  retry_count: number
  start_time: string | null
  end_time: string | null
  stages: DeployStageVO[]
}

// ★ 部署阶段VO — 对应后端 DeployStageVO (Step 6.2)
interface DeployStageVO {
  stage: string             // VALIDATE/DEPLOY/VERIFY
  status: string            // PENDING/RUNNING/DONE/FAILED
  log_file_path: string     // MinIO日志路径
  start_time: string | null
  end_time: string | null
  signed_url: string        // MinIO签名链接(1小时有效), 前端可直接下载
}
```

### 10.4 监控VO接口

```typescript
// ★ 监控部署状态VO — 对应后端 MonitorDeployVO (Step 6.4)
interface MonitorDeployVO {
  flow_id: number
  ips: string               // JSON数组字符串: 选中的机器IP
  deploy_status: MonitorDeployStatus
  deploy_task_id: string
  deploy_log_path: string   // MinIO部署日志路径
  start_time: string | null
  end_time: string | null
}

// ★ 监控配置状态VO — 对应后端 MonitorConfigVO (Step 6.4)
interface MonitorConfigVO {
  flow_id: number
  config_status: MonitorConfigStatus
  config_task_id: string
  config_log_path: string   // MinIO配置日志路径
  config_detail: string     // JSON字符串: 配置结果详情(哪些集群完成了配置)
}
```

### 10.5 演练VO接口

```typescript
// ★ 可演练集群VO — 对应后端 ClusterDrillVO (Step 7.2)
interface ClusterDrillVO {
  cluster_name: string
  mw_type: MWType
  node_count: number
  deploy_status: string     // 固定"DONE"（只返回部署完成的集群）
  drill_status: DrillStatus // 该集群演练汇总状态
  scene_count: number       // 应演练场景数
  done_count: number        // 已完成场景数
  fail_count: number        // 失败场景数
}
```

### 10.6 管理配置模型接口

```typescript
// ★ CheckRule — 前端展示版, 对应后端 model.CheckRule (Step 2.1)
interface CheckRule {
  id: number
  rule_name: string
  scope: RuleScope
  mw_type: string           // Scope=MW_TYPE时必填
  cluster_regex: string     // Scope=CLUSTER时必填, 正则表达式
  check_type: CheckType
  check_content: string     // 脚本内容或API配置JSON
  judge_rule: JudgeRule     // ★ 判定规则对象(不是字符串, 前端需要动态表单)
  sort: number
  status: string            // ENABLE/DISABLE
  create_time: string
  update_time: string
}

// ★ JudgeRule — 判定规则, 4种mode共用一个接口
interface JudgeRule {
  mode: JudgeRuleMode
  // mode=status_code时使用:
  expected?: number
  // mode=json_field时使用:
  field_path?: string
  expected?: string         // ★ 与status_code的expected类型不同, 前端需区分
  // mode=keyword时使用:
  expected?: string
  // mode=value_range时使用:
  field_path?: string
  min?: number
  max?: number
}

// ★ DrillScene — 前端展示版, 对应后端 model.DrillScene (Step 2.1)
interface DrillScene {
  id: number
  scene_name: string
  scope: RuleScope
  mw_type: string
  cluster_regex: string
  steps: DrillStep[]        // ★ 前端直接用对象数组, 不是JSON字符串
  status: string            // ENABLE/DISABLE
  create_time: string
  update_time: string
}

// ★ DrillStep — 演练步骤
interface DrillStep {
  name: string
  type: StepType
  content: string           // 脚本内容/playbook YAML/API请求配置JSON
  target: string            // 空=全部节点执行, 单IP=指定节点, 多IP逗号分隔
}

// ★ DeployConfig — 前端展示版, 对应后端 model.DeployConfig (Step 2.1)
interface DeployConfig {
  id: number
  name_regex: string        // 集群名称正则
  mw_type: MWType
  params: DeployParam[]     // ★ 前端直接用对象数组, 不是JSON字符串
  status: string            // ENABLE/DISABLE
  create_time: string
  update_time: string
}

// ★ DeployParam — 部署参数项
interface DeployParam {
  name: string
  default: string
  widget_type: string       // input/select/textarea/number
}

// ★ SysConfig — 前端展示版, 对应后端 model.SysConfig (Step 2.1)
interface SysConfig {
  id: number
  config_key: string
  config_group: string
  config_value: string      // ★ 敏感配置前端显示"****", 非敏感显示明文
  is_sensitive: boolean
  version: number
  status: string            // ENABLE/DISABLE
  operator: string
  create_time: string
  update_time: string
}
```

### 10.7 业务记录接口

```typescript
// ★ CheckRecord — 前端展示版, 对应后端 model.CheckRecord (Step 2.1)
interface CheckRecord {
  id: number
  rule_id: number
  flow_id: number
  cluster_name: string
  scope: RuleScope
  execute_time: string
  input_params: string      // JSON字符串
  result: string            // PASS/FAIL
  detail: string            // JSON字符串: 核查明细(含多节点结果)
  fail_reason: string
  log_file_path: string     // MinIO日志路径
}

// ★ DeployRecord — 前端展示版, 对应后端 model.DeployRecord (Step 2.1)
interface DeployRecord {
  id: number
  flow_id: number
  cluster_name: string
  mw_type: MWType
  task_id: string
  status: DeployStatus
  params: string            // JSON字符串
  retry_count: number
  start_time: string | null
  end_time: string | null
}

// ★ DrillRecord — 前端展示版, 对应后端 model.DrillRecord (Step 2.1)
interface DrillRecord {
  id: number
  scene_id: number
  flow_id: number
  cluster_name: string
  scope: RuleScope
  status: string            // PENDING/RUNNING/DONE/FAILED
  start_time: string | null
  end_time: string | null
  log_file_path: string     // MinIO日志路径
  result: DrillResult       // ★ 前端用对象, 不是字符串
}

// ★ DrillResult — 演练结果JSON结构
interface DrillResult {
  steps: DrillStepResult[]
  overall_result: string    // PASS/FAIL
}

interface DrillStepResult {
  step_name: string
  status: string            // PASS/FAIL
  type: StepType
  nodes?: NodeResult[]      // SHELL/ANSIBLE步骤有此字段
  api_result?: APIResult    // API步骤有此字段
  execute_time: string
}

interface NodeResult {
  ip: string
  result: string            // PASS/FAIL
  output: string
  error: string
}

interface APIResult {
  url: string
  status_code: number
  response_body: string
  error: string
}
```

### 10.8 枚举常量

```typescript
// ★ 所有枚举使用字符串常量联合类型, 不使用enum关键字(便于与后端JSON字符串对齐)

// 环节类型 — 对应后端 FlowPhase.PhaseType
type PhaseType = 'RESOURCE_APPLY' | 'CHECK' | 'MONITOR' | 'DEPLOY' | 'DRILL'

// 环节状态 — 对应后端 FlowPhase.Status
type PhaseStatus = 'PENDING' | 'RUNNING' | 'DONE' | 'FAILED'

// 交付状态 — 对应后端 ResourceApplyItem.DeliverStatus
type DeliverStatus = 'NONE' | 'PARTIAL' | 'FULL' | 'SUBMIT_FAILED'

// 部署状态 — 对应后端 DeployRecord.Status
type DeployStatus = 'PENDING' | 'VALIDATING' | 'DEPLOYING' | 'VERIFYING' | 'DONE' | 'FAILED'

// 监控部署状态 — 对应后端 MonitorDeploy.DeployStatus
type MonitorDeployStatus = 'PENDING' | 'RUNNING' | 'DONE' | 'FAILED'

// 监控配置状态 — 对应后端 MonitorDeploy.ConfigStatus
type MonitorConfigStatus = 'PENDING' | 'RUNNING' | 'DONE' | 'FAILED'

// 演练汇总状态 — 对应后端 ClusterDrillVO.DrillStatus
type DrillStatus = 'NONE' | 'PARTIAL' | 'ALL_DONE' | 'FAILED'

// 中间件类型 — 对应后端 common/enum.go MWType
type MWType = 'nginx' | 'zookeeper' | 'kafka' | 'rocketmq' | 'minio' | 'redis'

// 规则/场景范围 — 对应后端 common/enum.go Scope
type RuleScope = 'COMMON' | 'MW_TYPE' | 'CLUSTER'

// JudgeRule模式 — 对应后端 JudgeRule JSON Schema mode字段
type JudgeRuleMode = 'status_code' | 'json_field' | 'keyword' | 'value_range'

// 步骤类型 — 对应后端 DrillScene.Steps JSON Schema type字段
type StepType = 'SHELL' | 'ANSIBLE' | 'API'

// 核查类型 — 对应后端 CheckRule.CheckType
type CheckType = 'SCRIPT' | 'API'
```

### 10.9 枚举映射表

> 弱模型实现时必须使用以下映射表，不得自行发明映射值。

```typescript
// PhaseType中文名映射
const PHASE_NAME_MAP: Record<PhaseType, string> = {
  RESOURCE_APPLY: '资源申请',
  CHECK: '资源核查',
  MONITOR: '监控部署',
  DEPLOY: '服务部署',
  DRILL: '自动演练',
}

// PhaseStatus颜色映射(ElementPlus ElTag type)
const PHASE_STATUS_COLOR_MAP: Record<PhaseStatus, string> = {
  PENDING: 'info',
  RUNNING: 'warning',
  DONE: 'success',
  FAILED: 'danger',
}

// PhaseStatus中文名映射
const PHASE_STATUS_NAME_MAP: Record<PhaseStatus, string> = {
  PENDING: '尚未开始',
  RUNNING: '进行中',
  DONE: '已完成',
  FAILED: '失败',
}

// DeliverStatus颜色映射
const DELIVER_STATUS_COLOR_MAP: Record<DeliverStatus, string> = {
  NONE: 'danger',          // 红色: 无交付
  PARTIAL: 'warning',      // 黄色: 部分交付
  FULL: 'success',         // 绿色: 全量交付
  SUBMIT_FAILED: 'info',   // 灰色: 提交失败
}

// DeliverStatus中文名映射
const DELIVER_STATUS_NAME_MAP: Record<DeliverStatus, string> = {
  NONE: '未交付',
  PARTIAL: '部分交付',
  FULL: '已交付',
  SUBMIT_FAILED: '提交失败',
}

// DeployStatus颜色映射
const DEPLOY_STATUS_COLOR_MAP: Record<DeployStatus, string> = {
  PENDING: 'info',
  VALIDATING: 'warning',
  DEPLOYING: 'warning',
  VERIFYING: 'warning',
  DONE: 'success',
  FAILED: 'danger',
}

// DeployStatus中文名映射
const DEPLOY_STATUS_NAME_MAP: Record<DeployStatus, string> = {
  PENDING: '待部署',
  VALIDATING: '校验中',
  DEPLOYING: '部署中',
  VERIFYING: '验证中',
  DONE: '部署完成',
  FAILED: '部署失败',
}

// DeployStage名称映射(三阶段)
const DEPLOY_STAGE_NAME_MAP: Record<string, string> = {
  VALIDATE: '校验',
  DEPLOY: '部署',
  VERIFY: '验证',
}

// MonitorDeployStatus颜色映射
const MONITOR_DEPLOY_STATUS_COLOR_MAP: Record<MonitorDeployStatus, string> = {
  PENDING: 'info',
  RUNNING: 'warning',
  DONE: 'success',
  FAILED: 'danger',
}

// MonitorConfigStatus颜色映射
const MONITOR_CONFIG_STATUS_COLOR_MAP: Record<MonitorConfigStatus, string> = {
  PENDING: 'info',
  RUNNING: 'warning',
  DONE: 'success',
  FAILED: 'danger',
}

// DrillStatus颜色映射
const DRILL_STATUS_COLOR_MAP: Record<DrillStatus, string> = {
  NONE: 'info',
  PARTIAL: 'warning',
  ALL_DONE: 'success',
  FAILED: 'danger',
}

// DrillStatus中文名映射
const DRILL_STATUS_NAME_MAP: Record<DrillStatus, string> = {
  NONE: '未演练',
  PARTIAL: '部分完成',
  ALL_DONE: '全部完成',
  FAILED: '有失败',
}

// MWType中文名映射
const MW_TYPE_NAME_MAP: Record<MWType, string> = {
  nginx: 'Nginx',
  zookeeper: 'Zookeeper',
  kafka: 'Kafka',
  rocketmq: 'RocketMQ',
  minio: 'MinIO',
  redis: 'Redis',
}

// RuleScope中文名映射
const RULE_SCOPE_NAME_MAP: Record<RuleScope, string> = {
  COMMON: '通用',
  MW_TYPE: '按中间件类型',
  CLUSTER: '按集群名称',
}

// JudgeRuleMode中文名映射
const JUDGE_RULE_MODE_NAME_MAP: Record<JudgeRuleMode, string> = {
  status_code: 'HTTP状态码',
  json_field: 'JSON字段',
  keyword: '关键字',
  value_range: '数值范围',
}

// StepType中文名映射
const STEP_TYPE_NAME_MAP: Record<StepType, string> = {
  SHELL: 'Shell脚本',
  ANSIBLE: 'Ansible',
  API: 'API调用',
}

// CheckType中文名映射
const CHECK_TYPE_NAME_MAP: Record<CheckType, string> = {
  SCRIPT: '脚本执行',
  API: 'API调用',
}
```

### 10.10 通用辅助类型

```typescript
// ★ 分页日志响应 — LogViewer使用
interface LogPageResult {
  lines: string[]           // 日志行内容(不含行号)
  total_lines: number       // 总行数(用于分页)
  start_line: number        // 本次起始行号(0-based)
}

// ★ ConfirmSubmit结果 — ResourceService.ConfirmAndSubmit返回
interface ConfirmSubmitResult {
  total: number             // 总集群数
  success: number           // 成功数
  failed: number            // 失败数
  failed_clusters: FailedCluster[]
}

interface FailedCluster {
  cluster_name: string
  reason: string
}

// ★ API统一响应格式(后端response.Success/Fail返回的顶层JSON)
interface APIResponse<T> {
  code: number              // 0=成功, 非0=失败
  msg: string
  req_id: string
  data: T                   // ★ 成功时axios拦截器直接返回data, 前端代码不接触整个body
  timestamp: number
}

// ★ 前端axios拦截器已处理: 成功时直接返回data, 失败时ElMessage.error+reject
// 因此API方法返回类型是T而不是APIResponse<T>
```

## 11. API 模块方法签名

> 每个API方法必须精确遵循以下签名。弱模型实现时不得修改函数名、HTTP方法、URL路径、参数类型。

### 11.1 `api/flow.ts`

```typescript
import apiClient from './request'

export const flowApi = {
  // 创建交付流程
  // POST /api/v1/flows
  // 请求体: { flow_name: string, idc_name: string, creator?: string }
  // 返回: { flow: DeliveryFlow, phases: FlowPhase[] }
  createFlow: (data: { flow_name: string; idc_name: string; creator?: string }): Promise<{
    flow: { id: number; flow_name: string; idc_name: string; status: string; creator: string; create_time: string }
    phases: PhaseStatusVO[]
  }> => apiClient.post('/flows', data),

  // 查看流程状态
  // GET /api/v1/flows/:id
  // 路径参数: id=flowID
  // 返回: FlowStatusVO
  getFlowStatus: (flowID: number): Promise<FlowStatusVO> => apiClient.get(`/flows/${flowID}`),

  // 触发环节
  // POST /api/v1/flows/:id/phases/:type/start
  // 路径参数: id=flowID, type=PhaseType
  // 无请求体
  // 返回: null (成功无数据, 仅状态更新)
  startPhase: (flowID: number, phaseType: PhaseType): Promise<void> =>
    apiClient.post(`/flows/${flowID}/phases/${phaseType}/start`),

  // 完成环节
  // POST /api/v1/flows/:id/phases/:type/complete
  // 路径参数: id=flowID, type=PhaseType
  // 无请求体
  // 返回: null
  completePhase: (flowID: number, phaseType: PhaseType): Promise<void> =>
    apiClient.post(`/flows/${flowID}/phases/${phaseType}/complete`),
}
```

### 11.2 `api/resource.ts`

```typescript
export const resourceApi = {
  // 初始化资源申请
  // POST /api/v1/flows/:id/resource/init
  // 路径参数: id=flowID
  // 请求体: { ref_idc: string }
  // 返回: ResourceApplyItem[]
  initApply: (flowID: number, data: { ref_idc: string }): Promise<ResourceApplyItem[]> =>
    apiClient.post(`/flows/${flowID}/resource/init`, data),

  // 查询资源申请列表
  // GET /api/v1/flows/:id/resource/items
  // 路径参数: id=flowID
  // 返回: ResourceApplyItem[]
  getApplyItems: (flowID: number): Promise<ResourceApplyItem[]> =>
    apiClient.get(`/flows/${flowID}/resource/items`),

  // 修改申请条目
  // PUT /api/v1/resource/items/:id
  // 路径参数: id=itemID
  // 请求体: ResourceApplyItem(仅允许修改字段: cluster_name, mw_type, idc, env, node_count, cpu, memory, disk)
  // 返回: ResourceApplyItem
  updateApplyItem: (itemID: number, data: Partial<ResourceApplyItem>): Promise<ResourceApplyItem> =>
    apiClient.put(`/resource/items/${itemID}`, data),

  // 删除申请条目(逻辑删除)
  // DELETE /api/v1/resource/items/:id
  // 路径参数: id=itemID
  // 返回: null
  deleteApplyItem: (itemID: number): Promise<void> =>
    apiClient.delete(`/resource/items/${itemID}`),

  // 新增申请条目
  // POST /api/v1/flows/:id/resource/items
  // 路径参数: id=flowID
  // 请求体: { cluster_name, mw_type, idc, node_count, env?, cpu?, memory?, disk? }
  // 返回: ResourceApplyItem
  addApplyItem: (flowID: number, data: {
    cluster_name: string; mw_type: MWType; idc: string; node_count: number;
    env?: string; cpu?: string; memory?: string; disk?: string
  }): Promise<ResourceApplyItem> =>
    apiClient.post(`/flows/${flowID}/resource/items`, data),

  // 确认提交申请
  // POST /api/v1/flows/:id/resource/submit
  // 路径参数: id=flowID
  // 无请求体
  // 返回: ConfirmSubmitResult
  confirmAndSubmit: (flowID: number): Promise<ConfirmSubmitResult> =>
    apiClient.post(`/flows/${flowID}/resource/submit`),
}
```

### 11.3 `api/check.ts`

```typescript
export const checkApi = {
  // 查询交付状态
  // GET /api/v1/flows/:id/check/deliver-status
  // 路径参数: id=flowID
  // 返回: DeliverStatusVO[]
  queryDeliverStatus: (flowID: number): Promise<DeliverStatusVO[]> =>
    apiClient.get(`/flows/${flowID}/check/deliver-status`),

  // 执行集群核查
  // POST /api/v1/flows/:id/check/execute?cluster=xxx
  // 路径参数: id=flowID
  // Query参数: cluster=clusterName
  // 无请求体
  // 返回: CheckRecord[]
  executeCheck: (flowID: number, clusterName: string): Promise<CheckRecord[]> =>
    apiClient.post(`/flows/${flowID}/check/execute?cluster=${clusterName}`),

  // 查看核查明细
  // GET /api/v1/flows/:id/check/detail?cluster=xxx
  // 路径参数: id=flowID
  // Query参数: cluster=clusterName
  // 返回: CheckRecord[]
  getCheckDetail: (flowID: number, clusterName: string): Promise<CheckRecord[]> =>
    apiClient.get(`/flows/${flowID}/check/detail?cluster=${clusterName}`),

  // 查看核查日志(分页)
  // GET /api/v1/check/records/:id/log?start=0&count=100
  // 路径参数: id=recordID
  // Query参数: start=起始行号(0-based), count=行数(固定100)
  // 返回: LogPageResult
  getCheckLog: (recordID: number, start: number, count: number = 100): Promise<LogPageResult> =>
    apiClient.get(`/check/records/${recordID}/log?start=${start}&count=${count}`),
}
```

### 11.4 `api/deploy.ts`

```typescript
export const deployApi = {
  // 查看可部署集群(核查通过的)
  // GET /api/v1/flows/:id/deploy/clusters?mw_type=xxx
  // 路径参数: id=flowID
  // Query参数: mw_type=可选筛选
  // 返回: ClusterDeployVO[]
  getCheckedClusters: (flowID: number, mwType?: string): Promise<ClusterDeployVO[]> =>
    apiClient.get(`/flows/${flowID}/deploy/clusters${mwType ? `?mw_type=${mwType}` : ''}`),

  // 触发集群部署
  // POST /api/v1/flows/:id/deploy/trigger?cluster=xxx
  // 路径参数: id=flowID
  // Query参数: cluster=clusterName
  // 无请求体(★ 部署参数由后端从DeployConfig自动匹配, 前端不传参数)
  // 返回: DeployRecord(初始状态PENDING)
  triggerDeploy: (flowID: number, clusterName: string): Promise<DeployRecord> =>
    apiClient.post(`/flows/${flowID}/deploy/trigger?cluster=${clusterName}`),

  // 重试失败部署
  // POST /api/v1/deploy/:id/retry
  // 路径参数: id=deployID(DeployRecord.ID, 不是flowID)
  // 无请求体
  // 返回: null
  retryDeploy: (deployID: number): Promise<void> =>
    apiClient.post(`/deploy/${deployID}/retry`),

  // 查看部署详情
  // GET /api/v1/flows/:id/deploy/detail?cluster=xxx
  // 路径参数: id=flowID
  // Query参数: cluster=clusterName
  // 返回: DeployDetailVO
  getDeployDetail: (flowID: number, clusterName: string): Promise<DeployDetailVO> =>
    apiClient.get(`/flows/${flowID}/deploy/detail?cluster=${clusterName}`),

  // 查看部署日志(分页)
  // GET /api/v1/deploy/:id/log?stage=xxx&start=0&count=100
  // 路径参数: id=deployID
  // Query参数: stage=VALIDATE/DEPLOY/VERIFY, start=起始行号, count=行数
  // 返回: LogPageResult
  getStageLog: (deployID: number, stage: string, start: number, count: number = 100): Promise<LogPageResult> =>
    apiClient.get(`/deploy/${deployID}/log?stage=${stage}&start=${start}&count=${count}`),
}
```

### 11.5 `api/monitor.ts`

```typescript
export const monitorApi = {
  // 触发监控部署
  // POST /api/v1/flows/:id/monitor/deploy
  // 路径参数: id=flowID
  // 请求体: { ips: string[] }
  // 返回: null(后台轮询, WebSocket推送进度)
  triggerMonitorDeploy: (flowID: number, data: { ips: string[] }): Promise<void> =>
    apiClient.post(`/flows/${flowID}/monitor/deploy`, data),

  // 触发监控配置
  // POST /api/v1/flows/:id/monitor/config
  // 路径参数: id=flowID
  // 请求体: { clusters: string[] }
  // 返回: null
  triggerMonitorConfig: (flowID: number, data: { clusters: string[] }): Promise<void> =>
    apiClient.post(`/flows/${flowID}/monitor/config`, data),

  // 查看监控部署状态
  // GET /api/v1/flows/:id/monitor/status
  // 路径参数: id=flowID
  // 返回: { deploy: MonitorDeployVO, config: MonitorConfigVO }
  // ★ 后端将DeployVO和ConfigVO合并返回, 前端拆分使用
  getMonitorDeployStatus: (flowID: number): Promise<MonitorDeployVO> =>
    apiClient.get(`/flows/${flowID}/monitor/status`).then((res: any) => res.deploy || res),

  getMonitorConfigStatus: (flowID: number): Promise<MonitorConfigVO> =>
    apiClient.get(`/flows/${flowID}/monitor/status`).then((res: any) => res.config || res),

  // 查看监控部署日志(分页)
  // GET /api/v1/flows/:id/monitor/log?start=0&count=100
  // 路径参数: id=flowID
  // Query参数: start=起始行号, count=行数
  // 返回: LogPageResult
  getMonitorDeployLog: (flowID: number, start: number, count: number = 100): Promise<LogPageResult> =>
    apiClient.get(`/flows/${flowID}/monitor/log?start=${start}&count=${count}`),
}
```

### 11.6 `api/drill.ts`

```typescript
export const drillApi = {
  // 查看可演练集群
  // GET /api/v1/flows/:id/drill/clusters?mw_type=xxx
  // 路径参数: id=flowID
  // Query参数: mw_type=可选筛选
  // 返回: ClusterDrillVO[]
  getDeployedClusters: (flowID: number, mwType?: string): Promise<ClusterDrillVO[]> =>
    apiClient.get(`/flows/${flowID}/drill/clusters${mwType ? `?mw_type=${mwType}` : ''}`),

  // 执行集群演练(全场景或指定场景)
  // POST /api/v1/flows/:id/drill/execute?cluster=xxx
  // 路径参数: id=flowID
  // Query参数: cluster=clusterName
  // 请求体: { scene_ids?: number[] } — 空或不传=全场景, 传入=指定场景
  // 返回: DrillRecord[]
  executeDrill: (flowID: number, clusterName: string, data?: { scene_ids?: number[] }): Promise<DrillRecord[]> =>
    apiClient.post(`/flows/${flowID}/drill/execute?cluster=${clusterName}`, data || {}),

  // 重试失败演练
  // POST /api/v1/drill/:id/retry
  // 路径参数: id=drillID(DrillRecord.ID)
  // 无请求体
  // 返回: null
  retryDrill: (drillID: number): Promise<void> =>
    apiClient.post(`/drill/${drillID}/retry`),

  // 查看演练明细
  // GET /api/v1/flows/:id/drill/detail?cluster=xxx
  // 路径参数: id=flowID
  // Query参数: cluster=clusterName
  // 返回: DrillRecord[]
  getDrillDetail: (flowID: number, clusterName: string): Promise<DrillRecord[]> =>
    apiClient.get(`/flows/${flowID}/drill/detail?cluster=${clusterName}`),

  // 查看演练日志(分页)
  // GET /api/v1/drill/records/:id/log?start=0&count=100
  // 路径参数: id=recordID
  // Query参数: start=起始行号, count=行数
  // 返回: LogPageResult
  getDrillLog: (recordID: number, start: number, count: number = 100): Promise<LogPageResult> =>
    apiClient.get(`/drill/records/${recordID}/log?start=${start}&count=${count}`),
}
```

### 11.7 `api/admin.ts`

```typescript
export const checkRuleApi = {
  // 核查规则列表
  // GET /api/v1/check-rules?scope=xxx&mw_type=xxx
  // Query参数: scope=可选, mw_type=可选
  // 返回: CheckRule[]
  list: (scope?: string, mwType?: string): Promise<CheckRule[]> =>
    apiClient.get('/check-rules', { params: { scope, mw_type: mwType } }),

  // 核查规则详情
  // GET /api/v1/check-rules/:id
  // 路径参数: id=ruleID
  // 返回: CheckRule
  get: (id: number): Promise<CheckRule> => apiClient.get(`/check-rules/${id}`),

  // 创建核查规则
  // POST /api/v1/check-rules
  // 请求体: CheckRule(不含id/create_time/update_time)
  // 返回: CheckRule
  create: (data: Omit<CheckRule, 'id' | 'create_time' | 'update_time'>): Promise<CheckRule> =>
    apiClient.post('/check-rules', data),

  // 更新核查规则
  // PUT /api/v1/check-rules/:id
  // 路径参数: id=ruleID
  // 请求体: CheckRule(不含id/create_time)
  // 返回: CheckRule
  update: (id: number, data: Omit<CheckRule, 'id' | 'create_time'>): Promise<CheckRule> =>
    apiClient.put(`/check-rules/${id}`, data),

  // 删除核查规则(逻辑删除)
  // DELETE /api/v1/check-rules/:id
  // 路径参数: id=ruleID
  // 返回: null
  delete: (id: number): Promise<void> => apiClient.delete(`/check-rules/${id}`),

  // 匹配核查规则(三层)
  // GET /api/v1/check-rules/match?cluster=xxx&mw_type=xxx
  // Query参数: cluster=集群名称, mw_type=中间件类型
  // 返回: CheckRule[]
  matchRules: (clusterName: string, mwType: string): Promise<CheckRule[]> =>
    apiClient.get('/check-rules/match', { params: { cluster: clusterName, mw_type: mwType } }),
}

export const drillSceneApi = {
  // 演练场景列表
  // GET /api/v1/drill-scenes?scope=xxx&mw_type=xxx
  // 返回: DrillScene[]
  list: (scope?: string, mwType?: string): Promise<DrillScene[]> =>
    apiClient.get('/drill-scenes', { params: { scope, mw_type: mwType } }),

  // 演练场景详情
  // GET /api/v1/drill-scenes/:id
  // 返回: DrillScene
  get: (id: number): Promise<DrillScene> => apiClient.get(`/drill-scenes/${id}`),

  // 创建演练场景
  // POST /api/v1/drill-scenes
  // 请求体: DrillScene(不含id/create_time/update_time, steps为对象数组)
  // ★ 前端提交时steps需要JSON.stringify为字符串, 后端存储为text字段
  // 返回: DrillScene
  create: (data: Omit<DrillScene, 'id' | 'create_time' | 'update_time'>): Promise<DrillScene> =>
    apiClient.post('/drill-scenes', { ...data, steps: JSON.stringify(data.steps) }),

  // 更新演练场景
  // PUT /api/v1/drill-scenes/:id
  // 返回: DrillScene
  update: (id: number, data: Omit<DrillScene, 'id' | 'create_time'>): Promise<DrillScene> =>
    apiClient.put(`/drill-scenes/${id}`, { ...data, steps: JSON.stringify(data.steps) }),

  // 删除演练场景(逻辑删除)
  // DELETE /api/v1/drill-scenes/:id
  // 返回: null
  delete: (id: number): Promise<void> => apiClient.delete(`/drill-scenes/${id}`),

  // 匹配演练场景(三层)
  // GET /api/v1/drill-scenes/match?cluster=xxx&mw_type=xxx
  // 返回: DrillScene[]
  matchScenes: (clusterName: string, mwType: string): Promise<DrillScene[]> =>
    apiClient.get('/drill-scenes/match', { params: { cluster: clusterName, mw_type: mwType } }),
}

export const deployConfigApi = {
  // 部署配置列表
  // GET /api/v1/deploy-configs?mw_type=xxx
  // 返回: DeployConfig[]
  list: (mwType?: string): Promise<DeployConfig[]> =>
    apiClient.get('/deploy-configs', { params: { mw_type: mwType } }),

  // 部署配置详情
  // GET /api/v1/deploy-configs/:id
  // 返回: DeployConfig
  get: (id: number): Promise<DeployConfig> => apiClient.get(`/deploy-configs/${id}`),

  // 创建部署配置
  // POST /api/v1/deploy-configs
  // ★ 前端提交时params需要JSON.stringify为字符串
  // 返回: DeployConfig
  create: (data: Omit<DeployConfig, 'id' | 'create_time' | 'update_time'>): Promise<DeployConfig> =>
    apiClient.post('/deploy-configs', { ...data, params: JSON.stringify(data.params) }),

  // 更新部署配置
  // PUT /api/v1/deploy-configs/:id
  // 返回: DeployConfig
  update: (id: number, data: Omit<DeployConfig, 'id' | 'create_time'>): Promise<DeployConfig> =>
    apiClient.put(`/deploy-configs/${id}`, { ...data, params: JSON.stringify(data.params) }),

  // 删除部署配置(逻辑删除)
  // DELETE /api/v1/deploy-configs/:id
  // 返回: null
  delete: (id: number): Promise<void> => apiClient.delete(`/deploy-configs/${id}`),
}
```

## 12. Pinia Store 模块级定义

> 补充 flow.ts 和 websocket.ts 之外的业务 Store。每个 Store 与 flow.ts 的交互通过 `useFlowStore()` 调用完成。

### 12.1 `stores/resource.ts` — 资源申请状态管理

```typescript
import { defineStore } from 'pinia'
import { resourceApi } from '@/api/resource'
import { useFlowStore } from './flow'

interface ResourceState {
  items: ResourceApplyItem[]    // 资源申请条目列表
  applyStatus: string           // ResourceApply.Status: DRAFT/SUBMITTED/PARTIAL_SUBMITTED/SUBMIT_FAILED
  applyID: number | null        // ResourceApply.ID
}

export const useResourceStore = defineStore('resource', {
  state: (): ResourceState => ({
    items: [],
    applyStatus: '',
    applyID: null,
  }),

  actions: {
    // 初始化资源申请
    // 调用: resourceApi.initApply
    // 入参: flowID, refIDC
    // 返回: void(内部更新items)
    // ★ 初始化后applyStatus=DRAFT, 前端显示编辑/删除/新增/提交按钮
    async initApply(flowID: number, refIDC: string) {
      const items = await resourceApi.initApply(flowID, { ref_idc: refIDC })
      this.items = items
      this.applyStatus = 'DRAFT'
      this.applyID = items.length > 0 ? items[0].apply_id : null
    },

    // 加载资源申请条目列表
    // 调用: resourceApi.getApplyItems
    // 入参: flowID
    // 返回: void(内部更新items)
    async loadItems(flowID: number) {
      this.items = await resourceApi.getApplyItems(flowID)
      // 从items推断applyStatus(后端ResourceApply.Status通过条目deliver_status间接反映)
      // ★ 若所有item.deliver_status=SUBMITTED → applyStatus=SUBMITTED
      // ★ 若存在SUBMIT_FAILED → applyStatus=PARTIAL_SUBMITTED或SUBMIT_FAILED
    },

    // 修改申请条目
    // 调用: resourceApi.updateApplyItem
    // 入参: itemID, data(仅允许修改的字段)
    // 返回: void(内部更新对应item)
    // ★ 仅applyStatus=DRAFT时允许调用, 否则前端禁用按钮
    async updateItem(itemID: number, data: Partial<ResourceApplyItem>) {
      const updated = await resourceApi.updateApplyItem(itemID, data)
      const index = this.items.findIndex(i => i.id === itemID)
      if (index >= 0) this.items[index] = updated
    },

    // 删除申请条目(逻辑删除)
    // 调用: resourceApi.deleteApplyItem
    // 入参: itemID
    // 返回: void(内部移除item从列表)
    // ★ 仅applyStatus=DRAFT时允许调用
    async deleteItem(itemID: number) {
      await resourceApi.deleteApplyItem(itemID)
      this.items = this.items.filter(i => i.id !== itemID)
    },

    // 新增申请条目
    // 调用: resourceApi.addApplyItem
    // 入参: flowID, data
    // 返回: void(内部追加item到列表)
    // ★ 仅applyStatus=DRAFT时允许调用
    async addItem(flowID: number, data: {
      cluster_name: string; mw_type: MWType; idc: string; node_count: number;
      env?: string; cpu?: string; memory?: string; disk?: string
    }) {
      const newItem = await resourceApi.addApplyItem(flowID, data)
      this.items.push(newItem)
    },

    // 确认提交申请
    // 调用: resourceApi.confirmAndSubmit
    // 入参: flowID
    // 返回: ConfirmSubmitResult
    // ★ 与flowStore交互: 提交成功后调用flowStore.completePhase('RESOURCE_APPLY')
    async confirmSubmit(flowID: number): Promise<ConfirmSubmitResult> {
      const result = await resourceApi.confirmAndSubmit(flowID)
      // 更新applyStatus
      if (result.failed === 0) {
        this.applyStatus = 'SUBMITTED'
      } else if (result.success > 0) {
        this.applyStatus = 'PARTIAL_SUBMITTED'
      } else {
        this.applyStatus = 'SUBMIT_FAILED'
      }
      // ★ 至少部分成功 → 推进流程环节
      if (result.success > 0) {
        const flowStore = useFlowStore()
        await flowStore.completePhase('RESOURCE_APPLY')
      }
      // 刷新items(deliver_status已更新)
      await this.loadItems(flowID)
      return result
    },
  },
})
```

### 12.2 `stores/check.ts` — 核查状态管理

```typescript
import { defineStore } from 'pinia'
import { checkApi } from '@/api/check'

interface CheckState {
  deliverStatusList: DeliverStatusVO[]   // 交付状态列表
  checkRecords: CheckRecord[]            // 核查记录列表
  selectedCluster: string | null         // 当前选中的集群
}

export const useCheckStore = defineStore('check', {
  state: (): CheckState => ({
    deliverStatusList: [],
    checkRecords: [],
    selectedCluster: null,
  }),

  actions: {
    // 查询交付状态
    // 调用: checkApi.queryDeliverStatus
    // 入参: flowID
    // 返回: void(内部更新deliverStatusList)
    async queryDeliverStatus(flowID: number) {
      this.deliverStatusList = await checkApi.queryDeliverStatus(flowID)
    },

    // 执行集群核查
    // 调用: checkApi.executeCheck
    // 入参: flowID, clusterName
    // 返回: void(内部更新checkRecords)
    // ★ 核查可能耗时较长(SSH脚本执行), 显示loading
    async executeCheck(flowID: number, clusterName: string) {
      this.selectedCluster = clusterName
      this.checkRecords = await checkApi.executeCheck(flowID, clusterName)
    },

    // 加载核查明细
    // 调用: checkApi.getCheckDetail
    // 入参: flowID, clusterName
    // 返回: void(内部更新checkRecords)
    async loadCheckDetail(flowID: number, clusterName: string) {
      this.selectedCluster = clusterName
      this.checkRecords = await checkApi.getCheckDetail(flowID, clusterName)
    },

    // 加载核查日志(分页)
    // 调用: checkApi.getCheckLog
    // 入参: recordID, start, count
    // 返回: LogPageResult(直接返回, 不存state)
    async loadCheckLog(recordID: number, start: number, count: number = 100): Promise<LogPageResult> {
      return checkApi.getCheckLog(recordID, start, count)
    },
  },
})
```

### 12.3 `stores/deploy.ts` — 部署状态管理

```typescript
import { defineStore } from 'pinia'
import { deployApi } from '@/api/deploy'

interface DeployState {
  checkedClusters: ClusterDeployVO[]     // 核查通过的集群列表
  deployDetail: DeployDetailVO | null    // 当前选中集群的部署详情
  selectedCluster: string | null         // 当前选中的集群
}

export const useDeployStore = defineStore('deploy', {
  state: (): DeployState => ({
    checkedClusters: [],
    deployDetail: null,
    selectedCluster: null,
  }),

  actions: {
    // 加载核查通过的集群列表
    // 调用: deployApi.getCheckedClusters
    // 入参: flowID, mwType(可选)
    // 返回: void(内部更新checkedClusters)
    async loadCheckedClusters(flowID: number, mwType?: string) {
      this.checkedClusters = await deployApi.getCheckedClusters(flowID, mwType)
    },

    // 触发集群部署
    // 调用: deployApi.triggerDeploy
    // 入参: flowID, clusterName
    // 返回: void(WebSocket推送进度, 不需要手动刷新)
    // ★ 触发后状态由WebSocket推送更新, 前端无需再次调用API
    async triggerDeploy(flowID: number, clusterName: string) {
      this.selectedCluster = clusterName
      await deployApi.triggerDeploy(flowID, clusterName)
      // 状态由后台轮询+WebSocket推送, 前端不主动刷新
    },

    // 重试失败部署
    // 调用: deployApi.retryDeploy
    // 入参: deployID(DeployRecord.ID, 不是flowID)
    // 返回: void
    async retryDeploy(deployID: number) {
      await deployApi.retryDeploy(deployID)
    },

    // 加载部署详情
    // 调用: deployApi.getDeployDetail
    // 入参: flowID, clusterName
    // 返回: void(内部更新deployDetail)
    async loadDeployDetail(flowID: number, clusterName: string) {
      this.selectedCluster = clusterName
      this.deployDetail = await deployApi.getDeployDetail(flowID, clusterName)
    },

    // 加载部署阶段日志(分页)
    // 调用: deployApi.getStageLog
    // 入参: deployID, stage, start, count
    // 返回: LogPageResult(直接返回, 不存state)
    async loadStageLog(deployID: number, stage: string, start: number, count: number = 100): Promise<LogPageResult> {
      return deployApi.getStageLog(deployID, stage, start, count)
    },
  },
})
```

### 12.4 `stores/monitor.ts` — 监控状态管理

```typescript
import { defineStore } from 'pinia'
import { monitorApi } from '@/api/monitor'

interface MonitorState {
  deployVO: MonitorDeployVO | null      // 监控部署状态
  configVO: MonitorConfigVO | null      // 监控配置状态
}

export const useMonitorStore = defineStore('monitor', {
  state: (): MonitorState => ({
    deployVO: null,
    configVO: null,
  }),

  actions: {
    // 触发监控部署
    // 调用: monitorApi.triggerMonitorDeploy
    // 入参: flowID, ips
    // 返回: void(后台轮询, WebSocket推送)
    // ★ 前端校验: ips数组不为空才允许触发
    async triggerDeploy(flowID: number, ips: string[]) {
      await monitorApi.triggerMonitorDeploy(flowID, { ips })
      // 触发后刷新一次状态(获取初始PENDING状态)
      await this.loadDeployStatus(flowID)
    },

    // 触发监控配置
    // 调用: monitorApi.triggerMonitorConfig
    // 入参: flowID, clusters
    // 返回: void
    // ★ 前端校验: deployVO.deploy_status=DONE才允许触发(按钮条件渲染)
    async triggerConfig(flowID: number, clusters: string[]) {
      await monitorApi.triggerMonitorConfig(flowID, { clusters })
      await this.loadConfigStatus(flowID)
    },

    // 加载监控部署状态
    // 调用: monitorApi.getMonitorDeployStatus
    // 入参: flowID
    // 返回: void(内部更新deployVO)
    async loadDeployStatus(flowID: number) {
      this.deployVO = await monitorApi.getMonitorDeployStatus(flowID)
    },

    // 加载监控配置状态
    // 调用: monitorApi.getMonitorConfigStatus
    // 入参: flowID
    // 返回: void(内部更新configVO)
    async loadConfigStatus(flowID: number) {
      this.configVO = await monitorApi.getMonitorConfigStatus(flowID)
    },

    // 加载监控部署日志(分页)
    // 调用: monitorApi.getMonitorDeployLog
    // 入参: flowID, start, count
    // 返回: LogPageResult(直接返回, 不存state)
    async loadDeployLog(flowID: number, start: number, count: number = 100): Promise<LogPageResult> {
      return monitorApi.getMonitorDeployLog(flowID, start, count)
    },
  },
})
```

### 12.5 `stores/drill.ts` — 演练状态管理

```typescript
import { defineStore } from 'pinia'
import { drillApi } from '@/api/drill'

interface DrillState {
  deployedClusters: ClusterDrillVO[]     // 可演练集群列表
  drillRecords: DrillRecord[]            // 演练记录列表
  selectedCluster: string | null         // 当前选中的集群
}

export const useDrillStore = defineStore('drill', {
  state: (): DrillState => ({
    deployedClusters: [],
    drillRecords: [],
    selectedCluster: null,
  }),

  actions: {
    // 加载可演练集群列表
    // 调用: drillApi.getDeployedClusters
    // 入参: flowID, mwType(可选)
    // 返回: void(内部更新deployedClusters)
    async loadDeployedClusters(flowID: number, mwType?: string) {
      this.deployedClusters = await drillApi.getDeployedClusters(flowID, mwType)
    },

    // 执行集群演练(全场景或指定场景)
    // 调用: drillApi.executeDrill
    // 入参: flowID, clusterName, sceneIDs(可选)
    // 返回: void(内部更新drillRecords)
    // ★ 演练可能耗时较长(SSH脚本+API调用), 显示loading
    async executeDrill(flowID: number, clusterName: string, sceneIDs?: number[]) {
      this.selectedCluster = clusterName
      this.drillRecords = await drillApi.executeDrill(flowID, clusterName, sceneIDs ? { scene_ids: sceneIDs } : undefined)
    },

    // 重试失败演练
    // 调用: drillApi.retryDrill
    // 入参: drillID(DrillRecord.ID)
    // 返回: void
    // ★ 重试后需要重新加载drillRecords获取最新状态
    async retryDrill(drillID: number, flowID: number, clusterName: string) {
      await drillApi.retryDrill(drillID)
      await this.loadDrillDetail(flowID, clusterName)
    },

    // 加载演练明细
    // 调用: drillApi.getDrillDetail
    // 入参: flowID, clusterName
    // 返回: void(内部更新drillRecords)
    async loadDrillDetail(flowID: number, clusterName: string) {
      this.selectedCluster = clusterName
      this.drillRecords = await drillApi.getDrillDetail(flowID, clusterName)
    },

    // 加载演练日志(分页)
    // 调用: drillApi.getDrillLog
    // 入参: recordID, start, count
    // 返回: LogPageResult(直接返回, 不存state)
    async loadDrillLog(recordID: number, start: number, count: number = 100): Promise<LogPageResult> {
      return drillApi.getDrillLog(recordID, start, count)
    },
  },
})
```

## 13. WebSocket 推送消息 Schema

> 精确定义后端推送的所有消息类型。前端 `wsStore.onmessage` 根据 `event_type` 字段分发到对应 store 更新逻辑。

### 13.1 WSMessage 基类

```json
{
  "event_type": "string",
  "flow_id": "number",
  "timestamp": "number",
  "payload": "object"
}
```

```typescript
// ★ 前端WS消息基类
interface WSMessage {
  event_type: WSEventType
  flow_id: number
  timestamp: number         // Unix秒级时间戳
  payload: any              // 各事件类型的payload结构不同
}

// 事件类型枚举
type WSEventType =
  | 'phase_started'         // 环节启动
  | 'phase_completed'       // 环节完成
  | 'phase_failed'          // 环节失败
  | 'deploy_progress'       // 部署进度更新
  | 'monitor_deploy_progress' // 监控部署进度
  | 'monitor_config_progress' // 监控配置进度
  | 'check_completed'       // 核查完成
  | 'drill_completed'       // 演练完成
```

### 13.2 各事件类型 Payload 结构

#### phase_started — 环节启动

```json
{
  "event_type": "phase_started",
  "flow_id": 1,
  "timestamp": 1717234800,
  "payload": {
    "phase_type": "CHECK",
    "status": "RUNNING",
    "start_time": "2024-06-01T10:00:00Z"
  }
}
```

```typescript
interface PhaseStartedPayload {
  phase_type: PhaseType
  status: 'RUNNING'
  start_time: string
}
```

#### phase_completed — 环节完成

```json
{
  "event_type": "phase_completed",
  "flow_id": 1,
  "timestamp": 1717234800,
  "payload": {
    "phase_type": "RESOURCE_APPLY",
    "status": "DONE",
    "end_time": "2024-06-01T10:30:00Z"
  }
}
```

```typescript
interface PhaseCompletedPayload {
  phase_type: PhaseType
  status: 'DONE'
  end_time: string
}
```

#### phase_failed — 环节失败

```json
{
  "event_type": "phase_failed",
  "flow_id": 1,
  "timestamp": 1717234800,
  "payload": {
    "phase_type": "DEPLOY",
    "status": "FAILED",
    "fail_reason": "部署超时",
    "end_time": "2024-06-01T11:00:00Z"
  }
}
```

```typescript
interface PhaseFailedPayload {
  phase_type: PhaseType
  status: 'FAILED'
  fail_reason: string
  end_time: string
}
```

#### deploy_progress — 部署进度更新

```json
{
  "event_type": "deploy_progress",
  "flow_id": 1,
  "timestamp": 1717234800,
  "payload": {
    "cluster_name": "redis-prod-a",
    "mw_type": "redis",
    "status": "DEPLOYING",
    "current_stage": "DEPLOY",
    "stages": [
      { "stage": "VALIDATE", "status": "DONE", "start_time": "...", "end_time": "..." },
      { "stage": "DEPLOY", "status": "RUNNING", "start_time": "...", "end_time": null },
      { "stage": "VERIFY", "status": "PENDING", "start_time": null, "end_time": null }
    ]
  }
}
```

```typescript
interface DeployProgressPayload {
  cluster_name: string
  mw_type: string
  status: DeployStatus
  current_stage: string     // 当前正在执行的阶段名
  stages: DeployStageVO[]
}
```

#### monitor_deploy_progress — 监控部署进度

```json
{
  "event_type": "monitor_deploy_progress",
  "flow_id": 1,
  "timestamp": 1717234800,
  "payload": {
    "deploy_status": "RUNNING",
    "deploy_task_id": "task-123"
  }
}
```

```typescript
interface MonitorDeployProgressPayload {
  deploy_status: MonitorDeployStatus
  deploy_task_id: string
}
```

#### monitor_config_progress — 监控配置进度

```json
{
  "event_type": "monitor_config_progress",
  "flow_id": 1,
  "timestamp": 1717234800,
  "payload": {
    "config_status": "RUNNING",
    "config_task_id": "task-456"
  }
}
```

```typescript
interface MonitorConfigProgressPayload {
  config_status: MonitorConfigStatus
  config_task_id: string
}
```

#### check_completed — 核查完成

```json
{
  "event_type": "check_completed",
  "flow_id": 1,
  "timestamp": 1717234800,
  "payload": {
    "cluster_name": "redis-prod-a",
    "result": "PASS",
    "pass_count": 5,
    "fail_count": 0,
    "rule_count": 5
  }
}
```

```typescript
interface CheckCompletedPayload {
  cluster_name: string
  result: string            // PASS/FAIL(该集群核查汇总)
  pass_count: number
  fail_count: number
  rule_count: number
}
```

#### drill_completed — 演练完成

```json
{
  "event_type": "drill_completed",
  "flow_id": 1,
  "timestamp": 1717234800,
  "payload": {
    "cluster_name": "redis-prod-a",
    "drill_status": "ALL_DONE",
    "scene_count": 3,
    "done_count": 3,
    "fail_count": 0
  }
}
```

```typescript
interface DrillCompletedPayload {
  cluster_name: string
  drill_status: DrillStatus
  scene_count: number
  done_count: number
  fail_count: number
}
```

### 13.3 前端消息分发逻辑

```typescript
// ★ wsStore.onmessage 中的消息分发逻辑(补充到 stores/websocket.ts)

function dispatchWSMessage(data: WSMessage) {
  const flowStore = useFlowStore()
  // 仅处理当前订阅的flowID的消息
  if (data.flow_id !== flowStore.currentFlowID) return

  switch (data.event_type) {
    case 'phase_started':
    case 'phase_completed':
    case 'phase_failed':
      // ★ 环节状态变更 → 更新flowStore.phases中对应环节
      const phase = flowStore.phases.find(p => p.phase_type === data.payload.phase_type)
      if (phase) {
        phase.status = data.payload.status
        if (data.payload.start_time) phase.start_time = data.payload.start_time
        if (data.payload.end_time) phase.end_time = data.payload.end_time
        if (data.payload.fail_reason) phase.fail_reason = data.payload.fail_reason
      }
      break

    case 'deploy_progress':
      // ★ 部署进度 → 更新flowStore.phases[DEPLOY].clusters中对应集群的detail
      const deployPhase = flowStore.phases.find(p => p.phase_type === 'DEPLOY')
      if (deployPhase) {
        const cluster = deployPhase.clusters.find(c => c.cluster_name === data.payload.cluster_name)
        if (cluster) {
          cluster.status = data.payload.status
          cluster.detail = JSON.stringify(data.payload.stages)
        }
      }
      break

    case 'monitor_deploy_progress':
      // ★ 监控部署进度 → 更新monitorStore.deployVO
      const monitorStore = useMonitorStore()
      if (monitorStore.deployVO) {
        monitorStore.deployVO.deploy_status = data.payload.deploy_status
      }
      break

    case 'monitor_config_progress':
      // ★ 监控配置进度 → 更新monitorStore.configVO
      const monStore = useMonitorStore()
      if (monStore.configVO) {
        monStore.configVO.config_status = data.payload.config_status
      }
      break

    case 'check_completed':
      // ★ 核查完成 → 更新flowStore.phases[CHECK].clusters中对应集群
      const checkPhase = flowStore.phases.find(p => p.phase_type === 'CHECK')
      if (checkPhase) {
        const cluster = checkPhase.clusters.find(c => c.cluster_name === data.payload.cluster_name)
        if (cluster) {
          cluster.status = data.payload.result
          cluster.detail = JSON.stringify({
            pass_count: data.payload.pass_count,
            fail_count: data.payload.fail_count,
            rule_count: data.payload.rule_count,
          })
        }
      }
      break

    case 'drill_completed':
      // ★ 演练完成 → 更新flowStore.phases[DRILL].clusters中对应集群
      const drillPhase = flowStore.phases.find(p => p.phase_type === 'DRILL')
      if (drillPhase) {
        const cluster = drillPhase.clusters.find(c => c.cluster_name === data.payload.cluster_name)
        if (cluster) {
          cluster.status = data.payload.drill_status
          cluster.detail = JSON.stringify({
            scene_count: data.payload.scene_count,
            done_count: data.payload.done_count,
            fail_count: data.payload.fail_count,
          })
        }
      }
      break
  }
}
```

## 14. 组件级渲染规则

> 为每个关键组件定义精确的条件渲染规则。弱模型实现时必须严格按以下规则渲染，不得自行判断显示逻辑。

### 14.1 PhaseCard — 环节状态卡片

```typescript
// ★ PhaseCard.vue 渲染规则表
// 输入: PhaseStatusVO (从flowStore.phases[index]获取)

// ┌────────────────────────────────────────────────────────────────────────────┐
// │ PhaseCard 头部区域                                                        │
// │ ┌─────────────┬──────────────────────┬────────────────────────────────┐   │
// │ │ PHASE_NAME  │ STATUS_TAG           │ TIME_INFO                     │   │
// │ │ (PHASE_NAME │ (ElTag, type=        │ start_time ~ end_time         │   │
// │ │  _MAP映射)  │  PHASE_STATUS_       │ 或 "尚未开始"(PENDING)        │   │
// │ │             │  COLOR_MAP映射)       │                                │   │
// │ └─────────────┴──────────────────────┴────────────────────────────────┘   │
// │                                                                            │
// │ PhaseCard 操作区域(根据status条件渲染)                                      │
// │ PENDING:  [开始按钮(ElButton type=primary)]                                │
// │ RUNNING:  [进行中...标签(ElTag type=warning)] + 禁用所有按钮               │
// │ DONE:     [已完成标签(ElTag type=success)] + [查看详情按钮(ElButton)]      │
// │ FAILED:   [失败标签(ElTag type=danger)] + 失败原因文本(ElText type=danger) │
// │           + [重试按钮(ElButton type=warning)]                              │
// └────────────────────────────────────────────────────────────────────────────┘

// ★ IsParallel标记: MONITOR和DEPLOY的PhaseCard右上角显示"并行"小标签(ElTag size=small)
// ★ 集群统计: 卡片底部显示 "集群: 3/5通过" 格式(从clusters数组计算)

// 精确渲染伪代码:
function renderPhaseCard(phase: PhaseStatusVO) {
  const name = PHASE_NAME_MAP[phase.phase_type]
  const tagType = PHASE_STATUS_COLOR_MAP[phase.status]
  const statusText = PHASE_STATUS_NAME_MAP[phase.status]

  // 头部
  <div class="phase-header">
    <span>{name}</span>
    <ElTag type={tagType}>{statusText}</ElTag>
    {phase.is_parallel && <ElTag size="small" type="warning">并行</ElTag>}
  </div>

  // 时间信息
  <div class="phase-time">
    {phase.status === 'PENDING' ? '尚未开始' : `${phase.start_time} ~ ${phase.end_time || '进行中'}`}
  </div>

  // 操作按钮(根据status)
  <div class="phase-actions">
    {phase.status === 'PENDING' && <ElButton type="primary" onClick={emit('start')}>开始</ElButton>}
    {phase.status === 'RUNNING' && <ElTag type="warning">进行中...</ElTag>}
    {phase.status === 'DONE' && <ElButton type="primary" onClick={emit('detail')}>查看详情</ElButton>}
    {phase.status === 'FAILED' && (
      <>
        <ElText type="danger">{phase.fail_reason}</ElText>
        <ElButton type="warning" onClick={emit('retry')}>重试</ElButton>
      </>
    )}
  </div>

  // 集群统计(仅clusters非空时显示)
  {phase.clusters.length > 0 && (
    <div class="phase-stats">
      集群: {phase.clusters.filter(c => c.status === 'PASS' || c.status === 'DONE').length}/{phase.clusters.length}通过
    </div>
  )}
}
```

### 14.2 ResourceApplyPanel — 资源申请面板

```typescript
// ★ ResourceApplyPanel 渲染规则表
// 输入: useResourceStore() + useFlowStore()

// ┌────────────────────────────────────────────────────────────────────────────┐
// │ ResourceApplyPanel                                                        │
// │                                                                            │
// │ ★ 初始化区域: 仅在ResourceApply不存在时显示                                │
// │   [初始化按钮] → 弹出Dialog输入refIDC → 调用resourceStore.initApply        │
// │                                                                            │
// │ ★ 表格区域: items列表 + 根据applyStatus控制按钮                            │
// │                                                                            │
// │ applyStatus=DRAFT时:                                                       │
// │   表格每行: [编辑] [删除] 按钮                                             │
// │   表格上方: [新增] [确认提交] 按钮                                         │
// │   不可编辑列(deliver_status, ips, fail_reason)灰显                         │
// │                                                                            │
// │ applyStatus=SUBMITTED时:                                                   │
// │   所有行操作按钮隐藏(灰显)                                                 │
// │   [确认提交]按钮隐藏                                                       │
// │   表格列正常显示(不可编辑)                                                 │
// │                                                                            │
// │ applyStatus=PARTIAL_SUBMITTED时:                                           │
// │   所有行操作按钮隐藏(灰显)                                                 │
// │   [确认提交]按钮隐藏                                                       │
// │   失败集群行显示 [重试提交] 按钮                                           │
// │   ★ 重试提交: 调用resourceApi.confirmAndSubmit重新提交失败集群             │
// │                                                                            │
// │ applyStatus=SUBMIT_FAILED时:                                               │
// │   所有行操作按钮隐藏(灰显)                                                 │
// │   [重新提交] 按钮(替代"确认提交")                                          │
// │   失败集群行显示 fail_reason 红色文本                                      │
// └────────────────────────────────────────────────────────────────────────────┘

// ★ deliver_status列渲染:
function renderDeliverStatusTag(status: DeliverStatus) {
  return <ElTag type={DELIVER_STATUS_COLOR_MAP[status]}>{DELIVER_STATUS_NAME_MAP[status]}</ElTag>
}

// ★ ips列渲染:
function renderIPs(ipsStr: string) {
  // ipsStr是JSON数组字符串, 如 "[\"10.0.0.1\",\"10.0.0.2\"]"
  // 解析后展示: 10.0.0.1, 10.0.0.2 (逗号分隔, 不显示JSON括号)
  if (!ipsStr || ipsStr === '[]') return <ElText type="info">待交付</ElText>
  const ips: string[] = JSON.parse(ipsStr)
  return ips.join(', ')
}

// ★ fail_reason列渲染:
function renderFailReason(item: ResourceApplyItem) {
  if (item.deliver_status !== 'SUBMIT_FAILED' || !item.fail_reason) return null
  return <ElText type="danger" truncated>{item.fail_reason}</ElText>
}
```

### 14.3 CheckViewPanel — 核查面板

```typescript
// ★ CheckViewPanel 渲染规则表
// 输入: useCheckStore() + useFlowStore()

// ┌────────────────────────────────────────────────────────────────────────────┐
// │ CheckViewPanel                                                            │
// │                                                                            │
// │ ★ 交付状态区域:                                                           │
// │   [查询交付状态按钮] → 调用checkStore.queryDeliverStatus                    │
// │   交付状态表格:                                                            │
// │   ┌──────────┬──────────┬──────┬──────┬──────────┬──────────┐             │
// │   │ 集群名称 │ MWType   │ IDC  │ 交付  │ 申请数   │ 已交付   │             │
// │   │          │          │      │ 状态  │          │ 数       │             │
// │   ├──────────┼──────────┼──────┼──────┼──────────┼──────────┤             │
// │   │ cluster  │ mw_type  │ idc  │ TAG  │ expected │ actual   │             │
// │   │ _name    │          │      │      │ _count   │ _count   │             │
// │   └──────────┴──────────┴──────┴──────┴──────────┴──────────┘             │
// │   交付状态TAG颜色:                                                        │
// │     FULL=success(绿), PARTIAL=warning(黄), NONE=danger(红),               │
// │     SUBMIT_FAILED=info(灰)                                                │
// │                                                                            │
// │ ★ 核查操作区域:                                                           │
// │   表格每行: [执行核查按钮] → 调用checkStore.executeCheck                   │
// │   ★ 执行核查时显示loading(核查可能耗时较长)                                │
// │                                                                            │
// │ ★ 核查结果汇总:                                                           │
// │   核查结果列:                                                              │
// │     全部PASS → <ElTag type="success">核查通过</ElTag>                     │
// │     有FAIL  → <ElTag type="danger">核查失败(N项)</ElTag>                  │
// │     未核查  → <ElText type="info">未核查</ElText>                         │
// │                                                                            │
// │ ★ 核查明细区域:                                                           │
// │   点击"查看明细" → 展开子表格                                              │
// │   每条CheckRecord:                                                        │
// │   ┌──────────┬──────┬──────┬──────┬──────┬──────────┐                     │
// │   │ 规则名称 │ 范围 │ 类型 │ 结果 │ 时间 │ 查看日志 │                     │
// │   │ rule_name│scope │check │PASS/ │exec  │[日志按钮]│                     │
// │   │ (从rule  │      │_type │FAIL  │_time │→LogViewer│                     │
// │   │ _id关联) │      │      │TAG   │      │          │                     │
// │   └──────────┴──────┴──────┴──────┴──────┴──────────┘                     │
// │   结果TAG: PASS=success(绿), FAIL=danger(红)                              │
// │   范围TAG: COMMON=info, MW_TYPE=warning, CLUSTER=danger(仅展示,无操作)    │
// └────────────────────────────────────────────────────────────────────────────┘

// ★ 核查结果判定逻辑(前端汇总):
function aggregateCheckResult(records: CheckRecord[]): { result: string; passCount: number; failCount: number } {
  const passCount = records.filter(r => r.result === 'PASS').length
  const failCount = records.filter(r => r.result === 'FAIL').length
  const result = failCount === 0 ? 'PASS' : 'FAIL'
  return { result, passCount, failCount }
}

// ★ 核查结果TAG渲染:
function renderCheckResultTag(result: string, failCount: number) {
  if (result === 'PASS') return <ElTag type="success">核查通过</ElTag>
  return <ElTag type="danger">核查失败({failCount}项)</ElTag>
}
```

### 14.4 DeployViewPanel + DeployProgress — 部署面板

```typescript
// ★ DeployViewPanel 渲染规则表
// 输入: useDeployStore() + useFlowStore()

// ┌────────────────────────────────────────────────────────────────────────────┐
// │ DeployViewPanel                                                           │
// │                                                                            │
// │ ★ 可部署集群区域:                                                         │
// │   [加载集群按钮] → deployStore.loadCheckedClusters                         │
// │   表格:                                                                   │
// │   ┌──────────┬──────────┬──────┬──────────┬──────────┬──────────┐         │
// │   │ 集群名称 │ MWType   │ 节点 │ 部署参数 │ 部署状态 │ 操作     │         │
// │   │ cluster  │ mw_type  │ 数   │ params   │ status   │          │         │
// │   │ _name    │          │      │ (JSON)   │ TAG      │          │         │
// │   └──────────┴──────────┴──────┴──────────┴──────────┴──────────┘         │
// │   部署状态TAG: 使用DEPLOY_STATUS_COLOR_MAP+DEPLOY_STATUS_NAME_MAP          │
// │   操作列:                                                                 │
// │     PENDING/FAILED → [触发部署按钮]                                        │
// │     VALIDATING/DEPLOYING/VERIFYING → [查看进度按钮]                        │
// │     DONE → [查看详情按钮]                                                  │
// │     FAILED → [重试按钮] + [查看详情按钮]                                   │
// │                                                                            │
// │ ★ DeployProgress组件(嵌套在DeployViewPanel中):                             │
// │   选中集群后显示三阶段进度条                                                │
// │   ┌──────────────────────────────────────────────────────────┐             │
// │   │ ★ 三阶段卡片 (ElSteps方向=vertical)                     │             │
// │   │                                                          │             │
// │   │ VALIDATE(校验):                                          │             │
// │   │   状态图标: PENDING=灰色圆, RUNNING=蓝色动画圆,          │             │
// │   │             DONE=绿色勾, FAILED=红色叉                   │             │
// │   │   时间: start_time ~ end_time                           │             │
// │   │   [查看日志按钮]: 仅log_file_path非空时显示              │             │
// │   │                                                          │             │
// │   │ DEPLOY(部署): 同VALIDATE结构                             │             │
// │   │                                                          │             │
// │   │ VERIFY(验证): 同VALIDATE结构                             │             │
// │   │                                                          │             │
// │   │ ★ 部署记录信息:                                          │             │
// │   │   deploy_id, task_id, retry_count, params(JSON展示)      │             │
// │   └──────────────────────────────────────────────────────────┘             │
// └────────────────────────────────────────────────────────────────────────────┘

// ★ 阶段状态图标映射(DeployProgress内部):
const DEPLOY_STAGE_ICON_MAP: Record<string, { icon: string; color: string }> = {
  PENDING:  { icon: 'Circle', color: '#909399' },   // 灰色圆
  RUNNING:  { icon: 'Loading', color: '#409EFF' },   // 蓝色动画(使用ElIcon的loading动画)
  DONE:     { icon: 'SuccessFilled', color: '#67C23A' }, // 绿色勾
  FAILED:   { icon: 'CircleCloseFilled', color: '#F56C6C' }, // 红色叉
}

// ★ 阶段名称映射:
// VALIDATE → "校验", DEPLOY → "部署", VERIFY → "验证"
// 使用 DEPLOY_STAGE_NAME_MAP

// ★ 日志按钮条件:
function shouldShowStageLogButton(stage: DeployStageVO) {
  // 仅log_file_path非空时显示"查看日志"按钮
  // 或signed_url非空时显示"下载日志"链接
  return stage.log_file_path !== '' && stage.log_file_path !== null
}
```

### 14.5 MonitorViewPanel — 监控面板

```typescript
// ★ MonitorViewPanel 渲染规则表
// 输入: useMonitorStore() + useFlowStore()

// ┌────────────────────────────────────────────────────────────────────────────┐
// │ MonitorViewPanel                                                          │
// │                                                                            │
// │ ★ 两个独立状态卡片并排显示:                                               │
// │                                                                            │
// │ ┌─ DeployStatus卡片 ─────────────────────────────────────────┐             │
// │ │ 标题: 监控服务部署                                         │             │
// │ │ 状态TAG: MONITOR_DEPLOY_STATUS_COLOR_MAP                   │             │
// │ │ IPs列表: JSON数组解析后逗号分隔展示                         │             │
// │ │ TaskID: deploy_task_id(可折叠显示)                         │             │
// │ │ 时间: start_time ~ end_time                                │             │
// │ │ 操作按钮:                                                  │             │
// │ │   deploy_status=PENDING/FAILED → [部署监控按钮]            │             │
// │ │     ★ 弹出Dialog选择IP列表 → 调用monitorStore.triggerDeploy│             │
// │ │   deploy_status=RUNNING → [进行中...标签] 禁用按钮         │             │
// │ │   deploy_status=DONE → [查看日志按钮]                      │             │
// │ │                                                            │             │
// │ │ ★ 失败原因: FAILED时显示fail_reason(从ClusterStatusVO取)   │             │
// │ └────────────────────────────────────────────────────────────┘             │
// │                                                                            │
// │ ┌─ ConfigStatus卡片 ────────────────────────────────────────┐             │
// │ │ 标题: 监控配置                                             │             │
// │ │ 状态TAG: MONITOR_CONFIG_STATUS_COLOR_MAP                   │             │
// │ │ TaskID: config_task_id                                     │             │
// │ │ 操作按钮:                                                  │             │
// │ │   ★★★ 关键条件: deploy_status=DONE 且 config_status≠RUNNING│             │
// │ │     → [配置监控按钮]                                       │             │
// │ │   ★★★ deploy_status≠DONE → 隐藏配置按钮(灰色提示文字)      │             │
// │ │     "请先完成监控服务部署"                                  │             │
// │ │   config_status=RUNNING → [进行中...标签] 禁用按钮         │             │
// │ │   config_status=DONE → [查看配置详情按钮]                  │             │
// │ │                                                            │             │
// │ │ ★ ConfigDetail展示:                                        │             │
// │ │   点击"查看配置详情" → 展示configVO.config_detail          │             │
// │ │   config_detail是JSON字符串 → 解析后用ElDescriptions展示    │             │
// │ └────────────────────────────────────────────────────────────┘             │
// └────────────────────────────────────────────────────────────────────────────┘

// ★★★ 关键渲染规则: 配置监控按钮的条件
function shouldShowConfigDeployButton(deployVO: MonitorDeployVO | null, configVO: MonitorConfigVO | null): boolean {
  // ★ 前端硬校验: DeployStatus=DONE才显示配置按钮
  // 后端也有校验(DeployStatus!=DONE→拒绝), 但前端先隐藏按钮减少无效请求
  if (!deployVO) return false
  if (deployVO.deploy_status !== 'DONE') return false
  if (configVO && configVO.config_status === 'RUNNING') return false
  return true
}

// ★ 未满足条件时的提示:
function renderConfigDisabledHint(deployVO: MonitorDeployVO | null): string {
  if (!deployVO) return '请先部署监控服务'
  if (deployVO.deploy_status === 'PENDING') return '监控部署尚未开始'
  if (deployVO.deploy_status === 'RUNNING') return '监控部署进行中，请等待完成'
  if (deployVO.deploy_status === 'FAILED') return '监控部署失败，请重试部署后再配置'
  return ''
}

// ★ DeployStatus TAG颜色: 使用MONITOR_DEPLOY_STATUS_COLOR_MAP
// ★ ConfigStatus TAG颜色: 使用MONITOR_CONFIG_STATUS_COLOR_MAP

// ★ 状态中文名映射:
// PENDING→"待处理", RUNNING→"进行中", DONE→"完成", FAILED→"失败"
// (通用映射, 与PhaseStatus映射一致)
const MONITOR_STATUS_NAME_MAP: Record<string, string> = {
  PENDING: '待处理',
  RUNNING: '进行中',
  DONE: '完成',
  FAILED: '失败',
}
```

### 14.6 DrillViewPanel + DrillProgress — 演练面板

```typescript
// ★ DrillViewPanel 渲染规则表
// 输入: useDrillStore() + useFlowStore()

// ┌────────────────────────────────────────────────────────────────────────────┐
// │ DrillViewPanel                                                            │
// │                                                                            │
// │ ★ 可演练集群区域:                                                         │
// │   [加载集群按钮] → drillStore.loadDeployedClusters                         │
// │   表格:                                                                   │
// │   ┌──────────┬──────────┬──────┬──────────┬──────────┬──────┬──────┐       │
// │   │ 集群名称 │ MWType   │ 节点 │ 部署状态 │ 演练状态 │ 完成 │ 失败 │       │
// │   │ cluster  │ mw_type  │ 数   │ deploy   │ drill   │ 数   │ 数   │       │
// │   │ _name    │          │      │ _status  │ _status │      │      │       │
// │   └──────────┴──────────┴──────┴──────────┴──────────┴──────┴──────┘       │
// │   部署状态列: 固定显示"完成"(只有DONE的集群才在列表中)                     │
// │   演练状态TAG: 使用DRILL_STATUS_COLOR_MAP+DRILL_STATUS_NAME_MAP            │
// │   操作列:                                                                 │
// │     drill_status=NONE → [一键演练按钮] + [选择场景演练按钮]                │
// │     drill_status=PARTIAL → [继续演练按钮] + [查看明细按钮]                 │
// │     drill_status=ALL_DONE → [查看明细按钮]                                │
// │     drill_status=FAILED → [重试失败按钮] + [查看明细按钮]                 │
// │                                                                            │
// │ ★ DrillProgress组件(场景结果卡片列表):                                     │
// │   选中集群后显示演练结果                                                   │
// │   ┌──────────────────────────────────────────────────────────┐             │
// │   │ 每个场景一个结果卡片(ElCard):                            │             │
// │   │                                                          │             │
// │   │ 卡片标题: {scope图标} {scene_name}                       │             │
// │   │ scope图标: COMMON=🌍(通用), MW_TYPE=🔧(按类型),          │             │
// │   │           CLUSTER=🎯(按集群) — 使用RuleScope映射         │             │
// │   │                                                          │             │
// │   │ 卡片状态TAG:                                             │             │
// │   │   Status=DONE + overall_result=PASS → ElTag success      │             │
// │   │   Status=DONE + overall_result=FAIL → ElTag danger       │             │
// │   │   Status=FAILED → ElTag danger                           │             │
// │   │   Status=RUNNING → ElTag warning                         │             │
// │   │                                                          │             │
// │   │ 卡片内容:                                                │             │
// │   │   点击卡片 → 展开步骤结果列表                             │             │
// │   │   每个步骤:                                              │             │
// │   │   ┌──────────┬──────┬──────┬──────┬──────┬──────┐       │             │
// │   │   │ 步骤名称 │ 类型 │ 结果 │ 时间 │ 日志 │ 操作 │       │             │
// │   │   │ step_name│ type │PASS/ │exec  │路径  │[重试]│       │             │
// │   │   │          │      │FAIL  │_time │      │按钮  │       │             │
// │   │   └──────────┴──────┴──────┴──────┴──────┴──────┘       │             │
// │   │   步骤结果TAG: PASS=success, FAIL=danger                │             │
// │   │   步骤类型TAG: 使用STEP_TYPE_NAME_MAP                    │             │
// │   │                                                          │             │
// │   │   SHELL/ANSIBLE步骤展开:                                 │             │
// │   │     每个节点: ip + result(TAG) + output(截断显示)        │             │
// │   │   API步骤展开:                                           │             │
// │   │     url + status_code + response_body(截断显示)          │             │
// │   │                                                          │             │
// │   │ ★ FAILED场景: 显示[重试按钮] → 调用drillStore.retryDrill │             │
// │   └──────────────────────────────────────────────────────────┘             │
// └────────────────────────────────────────────────────────────────────────────┘

// ★ 场景结果判定逻辑:
function renderDrillSceneStatusTag(record: DrillRecord) {
  if (record.status === 'RUNNING') return <ElTag type="warning">进行中</ElTag>
  if (record.status === 'FAILED') return <ElTag type="danger">失败</ElTag>
  // Status=DONE时, 看overall_result
  const result = record.result?.overall_result
  if (result === 'PASS') return <ElTag type="success">通过</ElTag>
  return <ElTag type="danger">未通过</ElTag>
}

// ★ 步骤结果判定(从DrillResult.steps数组):
function renderStepResultTag(step: DrillStepResult) {
  if (step.status === 'PASS') return <ElTag type="success" size="small">PASS</ElTag>
  return <ElTag type="danger" size="small">FAIL</ElTag>
}

// ★ scope图标映射(场景卡片标题装饰):
const SCOPE_ICON_MAP: Record<RuleScope, string> = {
  COMMON: '🌐',
  MW_TYPE: '🔧',
  CLUSTER: '🎯',
}

// ★ 场景排序: drillRecords按scope排序 COMMON→MW_TYPE→CLUSTER
function sortDrillRecords(records: DrillRecord[]): DrillRecord[] {
  const scopeOrder: Record<string, number> = { COMMON: 1, MW_TYPE: 2, CLUSTER: 3 }
  return [...records].sort((a, b) => scopeOrder[a.scope] - scopeOrder[b.scope])
}
```

### 14.7 LogViewer — 日志查看器渲染规则补充

```typescript
// ★ LogViewer 渲染规则补充(现有6.2节基础规则)

// 行号计算: 第1页行号1~100, 第2页101~200
// startLine参数: 0-based(第1页=0), 前端显示1-based
// 行号 = apiStartLine + index + 1

// ★ 空日志处理:
function renderEmptyLog(totalLines: number) {
  if (totalLines === 0) return <ElEmpty description="暂无日志内容" />
}

// ★ 行内容截断:
function renderLogLine(line: string, maxLen: number = 200) {
  // 单行超过200字符截断, 鼠标悬停显示完整内容(ElTooltip)
  if (line.length > maxLen) {
    return <ElTooltip content={line} placement="top">
      <span>{line.slice(0, maxLen)}...</span>
    </ElTooltip>
  }
  return line
}

// ★ 日志颜色: 不做语法高亮, 使用等宽字体(monospace) + 灰底黑字
// .log-line { font-family: 'Courier New', monospace; background: #f5f7fa; }
```

### 14.8 AdminView — 管理配置页渲染规则补充

```typescript
// ★ JudgeRule动态表单渲染(补充5.8节)

// JudgeRule表单根据mode动态切换, ★ 弱模型最容易出错的地方

function renderJudgeRuleForm(rule: JudgeRule, onUpdate: (rule: JudgeRule) => void) {
  return (
    <div>
      {/* Mode选择 */}
      <ElSelect value={rule.mode} onChange={(mode: JudgeRuleMode) => onUpdate({ ...rule, mode })}>
        {Object.entries(JUDGE_RULE_MODE_NAME_MAP).map(([k, v]) =>
          <ElOption key={k} label={v} value={k} />
        )}
      </ElSelect>

      {/* ★ 根据mode条件渲染不同字段 */}
      {rule.mode === 'status_code' && (
        <ElInputNumber value={rule.expected as number} label="期望状态码"
          onChange={(v: number) => onUpdate({ ...rule, expected: v })} />
      )}

      {rule.mode === 'json_field' && (
        <>
          <ElInput value={rule.field_path} label="字段路径(如data.status)"
            onChange={(v: string) => onUpdate({ ...rule, field_path: v })} />
          <ElInput value={rule.expected as string} label="期望值"
            onChange={(v: string) => onUpdate({ ...rule, expected: v })} />
        </>
      )}

      {rule.mode === 'keyword' && (
        <ElInput value={rule.expected as string} label="关键字(响应中包含则FAIL)"
          onChange={(v: string) => onUpdate({ ...rule, expected: v })} />
      )}

      {rule.mode === 'value_range' && (
        <>
          <ElInput value={rule.field_path} label="字段路径(如data.cpu_usage)"
            onChange={(v: string) => onUpdate({ ...rule, field_path: v })} />
          <ElInputNumber value={rule.min} label="最小值"
            onChange={(v: number) => onUpdate({ ...rule, min: v })} />
          <ElInputNumber value={rule.max} label="最大值"
            onChange={(v: number) => onUpdate({ ...rule, max: v })} />
        </>
      )}
    </div>
  )
}

// ★ Scope条件显示规则(核查规则和演练场景通用):
function renderScopeConditionalFields(scope: RuleScope) {
  return (
    <>
      {/* Scope=COMMON: MWType和ClusterRegex隐藏 */}
      {scope === 'MW_TYPE' && (
        <ElSelect label="中间件类型">
          {Object.entries(MW_TYPE_NAME_MAP).map(([k, v]) =>
            <ElOption key={k} label={v} value={k} />
          )}
        </ElSelect>
      )}
      {scope === 'CLUSTER' && (
        <ElInput label="集群名称正则(如redis-prod-*)" />
      )}
    </>
  )
}

// ★ StepsEditor渲染规则(演练场景步骤编辑器):
// - 步骤列表: 可拖拽排序(使用vuedraggable或手动排序)
// - 每行: StepName(ElInput) + Type(ElSelect: SHELL/ANSIBLE/API) + Content(ElInput textarea) + Target(ElInput) + 删除按钮
// - Target字段placeholder: "空=全部节点, 单IP=指定节点, 多IP逗号分隔"
// - 添加步骤按钮: 新增一行空步骤 { name: '', type: 'SHELL', content: '', target: '' }

// ★ DeployParamEditor渲染规则(部署配置参数编辑器):
// - 每行: Name(ElInput) + Default(ElInput) + WidgetType(ElSelect: input/select/textarea/number) + 删除按钮
// - 添加参数按钮: 新增一行空参数 { name: '', default: '', widget_type: 'input' }
```

### 14.9 通用状态指示器渲染

```typescript
// ★ WebSocket连接状态指示器(FlowDetail.vue右上角)
function renderWSIndicator(wsStore: ReturnType<typeof useWSStore>) {
  // 绿点=已连接, 红点=断开, 黄点=重连中
  const color = wsStore.connected ? '#67C23A'
    : wsStore.reconnectCount > 0 ? '#E6A23C'
    : '#F56C6C'

  const text = wsStore.connected ? '实时连接'
    : wsStore.reconnectCount > 0 ? `重连中(${wsStore.reconnectCount}/5)`
    : '连接断开'

  return (
    <div class="ws-indicator">
      <span class="ws-dot" style={{ backgroundColor: color }}></span>
      <ElText size="small">{text}</ElText>
    </div>
  )
}

// ★ CSS:
// .ws-indicator { display: flex; align-items: center; gap: 4px; position: absolute; top: 16px; right: 16px; }
// .ws-dot { width: 8px; height: 8px; border-radius: 50%; }
// ★ RUNNING状态的闪烁动画:
// .ws-dot.reconnecting { animation: blink 1s infinite; }
// @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
```
