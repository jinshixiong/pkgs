package minio

import (
	"time"

	"github.com/minio/minio-go/v7"
	"github.com/yourorg/fast-mw/internal/config"
)

type MinioClient struct {
	client *minio.Client
}

func NewMinioClient(cfg *config.MinioConfig) (*MinioClient, error) {
	panic("not implemented")
}

func (mc *MinioClient) Upload(bucket, objectName string, data []byte) error {
	panic("not implemented")
}

func (mc *MinioClient) Download(bucket, objectName string) ([]byte, error) {
	panic("not implemented")
}

func (mc *MinioClient) GetSignedURL(bucket, objectName string, expiry time.Duration) (string, error) {
	panic("not implemented")
}

func (mc *MinioClient) ReadLines(bucket, objectName string, startLine, lineCount int) ([]string, error) {
	panic("not implemented")
}
