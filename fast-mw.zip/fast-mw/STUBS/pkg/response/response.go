package response

import (
	"time"

	"github.com/gin-gonic/gin"
)

type Response struct {
	Code      int    `json:"code"`
	Msg       string `json:"msg"`
	ReqID     string `json:"reqId"`
	Data      any    `json:"data"`
	Timestamp int64  `json:"timestamp"`
}

func Success(c *gin.Context, reqID string, data any) {
	panic("not implemented")
}

func Fail(c *gin.Context, reqID string, code int, msg string) {
	panic("not implemented")
}

func GenerateReqID() string {
	panic("not implemented")
}
