package errcode

const (
	ErrParamInvalid    = 1001
	ErrInternalError   = 1002
	ErrAPICallFailed   = 1003

	ErrTemplateNameDup  = 2001
	ErrCMDBAPIFailed    = 2002
	ErrResourceDelivering = 2003

	ErrCheckRuleNotFound = 2201
	ErrCheckFailed       = 2202

	ErrDeployFailed    = 2301
	ErrDeployRetrying  = 2302

	ErrDrillFailed       = 2401
	ErrDrillSceneNotFound = 2402

	ErrMonitorDeployFailed = 2501
)

func Msg(code int) string {
	panic("not implemented")
}
