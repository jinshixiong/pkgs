module github.com/yourorg/fast-mw

go 1.21

require (
	github.com/gin-gonic/gin v1.9.1
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/gorilla/websocket v1.5.3
	github.com/minio/minio-go/v7 v7.0.74
	github.com/panjf2000/ants/v2 v2.10.0
	github.com/patrickmn/go-cache v2.1.0+incompatible
	github.com/swaggo/gin-swagger v1.6.0
	github.com/swaggo/swag v1.16.3
	github.com/xuri/excelize/v2 v2.8.1
	golang.org/x/crypto v0.28.0
	golang.org/x/oauth2 v0.23.0
	golang.org/x/time v0.7.0
	gorm.io/driver/mysql v1.5.7
	gorm.io/gorm v1.25.12
)
