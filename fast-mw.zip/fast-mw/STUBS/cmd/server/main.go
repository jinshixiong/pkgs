package main

import (
	"log"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/fast-mw/internal/config"
	"github.com/yourorg/fast-mw/internal/database"
	"github.com/yourorg/fast-mw/internal/lock"
	"github.com/yourorg/fast-mw/api/v1"
)

func main() {
	cfg, err := config.Load("config.yaml")
	if err != nil {
		log.Fatalf("load config failed: %v", err)
	}

	db, err := database.InitDB(&cfg.Database)
	if err != nil {
		log.Fatalf("init database failed: %v", err)
	}

	if err := database.AutoMigrate(db); err != nil {
		log.Fatalf("auto migrate failed: %v", err)
	}

	_ = lock.NewDistributedLock(db)

	r := gin.Default()
	api.RegisterRoutes(r, db, cfg)

	log.Printf("server starting on port %d", cfg.Server.Port)
	if err := r.Run(); err != nil {
		log.Fatalf("server start failed: %v", err)
	}
}
