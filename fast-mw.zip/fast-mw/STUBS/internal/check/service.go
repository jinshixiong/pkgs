package check

import (
	"context"

	"github.com/panjf2000/ants/v2"
	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/admin"
	"github.com/yourorg/fast-mw/internal/model"
	minioclient "github.com/yourorg/fast-mw/pkg/minio"
)

type CheckService struct {
	db      *gorm.DB
	pool    *ants.Pool
	ruleSvc *admin.CheckRuleService
	minio   *minioclient.MinioClient
}

func NewCheckService(db *gorm.DB, pool *ants.Pool, ruleSvc *admin.CheckRuleService, minio *minioclient.MinioClient) *CheckService {
	panic("not implemented")
}

type DeliverStatusVO struct {
	ClusterName    string
	MWType         string
	DeliverStatus  string
	ExpectedCount  int
	ActualCount    int
}

func (s *CheckService) QueryDeliverStatus(ctx context.Context, flowID uint64) ([]*DeliverStatusVO, error) {
	panic("not implemented")
}

func (s *CheckService) ExecuteCheck(ctx context.Context, flowID uint64, clusterName string) ([]*model.CheckRecord, error) {
	panic("not implemented")
}

func (s *CheckService) GetCheckDetail(ctx context.Context, flowID uint64, clusterName string) ([]*model.CheckRecord, error) {
	panic("not implemented")
}

func (s *CheckService) GetCheckLog(ctx context.Context, recordID uint64, startLine, lineCount int) ([]string, error) {
	panic("not implemented")
}
