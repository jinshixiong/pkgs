package monitor

import (
	"context"

	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/adapter/monitor"
	minioclient "github.com/yourorg/fast-mw/pkg/minio"
)

type MonitorService struct {
	db    *gorm.DB
	mc    *monitor.MonitorClient
	minio *minioclient.MinioClient
}

func NewMonitorService(db *gorm.DB, mc *monitor.MonitorClient, minio *minioclient.MinioClient) *MonitorService {
	panic("not implemented")
}

func (s *MonitorService) TriggerDeploy(ctx context.Context, flowID uint64, ips []string) error {
	panic("not implemented")
}

func (s *MonitorService) TriggerConfig(ctx context.Context, flowID uint64, clusterNames []string) error {
	panic("not implemented")
}

type MonitorDeployVO struct {
	DeployStatus string
	ConfigStatus string
}

func (s *MonitorService) GetDeployStatus(ctx context.Context, flowID uint64) (*MonitorDeployVO, error) {
	panic("not implemented")
}

func (s *MonitorService) GetConfigStatus(ctx context.Context, flowID uint64) (*monitor.MonitorConfigResult, error) {
	panic("not implemented")
}

func (s *MonitorService) GetDeployLog(ctx context.Context, flowID uint64, startLine, lineCount int) ([]string, error) {
	panic("not implemented")
}

func (s *MonitorService) GetConfigDetail(ctx context.Context, flowID uint64) ([]byte, error) {
	panic("not implemented")
}
