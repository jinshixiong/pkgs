package deploy

import (
	"context"

	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/admin"
	"github.com/yourorg/fast-mw/internal/adapter/deploy"
	"github.com/yourorg/fast-mw/internal/model"
)

type DeployService struct {
	db           *gorm.DB
	deployClient *deploy.DeployClient
	configSvc    *admin.DeployConfigService
}

func NewDeployService(db *gorm.DB, dc *deploy.DeployClient, cs *admin.DeployConfigService) *DeployService {
	panic("not implemented")
}

type ClusterDeployVO struct {
	ClusterName string
	MWType      string
	Status      string
	Params      map[string]any
}

func (s *DeployService) GetCheckedClusters(ctx context.Context, flowID uint64, mwType string) ([]*ClusterDeployVO, error) {
	panic("not implemented")
}

func (s *DeployService) TriggerDeploy(ctx context.Context, flowID uint64, clusterName string) error {
	panic("not implemented")
}

func (s *DeployService) RetryDeploy(ctx context.Context, deployID uint64) error {
	panic("not implemented")
}

type DeployDetailVO struct {
	DeployRecord *model.DeployRecord
	Stages       []*model.DeployStageLog
}

func (s *DeployService) GetDeployDetail(ctx context.Context, flowID uint64, clusterName string) (*DeployDetailVO, error) {
	panic("not implemented")
}

func (s *DeployService) GetStageLog(ctx context.Context, deployID uint64, stage string, startLine, lineCount int) ([]string, error) {
	panic("not implemented")
}
