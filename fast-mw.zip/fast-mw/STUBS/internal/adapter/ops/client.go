package ops

type OpsClient struct {
	baseURL string
	timeout int
}

func NewOpsClient(cfg *config.OpsServiceConfig) *OpsClient {
	panic("not implemented")
}

func (c *OpsClient) ExecuteServiceAction(ip, serviceName, action string) error {
	panic("not implemented")
}

func (c *OpsClient) ExecuteScript(ip string, scriptType, scriptContent string) (string, error) {
	panic("not implemented")
}

func (c *OpsClient) CallAPI(apiURL, method string, params map[string]any) (map[string]any, error) {
	panic("not implemented")
}
