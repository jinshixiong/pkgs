package deploy

type DeployStatusResult struct {
	TaskID string
	Status string
	Stages []StageStatus
}

type StageStatus struct {
	Stage     string
	Status    string
 StartTime time.Time
	EndTime   time.Time
}

type DeployClient struct {
	baseURL string
	timeout int
}

func NewDeployClient(cfg *config.DeployServiceConfig) *DeployClient {
	panic("not implemented")
}

func (c *DeployClient) TriggerDeploy(clusterName, mwType string, ips []string, params map[string]any) (string, error) {
	panic("not implemented")
}

func (c *DeployClient) GetDeployStatus(taskID string) (*DeployStatusResult, error) {
	panic("not implemented")
}

func (c *DeployClient) GetDeployStageLog(taskID string, stage string) ([]byte, error) {
	panic("not implemented")
}

func (c *DeployClient) RetryDeploy(taskID string) error {
	panic("not implemented")
}
