package monitor

type MonitorDeployResult struct {
	TaskID string
	Status string
}

type MonitorConfigResult struct {
	TaskID      string
	Status      string
	ClusterDetails []ClusterConfigDetail
}

type ClusterConfigDetail struct {
	ClusterName string
	MWType      string
	Status      string
}

type MonitorClient struct {
	baseURL string
	timeout int
}

func NewMonitorClient(cfg *config.MonitorServiceConfig) *MonitorClient {
	panic("not implemented")
}

func (c *MonitorClient) TriggerDeploy(ips []string) (string, error) {
	panic("not implemented")
}

func (c *MonitorClient) GetDeployStatus(taskID string) (*MonitorDeployResult, error) {
	panic("not implemented")
}

func (c *MonitorClient) GetDeployLog(taskID string) ([]byte, error) {
	panic("not implemented")
}

func (c *MonitorClient) TriggerConfig(clusterNames []string, mwType string) (string, error) {
	panic("not implemented")
}

func (c *MonitorClient) GetConfigStatus(taskID string) (*MonitorConfigResult, error) {
	panic("not implemented")
}

func (c *MonitorClient) GetConfigDetail(taskID string) ([]byte, error) {
	panic("not implemented")
}
