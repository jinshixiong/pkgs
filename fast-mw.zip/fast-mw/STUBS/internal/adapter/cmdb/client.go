package adapter

type CMDBResource struct {
	ClusterName string
	MWType      string
	IDC         string
	IPs         []string
	CPU         string
	Memory      string
	Disk        string
	NodeCount   int
}

type CMDBClient struct {
	baseURL       string
	timeout       int
	retryCount    int
	retryInterval int
}

func NewCMDBClient(cfg *config.CMDBConfig) *CMDBClient {
	panic("not implemented")
}

func (c *CMDBClient) QueryResources(idc, ownerGroup, opsGroup string) ([]*CMDBResource, error) {
	panic("not implemented")
}

func (c *CMDBClient) SubmitResource(clusterName string, items []*ResourceApplyItem) error {
	panic("not implemented")
}

func (c *CMDBClient) QueryDeliveredResources(idc string) ([]*CMDBResource, error) {
	panic("not implemented")
}
