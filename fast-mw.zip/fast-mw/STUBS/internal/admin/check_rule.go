package admin

import (
	"context"

	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/model"
)

type CheckRuleService struct {
	db *gorm.DB
}

func NewCheckRuleService(db *gorm.DB) *CheckRuleService {
	panic("not implemented")
}

func (s *CheckRuleService) Create(ctx context.Context, rule *model.CheckRule) error {
	panic("not implemented")
}

func (s *CheckRuleService) Update(ctx context.Context, rule *model.CheckRule) error {
	panic("not implemented")
}

func (s *CheckRuleService) Delete(ctx context.Context, id uint64) error {
	panic("not implemented")
}

func (s *CheckRuleService) List(ctx context.Context, scope, mwType string) ([]*model.CheckRule, error) {
	panic("not implemented")
}

func (s *CheckRuleService) Get(ctx context.Context, id uint64) (*model.CheckRule, error) {
	panic("not implemented")
}

func (s *CheckRuleService) MatchRules(ctx context.Context, clusterName, mwType string) ([]*model.CheckRule, error) {
	panic("not implemented")
}
