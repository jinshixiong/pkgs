package admin

import (
	"context"

	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/model"
)

type DrillSceneService struct {
	db *gorm.DB
}

func NewDrillSceneService(db *gorm.DB) *DrillSceneService {
	panic("not implemented")
}

func (s *DrillSceneService) Create(ctx context.Context, scene *model.DrillScene) error {
	panic("not implemented")
}

func (s *DrillSceneService) Update(ctx context.Context, scene *model.DrillScene) error {
	panic("not implemented")
}

func (s *DrillSceneService) Delete(ctx context.Context, id uint64) error {
	panic("not implemented")
}

func (s *DrillSceneService) List(ctx context.Context, scope, mwType string) ([]*model.DrillScene, error) {
	panic("not implemented")
}

func (s *DrillSceneService) Get(ctx context.Context, id uint64) (*model.DrillScene, error) {
	panic("not implemented")
}

func (s *DrillSceneService) MatchScenes(ctx context.Context, clusterName, mwType string) ([]*model.DrillScene, error) {
	panic("not implemented")
}
