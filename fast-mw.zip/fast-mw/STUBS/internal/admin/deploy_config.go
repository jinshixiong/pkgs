package admin

import (
	"context"

	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/model"
)

type DeployConfigService struct {
	db *gorm.DB
}

func NewDeployConfigService(db *gorm.DB) *DeployConfigService {
	panic("not implemented")
}

func (s *DeployConfigService) Create(ctx context.Context, cfg *model.DeployConfig) error {
	panic("not implemented")
}

func (s *DeployConfigService) Update(ctx context.Context, cfg *model.DeployConfig) error {
	panic("not implemented")
}

func (s *DeployConfigService) Delete(ctx context.Context, id uint64) error {
	panic("not implemented")
}

func (s *DeployConfigService) List(ctx context.Context, mwType string) ([]*model.DeployConfig, error) {
	panic("not implemented")
}

func (s *DeployConfigService) Get(ctx context.Context, id uint64) (*model.DeployConfig, error) {
	panic("not implemented")
}

func (s *DeployConfigService) MatchConfig(ctx context.Context, clusterName string) (*model.DeployConfig, error) {
	panic("not implemented")
}
