package drill

import (
	"context"

	"github.com/panjf2000/ants/v2"
	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/admin"
	"github.com/yourorg/fast-mw/internal/adapter/ops"
	"github.com/yourorg/fast-mw/internal/model"
	minioclient "github.com/yourorg/fast-mw/pkg/minio"
)

type DrillService struct {
	db        *gorm.DB
	pool      *ants.Pool
	sceneSvc  *admin.DrillSceneService
	opsClient *ops.OpsClient
	minio     *minioclient.MinioClient
}

func NewDrillService(db *gorm.DB, pool *ants.Pool, ss *admin.DrillSceneService, oc *ops.OpsClient, mc *minioclient.MinioClient) *DrillService {
	panic("not implemented")
}

type ClusterDrillVO struct {
	ClusterName string
	MWType      string
	DeployStatus string
}

func (s *DrillService) GetDeployedClusters(ctx context.Context, flowID uint64, mwType string) ([]*ClusterDrillVO, error) {
	panic("not implemented")
}

func (s *DrillService) ExecuteDrill(ctx context.Context, flowID uint64, clusterName string, sceneIDs []uint64) ([]*model.DrillRecord, error) {
	panic("not implemented")
}

func (s *DrillService) RetryDrill(ctx context.Context, drillID uint64) error {
	panic("not implemented")
}

func (s *DrillService) GetDrillDetail(ctx context.Context, flowID uint64, clusterName string) ([]*model.DrillRecord, error) {
	panic("not implemented")
}

func (s *DrillService) GetDrillLog(ctx context.Context, recordID uint64, startLine, lineCount int) ([]string, error) {
	panic("not implemented")
}
