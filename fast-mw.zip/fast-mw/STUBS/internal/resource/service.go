package resource

import (
	"context"

	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/adapter/cmdb"
	"github.com/yourorg/fast-mw/internal/model"
)

type ResourceService struct {
	db   *gorm.DB
	cmdb *cmdb.CMDBClient
}

func NewResourceService(db *gorm.DB, cmdb *cmdb.CMDBClient) *ResourceService {
	panic("not implemented")
}

func (s *ResourceService) InitApply(ctx context.Context, flowID uint64, refIDC string) ([]*model.ResourceApplyItem, error) {
	panic("not implemented")
}

func (s *ResourceService) UpdateApplyItem(ctx context.Context, item *model.ResourceApplyItem) error {
	panic("not implemented")
}

func (s *ResourceService) DeleteApplyItem(ctx context.Context, itemID uint64) error {
	panic("not implemented")
}

func (s *ResourceService) AddApplyItem(ctx context.Context, item *model.ResourceApplyItem) error {
	panic("not implemented")
}

func (s *ResourceService) ConfirmAndSubmit(ctx context.Context, flowID uint64) error {
	panic("not implemented")
}
