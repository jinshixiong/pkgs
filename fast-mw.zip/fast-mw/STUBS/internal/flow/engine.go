package flow

import (
	"context"

	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/model"
)

type FlowEngine struct {
	db *gorm.DB
}

func NewFlowEngine(db *gorm.DB) *FlowEngine {
	panic("not implemented")
}

func (e *FlowEngine) CreateFlow(ctx context.Context, flowName, idcName, creator string) (*model.DeliveryFlow, error) {
	panic("not implemented")
}

func (e *FlowEngine) GetFlow(ctx context.Context, id uint64) (*model.DeliveryFlow, []*model.FlowPhase, error) {
	panic("not implemented")
}

func (e *FlowEngine) StartPhase(ctx context.Context, flowID uint64, phaseType string) error {
	panic("not implemented")
}

func (e *FlowEngine) CompletePhase(ctx context.Context, flowID uint64, phaseType string) error {
	panic("not implemented")
}

func (e *FlowEngine) FailPhase(ctx context.Context, flowID uint64, phaseType string, reason string) error {
	panic("not implemented")
}

type FlowStatusVO struct {
	Flow          *model.DeliveryFlow
	Phases        []*model.FlowPhase
	PhaseDetails  map[string]any
}

func (e *FlowEngine) GetFlowStatus(ctx context.Context, id uint64) (*FlowStatusVO, error) {
	panic("not implemented")
}
