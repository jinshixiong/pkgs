package flow

import "github.com/gin-gonic/gin"

type FlowWebSocket struct{}

func NewFlowWebSocket() *FlowWebSocket {
	panic("not implemented")
}

func (ws *FlowWebSocket) HandleConnection(c *gin.Context) {
	panic("not implemented")
}

func (ws *FlowWebSocket) PushStatus(flowID uint64, status any) {
	panic("not implemented")
}
