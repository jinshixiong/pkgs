package model

import "time"

type CheckRule struct {
	ID           uint64    `gorm:"primaryKey;autoIncrement"`
	RuleName     string    `gorm:"size:128;not null"`
	Scope        string    `gorm:"size:32;not null"`
	MWType       string    `gorm:"size:64"`
	ClusterRegex string    `gorm:"size:256"`
	CheckType    string    `gorm:"size:32;not null"`
	CheckContent string    `gorm:"type:text"`
	JudgeRule    string    `gorm:"type:text"`
	Sort         int       `gorm:"not null"`
	Status       string    `gorm:"size:16;not null"`
	CreateTime   time.Time `gorm:"autoCreateTime"`
	UpdateTime   time.Time `gorm:"autoUpdateTime"`
}

type CheckRecord struct {
	ID          uint64    `gorm:"primaryKey;autoIncrement"`
	RuleID      uint64    `gorm:"not null;index"`
	FlowID      uint64    `gorm:"not null;index"`
	ClusterName string    `gorm:"size:128;not null;index"`
	Scope       string    `gorm:"size:32"`
	ExecuteTime time.Time
	InputParams string    `gorm:"type:text"`
	Result      string    `gorm:"size:16"`
	Detail      string    `gorm:"type:text"`
	LogFilePath string    `gorm:"size:256"`
}
