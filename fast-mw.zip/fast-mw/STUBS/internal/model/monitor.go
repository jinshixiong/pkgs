package model

import "time"

type MonitorDeploy struct {
	ID           uint64    `gorm:"primaryKey;autoIncrement"`
	FlowID       uint64    `gorm:"not null;index"`
	IPs          string    `gorm:"type:text"`
	DeployStatus string    `gorm:"size:32"`
	DeployLogPath string   `gorm:"size:256"`
	ConfigStatus string    `gorm:"size:32"`
	StartTime    *time.Time
	EndTime      *time.Time
}
