package model

import "time"

type DeliveryFlow struct {
	ID         uint64    `gorm:"primaryKey;autoIncrement"`
	FlowName   string    `gorm:"size:128;not null"`
	IDCName    string    `gorm:"size:64;not null"`
	Status     string    `gorm:"size:32;not null"`
	Creator    string    `gorm:"size:64"`
	CreateTime time.Time `gorm:"autoCreateTime"`
	UpdateTime time.Time `gorm:"autoUpdateTime"`
}

type FlowPhase struct {
	ID        uint64    `gorm:"primaryKey;autoIncrement"`
	FlowID    uint64    `gorm:"not null;index"`
	PhaseType string    `gorm:"size:32;not null"`
	Status    string    `gorm:"size:32;not null"`
	Sort      int       `gorm:"not null"`
	IsParallel bool     `gorm:"default:false"`
	StartTime  *time.Time
	EndTime    *time.Time
}
