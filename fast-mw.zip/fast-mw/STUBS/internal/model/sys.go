package model

import "time"

type SysConfig struct {
	ID          uint64    `gorm:"primaryKey;autoIncrement"`
	ConfigKey   string    `gorm:"size:128;not null;uniqueIndex:idx_key_group"`
	ConfigGroup string    `gorm:"size:64;not null;uniqueIndex:idx_key_group"`
	ConfigValue string    `gorm:"type:text"`
	IsSensitive bool      `gorm:"default:false"`
	Version     int       `gorm:"not null;default:1"`
	Status      string    `gorm:"size:16;default:ENABLE"`
	Operator    string    `gorm:"size:64"`
	CreateTime  time.Time `gorm:"autoCreateTime"`
	UpdateTime  time.Time `gorm:"autoUpdateTime"`
}

func (sc *SysConfig) BeforeCreate(tx *gorm.DB) error {
	panic("not implemented: AES encryption for IsSensitive=true")
}

func (sc *SysConfig) AfterFind(tx *gorm.DB) error {
	panic("not implemented: AES decryption + masking for IsSensitive=true")
}

type SysConfigHistory struct {
	ID         uint64    `gorm:"primaryKey;autoIncrement"`
	ConfigID   uint64    `gorm:"not null;index"`
	ConfigKey  string    `gorm:"size:128"`
	OldValue   string    `gorm:"type:text"`
	NewValue   string    `gorm:"type:text"`
	Version    int       `gorm:"not null"`
	Operator   string    `gorm:"size:64"`
	OperateTime time.Time
}

type DistributedLock struct {
	LockKey    string    `gorm:"primaryKey;size:256"`
	LockOwner  string    `gorm:"size:64;not null"`
	LockTime   time.Time `gorm:"autoCreateTime"`
	ExpireTime time.Time `gorm:"not null"`
}

type AuditLog struct {
	ID          uint64    `gorm:"primaryKey;autoIncrement"`
	Operator    string    `gorm:"size:64;not null;index"`
	OperateTime time.Time `gorm:"not null;index"`
	OperateIP   string    `gorm:"size:64"`
	APIPath     string    `gorm:"size:256;not null"`
	Method      string    `gorm:"size:16"`
	Params      string    `gorm:"type:text"`
	Result      string    `gorm:"size:16"`
}

func (a *AuditLog) TableName() string {
	panic("not implemented: monthly sharding logic, e.g. audit_log_202406")
}
