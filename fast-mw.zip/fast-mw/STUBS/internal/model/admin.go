package model

import "time"

type DeployConfig struct {
	ID         uint64    `gorm:"primaryKey;autoIncrement"`
	NameRegex  string    `gorm:"size:256;not null"`
	MWType     string    `gorm:"size:64;not null"`
	Params     string    `gorm:"type:text"`
	Status     string    `gorm:"size:16"`
	CreateTime time.Time `gorm:"autoCreateTime"`
	UpdateTime time.Time `gorm:"autoUpdateTime"`
}
