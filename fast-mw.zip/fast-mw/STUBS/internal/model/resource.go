package model

import "time"

type ResourceApply struct {
	ID         uint64    `gorm:"primaryKey;autoIncrement"`
	FlowID     uint64    `gorm:"not null;index"`
	RefIDC     string    `gorm:"size:64;not null"`
	Status     string    `gorm:"size:32;not null"`
	Creator    string    `gorm:"size:64"`
	CreateTime time.Time `gorm:"autoCreateTime"`
}

type ResourceApplyItem struct {
	ID           uint64 `gorm:"primaryKey;autoIncrement"`
	ApplyID      uint64 `gorm:"not null;index"`
	ClusterName  string `gorm:"size:128;not null;index"`
	MWType       string `gorm:"size:64;not null"`
	IDC          string `gorm:"size:64;not null"`
	Env          string `gorm:"size:32;not null"`
	NodeCount    int    `gorm:"not null"`
	CPU          string `gorm:"size:32"`
	Memory       string `gorm:"size:32"`
	Disk         string `gorm:"size:32"`
	IPs          string `gorm:"type:text"`
	DeliverStatus string `gorm:"size:32"`
}
