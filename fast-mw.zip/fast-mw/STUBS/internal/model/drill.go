package model

import "time"

type DrillScene struct {
	ID           uint64    `gorm:"primaryKey;autoIncrement"`
	SceneName    string    `gorm:"size:128;not null"`
	Scope        string    `gorm:"size:32;not null"`
	MWType       string    `gorm:"size:64"`
	ClusterRegex string    `gorm:"size:256"`
	Steps        string    `gorm:"type:text"`
	Status       string    `gorm:"size:16"`
	CreateTime   time.Time `gorm:"autoCreateTime"`
	UpdateTime   time.Time `gorm:"autoUpdateTime"`
}

type DrillRecord struct {
	ID          uint64    `gorm:"primaryKey;autoIncrement"`
	SceneID     uint64    `gorm:"not null;index"`
	FlowID      uint64    `gorm:"not null;index"`
	ClusterName string    `gorm:"size:128;not null;index"`
	Scope       string    `gorm:"size:32"`
	Status      string    `gorm:"size:32"`
	StartTime   *time.Time
	EndTime     *time.Time
	LogFilePath string    `gorm:"size:256"`
	Result      string    `gorm:"type:text"`
}
