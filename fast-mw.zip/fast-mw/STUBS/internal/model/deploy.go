package model

import "time"

type DeployRecord struct {
	ID          uint64    `gorm:"primaryKey;autoIncrement"`
	FlowID      uint64    `gorm:"not null;index"`
	ClusterName string    `gorm:"size:128;not null;index"`
	MWType      string    `gorm:"size:64;not null"`
	Status      string    `gorm:"size:32;not null"`
	Params      string    `gorm:"type:text"`
	RetryCount  int       `gorm:"default:0"`
	StartTime   *time.Time
	EndTime     *time.Time
}

type DeployStageLog struct {
	ID          uint64    `gorm:"primaryKey;autoIncrement"`
	DeployID    uint64    `gorm:"not null;index"`
	Stage       string    `gorm:"size:32;not null"`
	LogFilePath string    `gorm:"size:256"`
	StartTime   *time.Time
	EndTime     *time.Time
}
