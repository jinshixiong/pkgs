package database

import (
	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/config"
	"github.com/yourorg/fast-mw/internal/model"
)

func InitDB(cfg *config.DatabaseConfig) (*gorm.DB, error) {
	panic("not implemented")
}

func AutoMigrate(db *gorm.DB) error {
	return db.AutoMigrate(
		&model.DeliveryFlow{},
		&model.FlowPhase{},
		&model.ResourceApply{},
		&model.ResourceApplyItem{},
		&model.CheckRule{},
		&model.CheckRecord{},
		&model.DeployRecord{},
		&model.DeployStageLog{},
		&model.MonitorDeploy{},
		&model.DrillScene{},
		&model.DrillRecord{},
		&model.DeployConfig{},
		&model.SysConfig{},
		&model.SysConfigHistory{},
		&model.DistributedLock{},
		&model.AuditLog{},
	)
}
