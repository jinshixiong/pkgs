package common

const (
	MWTypeNginx     = "nginx"
	MWTypeZookeeper = "zookeeper"
	MWTypeKafka     = "kafka"
	MWTypeRocketMQ  = "rocketmq"
	MWTypeMinio     = "minio"
	MWTypeRedis     = "redis"
)

var ValidMWTypes = []string{
	MWTypeNginx, MWTypeZookeeper, MWTypeKafka,
	MWTypeRocketMQ, MWTypeMinio, MWTypeRedis,
}

func IsValidMWType(mwType string) bool {
	panic("not implemented")
}

const (
	ScopeCommon  = "COMMON"
	ScopeMWType  = "MW_TYPE"
	ScopeCluster = "CLUSTER"
)

const (
	StatusPending  = "PENDING"
	StatusRunning  = "RUNNING"
	StatusDone     = "DONE"
	StatusFailed   = "FAILED"
)

const (
	PhaseResourceApply = "RESOURCE_APPLY"
	PhaseCheck         = "CHECK"
	PhaseMonitor       = "MONITOR"
	PhaseDeploy        = "DEPLOY"
	PhaseDrill         = "DRILL"
)
