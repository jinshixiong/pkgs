package lock

import (
	"context"
	"time"

	"gorm.io/gorm"
)

type DistributedLock struct {
	db *gorm.DB
}

func NewDistributedLock(db *gorm.DB) *DistributedLock {
	panic("not implemented")
}

func (dl *DistributedLock) Acquire(lockKey, owner string, expireSeconds int) (bool, error) {
	panic("not implemented")
}

func (dl *DistributedLock) Release(lockKey, owner string) error {
	panic("not implemented")
}

func (dl *DistributedLock) StartCleanup(ctx context.Context) {
	panic("not implemented")
}
