package cache

import (
	"time"

	"github.com/patrickmn/go-cache"
)

type LocalCache struct {
	cache *go_cache.Cache
}

func NewLocalCache(defaultTTL, cleanupInterval time.Duration) *LocalCache {
	panic("not implemented")
}

func (lc *LocalCache) Get(key string) (any, bool) {
	panic("not implemented")
}

func (lc *LocalCache) Set(key string, value any, ttl time.Duration) {
	panic("not implemented")
}

func (lc *LocalCache) Delete(key string) {
	panic("not implemented")
}

func (lc *LocalCache) Flush() {
	panic("not implemented")
}
