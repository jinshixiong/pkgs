package middleware

import (
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func JWTAuth() gin.HandlerFunc {
	panic("not implemented")
}

func AuditLog(db *gorm.DB) gin.HandlerFunc {
	panic("not implemented")
}

func RateLimit(rps int) gin.HandlerFunc {
	panic("not implemented")
}
