package config

type ServerConfig struct {
	Port int  `yaml:"port"`
	Mode string `yaml:"mode"`
}

type DatabaseConfig struct {
	Host         string `yaml:"host"`
	Port         int    `yaml:"port"`
	User         string `yaml:"user"`
	Password     string `yaml:"password"`
	DBName       string `yaml:"dbname"`
	MaxOpenConns int    `yaml:"max_open_conns"`
	MaxIdleConns int    `yaml:"max_idle_conns"`
}

type MinioConfig struct {
	Endpoint  string `yaml:"endpoint"`
	AccessKey string `yaml:"access_key"`
	SecretKey string `yaml:"secret_key"`
	UseSSL    bool   `yaml:"use_ssl"`
}

type CMDBConfig struct {
	BaseURL        string `yaml:"base_url"`
	Timeout        int    `yaml:"timeout"`
	RetryCount     int    `yaml:"retry_count"`
	RetryInterval  int    `yaml:"retry_interval"`
}

type DeployServiceConfig struct {
	BaseURL string `yaml:"base_url"`
	Timeout int    `yaml:"timeout"`
}

type MonitorServiceConfig struct {
	BaseURL string `yaml:"base_url"`
	Timeout int    `yaml:"timeout"`
}

type OpsServiceConfig struct {
	BaseURL string `yaml:"base_url"`
	Timeout int    `yaml:"timeout"`
}

type ExternalConfig struct {
	CMDB           CMDBConfig           `yaml:"cmdb"`
	DeployService  DeployServiceConfig  `yaml:"deploy_service"`
	MonitorService MonitorServiceConfig `yaml:"monitor_service"`
	OpsService     OpsServiceConfig     `yaml:"ops_service"`
}

type Config struct {
	Server       ServerConfig   `yaml:"server"`
	Database     DatabaseConfig `yaml:"database"`
	Minio        MinioConfig    `yaml:"minio"`
	AESSecretKey string         `yaml:"aes_secret_key"`
	External     ExternalConfig `yaml:"external"`
}

func Load(path string) (*Config, error) {
	panic("not implemented")
}
