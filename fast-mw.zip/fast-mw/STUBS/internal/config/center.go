package config

import (
	"context"
	"sync"

	"gorm.io/gorm"
)

type ConfigCenter struct {
	db    *gorm.DB
	store *sync.Map
}

func NewConfigCenter(db *gorm.DB) *ConfigCenter {
	panic("not implemented")
}

func (cc *ConfigCenter) Init() error {
	panic("not implemented")
}

func (cc *ConfigCenter) Get(key, group string) (string, error) {
	panic("not implemented")
}

func (cc *ConfigCenter) Set(key, group, value, operator string) error {
	panic("not implemented")
}

func (cc *ConfigCenter) StartHotReload(ctx context.Context) {
	panic("not implemented")
}
