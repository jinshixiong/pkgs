package v1

import (
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func RegisterFlowRoutes(g *gin.RouterGroup, db *gorm.DB) {
	g.POST("/flows", createFlow)
	g.GET("/flows/:id", getFlowStatus)
	g.POST("/flows/:id/phases/:type/start", startPhase)
	g.POST("/flows/:id/phases/:type/complete", completePhase)
}

func createFlow(c *gin.Context)  { panic("not implemented") }
func getFlowStatus(c *gin.Context) { panic("not implemented") }
func startPhase(c *gin.Context)   { panic("not implemented") }
func completePhase(c *gin.Context) { panic("not implemented") }
