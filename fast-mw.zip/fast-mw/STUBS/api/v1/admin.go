package v1

import (
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func RegisterAdminRoutes(g *gin.RouterGroup, db *gorm.DB) {
	checkRules := g.Group("/check-rules")
	checkRules.GET("", listCheckRules)
	checkRules.GET("/:id", getCheckRule)
	checkRules.POST("", createCheckRule)
	checkRules.PUT("/:id", updateCheckRule)
	checkRules.DELETE("/:id", deleteCheckRule)
	checkRules.GET("/match", matchCheckRules)

	drillScenes := g.Group("/drill-scenes")
	drillScenes.GET("", listDrillScenes)
	drillScenes.GET("/:id", getDrillScene)
	drillScenes.POST("", createDrillScene)
	drillScenes.PUT("/:id", updateDrillScene)
	drillScenes.DELETE("/:id", deleteDrillScene)
	drillScenes.GET("/match", matchDrillScenes)

	deployConfigs := g.Group("/deploy-configs")
	deployConfigs.GET("", listDeployConfigs)
	deployConfigs.GET("/:id", getDeployConfig)
	deployConfigs.POST("", createDeployConfig)
	deployConfigs.PUT("/:id", updateDeployConfig)
	deployConfigs.DELETE("/:id", deleteDeployConfig)
}

func listCheckRules(c *gin.Context)      { panic("not implemented") }
func getCheckRule(c *gin.Context)         { panic("not implemented") }
func createCheckRule(c *gin.Context)      { panic("not implemented") }
func updateCheckRule(c *gin.Context)      { panic("not implemented") }
func deleteCheckRule(c *gin.Context)      { panic("not implemented") }
func matchCheckRules(c *gin.Context)      { panic("not implemented") }

func listDrillScenes(c *gin.Context)      { panic("not implemented") }
func getDrillScene(c *gin.Context)         { panic("not implemented") }
func createDrillScene(c *gin.Context)      { panic("not implemented") }
func updateDrillScene(c *gin.Context)      { panic("not implemented") }
func deleteDrillScene(c *gin.Context)      { panic("not implemented") }
func matchDrillScenes(c *gin.Context)      { panic("not implemented") }

func listDeployConfigs(c *gin.Context)    { panic("not implemented") }
func getDeployConfig(c *gin.Context)       { panic("not implemented") }
func createDeployConfig(c *gin.Context)    { panic("not implemented") }
func updateDeployConfig(c *gin.Context)    { panic("not implemented") }
func deleteDeployConfig(c *gin.Context)    { panic("not implemented") }
