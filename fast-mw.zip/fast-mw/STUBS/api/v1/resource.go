package v1

import "github.com/gin-gonic/gin"

func RegisterResourceRoutes(g *gin.RouterGroup, db *gorm.DB, cfg *config.Config) {
	g.POST("/flows/:id/resource/init", initApply)
	g.PUT("/resource/items/:id", updateApplyItem)
	g.DELETE("/resource/items/:id", deleteApplyItem)
	g.POST("/flows/:id/resource/items", addApplyItem)
	g.POST("/flows/:id/resource/submit", confirmAndSubmit)
	g.GET("/flows/:id/resource/items", listApplyItems)
}

func initApply(c *gin.Context)        { panic("not implemented") }
func updateApplyItem(c *gin.Context)   { panic("not implemented") }
func deleteApplyItem(c *gin.Context)   { panic("not implemented") }
func addApplyItem(c *gin.Context)      { panic("not implemented") }
func confirmAndSubmit(c *gin.Context)  { panic("not implemented") }
func listApplyItems(c *gin.Context)    { panic("not implemented") }
