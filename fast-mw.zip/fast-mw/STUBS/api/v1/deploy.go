package v1

import "github.com/gin-gonic/gin"

func RegisterDeployRoutes(g *gin.RouterGroup, db *gorm.DB, cfg *config.Config) {
	g.GET("/flows/:id/deploy/clusters", getCheckedClusters)
	g.POST("/flows/:id/deploy/trigger", triggerDeploy)
	g.POST("/deploy/:id/retry", retryDeploy)
	g.GET("/flows/:id/deploy/detail", getDeployDetail)
	g.GET("/deploy/:id/log", getStageLog)
}

func getCheckedClusters(c *gin.Context) { panic("not implemented") }
func triggerDeploy(c *gin.Context)      { panic("not implemented") }
func retryDeploy(c *gin.Context)        { panic("not implemented") }
func getDeployDetail(c *gin.Context)    { panic("not implemented") }
func getStageLog(c *gin.Context)        { panic("not implemented") }
