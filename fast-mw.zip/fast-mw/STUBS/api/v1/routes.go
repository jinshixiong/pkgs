package v1

import (
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"

	"github.com/yourorg/fast-mw/internal/config"
	"github.com/yourorg/fast-mw/internal/middleware"
)

func RegisterRoutes(r *gin.Engine, db *gorm.DB, cfg *config.Config) {
	v1 := r.Group("/api/v1")
	v1.Use(middleware.JWTAuth())
	v1.Use(middleware.AuditLog(db))

	RegisterFlowRoutes(v1, db)
	RegisterResourceRoutes(v1, db, cfg)
	RegisterCheckRoutes(v1, db, cfg)
	RegisterMonitorRoutes(v1, db, cfg)
	RegisterDeployRoutes(v1, db, cfg)
	RegisterDrillRoutes(v1, db, cfg)
	RegisterAdminRoutes(v1, db)
	RegisterWebSocketRoute(v1, db)
}

func RegisterWebSocketRoute(g *gin.RouterGroup, db *gorm.DB) {
	g.GET("/ws/flow", handleWebSocket)
}

func handleWebSocket(c *gin.Context) { panic("not implemented") }
