package v1

import "github.com/gin-gonic/gin"

func RegisterDrillRoutes(g *gin.RouterGroup, db *gorm.DB, cfg *config.Config) {
	g.GET("/flows/:id/drill/clusters", getDeployedClusters)
	g.POST("/flows/:id/drill/execute", executeDrill)
	g.POST("/drill/:id/retry", retryDrill)
	g.GET("/flows/:id/drill/detail", getDrillDetail)
	g.GET("/drill/records/:id/log", getDrillLog)
}

func getDeployedClusters(c *gin.Context) { panic("not implemented") }
func executeDrill(c *gin.Context)         { panic("not implemented") }
func retryDrill(c *gin.Context)           { panic("not implemented") }
func getDrillDetail(c *gin.Context)       { panic("not implemented") }
func getDrillLog(c *gin.Context)          { panic("not implemented") }
