package v1

import "github.com/gin-gonic/gin"

func RegisterCheckRoutes(g *gin.RouterGroup, db *gorm.DB, cfg *config.Config) {
	g.GET("/flows/:id/check/deliver-status", queryDeliverStatus)
	g.POST("/flows/:id/check/execute", executeCheck)
	g.GET("/flows/:id/check/detail", getCheckDetail)
	g.GET("/check/records/:id/log", getCheckLog)
}

func queryDeliverStatus(c *gin.Context) { panic("not implemented") }
func executeCheck(c *gin.Context)        { panic("not implemented") }
func getCheckDetail(c *gin.Context)      { panic("not implemented") }
func getCheckLog(c *gin.Context)         { panic("not implemented") }
