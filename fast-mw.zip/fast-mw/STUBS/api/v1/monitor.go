package v1

import "github.com/gin-gonic/gin"

func RegisterMonitorRoutes(g *gin.RouterGroup, db *gorm.DB, cfg *config.Config) {
	g.POST("/flows/:id/monitor/deploy", triggerMonitorDeploy)
	g.POST("/flows/:id/monitor/config", triggerMonitorConfig)
	g.GET("/flows/:id/monitor/status", getMonitorStatus)
	g.GET("/flows/:id/monitor/log", getMonitorLog)
}

func triggerMonitorDeploy(c *gin.Context) { panic("not implemented") }
func triggerMonitorConfig(c *gin.Context)  { panic("not implemented") }
func getMonitorStatus(c *gin.Context)      { panic("not implemented") }
func getMonitorLog(c *gin.Context)         { panic("not implemented") }
