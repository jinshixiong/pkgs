# Test Specs

> 验收测试规格。每个核心功能点的测试场景，格式: 前置条件→输入→预期断言。

## Phase 1: 基础层

### TestConfigCenter_Init (P0)
- 前置: MySQL中有3条sys_config记录, group="config.common"
- 输入: `NewConfigCenter(db).Init()`
- 断言: `Get("key1", "config.common")` 返回正确value; sync.Map中有3个条目

### TestConfigCenter_HotReload (P0)
- 前置: ConfigCenter已初始化; DB中config版本=1
- 输入: DB中UPDATE config_value并version=2; 等待6秒
- 断言: `Get()` 返回新值

### TestConfigCenter_SensitiveEncryption (P0)
- 前置: AES_SECRET_KEY环境变量已设置
- 输入: `Set("api_key", "config.external.cmdb", "secret_value", "admin")` is_sensitive=true
- 断言: DB中config_value为AES加密串(非明文); `Get()` 返回明文; API返回`****`

### TestDistributedLock_AcquireRelease (P0)
- 前置: distributed_lock表存在且空
- 输入: `Acquire("deploy:cluster-a", "node1", 30)` → `Release("deploy:cluster-a", "node1")`
- 断言: Acquire返回true; 表中有记录; Release后记录消失

### TestDistributedLock_ConcurrentAcquire (P0)
- 前置: distributed_lock表存在
- 输入: 两个goroutine同时 `Acquire("same-lock", "owner1"/"owner2", 30)`
- 断言: 仅一个返回true, 另一个返回false

### TestDistributedLock_ExpiredCleanup (P1)
- 前置: 有1条锁记录expire_time=过去时间
- 输入: `StartCleanup(ctx)` 运行, 等11秒
- 断言: 过期锁记录被删除

### TestLocalCache_SetGetDelete (P0)
- 前置: LocalCache初始化, TTL=30分钟
- 输入: `Set("template:1", data, 30min)` → `Get("template:1")` → `Delete("template:1")`
- 断言: Get返回data和true; Delete后Get返回nil和false

### TestLocalCache_Flush (P1)
- 前置: 缓存中有5个条目
- 输入: `Flush()`
- 断言: 所有条目Get返回false

### TestResponseFormat (P0)
- 前置: Gin context mock
- 输入: `Success(ctx, "req123", map{"id": 1})`
- 断言: 响应JSON包含code=0, msg, reqId="req123", data, timestamp 5个字段

### TestErrcode (P1)
- 前置: 无
- 输入: 检查所有错误码常量值
- 断言: 系统级1XXX, 业务级2XXX, 核查22XX, 部署23XX, 演练24XX, 监控25XX

## Phase 2: 数据模型

### TestAutoMigrate (P0)
- 前置: MySQL连接成功
- 输入: `AutoMigrate(db)`
- 断言: 所有表创建成功; `SHOW TABLES` 包含 delivery_flow, flow_phase, resource_apply, resource_apply_item, check_rule, check_record, deploy_record, deploy_stage_log, monitor_deploy, drill_scene, drill_record, deploy_config, sys_config, sys_config_history, distributed_lock, audit_log

### TestSysConfigUniqueIndex (P0)
- 前置: sys_config表存在
- 输入: INSERT两条 config_key="same", config_group="same" 的记录
- 断言: 第二条INSERT返回唯一键冲突错误

### TestResourceApplyItemUniqueIndex (P1)
- 前置: resource_apply_item表存在
- 输入: INSERT两条 cluster_name="same", idc="same" 同一apply_id的记录
- 断言: 第二条INSERT返回唯一键冲突错误

## Phase 3: 管理配置

### TestCheckRuleService_CRUD (P0)
- 前置: DB中无核查规则
- 输入: Create(COMMON规则) → List(scope=COMMON) → Update → Delete
- 断言: Create后List返回1条; Update后字段更新; Delete后status=DISABLE

### TestCheckRuleService_MatchRules_ThreeLayers (P0)
- 前置: DB中有: 1条COMMON规则 + 1条MW_TYPE(redis)规则 + 1条CLUSTER正则(`redis-prod-*`)规则
- 输入: `MatchRules("redis-prod-a", "redis")`
- 断言: 返回3条规则, 排序为 COMMON→MW_TYPE→CLUSTER

### TestCheckRuleService_MatchRules_NoClusterMatch (P1)
- 前置: DB中有COMMON + MW_TYPE(redis) + CLUSTER正则(`kafka-*`)
- 输入: `MatchRules("redis-prod-a", "redis")`
- 断言: 返回2条(COMMON+MW_TYPE), CLUSTER正则不命中

### TestDrillSceneService_MatchScenes_ThreeLayers (P0)
- 前置: DB中有: 1条COMMON场景 + 1条MW_TYPE(redis)场景 + 1条CLUSTER正则(`redis-prod-*`)场景
- 输入: `MatchScenes("redis-prod-a", "redis")`
- 断言: 返回3条, 排序 COMMON→MW_TYPE→CLUSTER

### TestDeployConfigService_MatchConfig (P0)
- 前置: DB中有2条DeployConfig: regex=`redis-prod-*` 和 regex=`kafka-*`
- 输入: `MatchConfig("redis-prod-a")`
- 断言: 返回redis配置; 输入"kafka-cluster-b"返回kafka配置

### TestDeployConfigService_MatchConfig_NoMatch (P1)
- 前置: DB中只有redis和kafka的配置
- 输入: `MatchConfig("zookeeper-cluster-c")`
- 断言: 返回nil或error

## Phase 4: 交付流程引擎

### TestFlowEngine_CreateFlow (P0)
- 前置: DB清空
- 输入: `CreateFlow("北京三机房交付", "IDC-BJ-3", "zhangsan")`
- 断言: delivery_flow记录创建; 5个flow_phase记录创建; MONITOR和DEPLOY标记is_parallel

### TestFlowEngine_StartPhase_DependencyCheck (P0)
- 前置: flow创建, RESOURCE_APPLY=DONE, CHECK=PENDING
- 输入: `StartPhase(flowID, DEPLOY)`
- 断言: 返回错误"CHECK必须先完成"

### TestFlowEngine_StartPhase_ParallelAllowed (P0)
- 前置: flow创建, CHECK=DONE
- 输入: 同时 `StartPhase(flowID, MONITOR)` 和 `StartPhase(flowID, DEPLOY)`
- 断言: 两者均成功, 无互斥报错

### TestFlowEngine_StartPhase_SequentialNotAllowed (P0)
- 前置: flow创建, RESOURCE_APPLY=PENDING
- 输入: `StartPhase(flowID, CHECK)`
- 断言: 返回错误"RESOURCE_APPLY必须先完成"

### TestFlowWebSocket_PushStatus (P1)
- 前置: WebSocket客户端已连接
- 输入: `PushStatus(flowID, statusData)`
- 断言: 客户端收到包含flowID的JSON消息

## Phase 5: 资源申请与核查

### TestResourceService_InitApply (P0)
- 前置: CMDBClient mock返回3条资源(redis-cluster-a 3节点, kafka-cluster-b 5节点)
- 输入: `InitApply(flowID=1, refIDC="IDC-BJ-1")`
- 断言: DB中resource_apply_items有2条(2个集群); 各cluster字段正确

### TestResourceService_ConfirmAndSubmit (P0)
- 前置: 有2条apply_items, CMDBClient.SubmitResource mock成功
- 输入: `ConfirmAndSubmit(flowID=1)`
- 断言: resource_apply.status=SUBMITTED; CMDBClient.SubmitResource被调用2次; FlowPhase(RESOURCE_APPLY).status=DONE

### TestResourceService_ConfirmAndSubmit_PartialFail (P1)
- 前置: 2条items, CMDBClient.SubmitResource第1次成功第2次失败
- 输入: `ConfirmAndSubmit(flowID=1)`
- 断言: 第1集群提交成功, 第2集群返回失败明细; 不影响已成功的集群

### TestCheckService_QueryDeliverStatus (P0)
- 前置: resource_apply_items中redis-cluster-a申请3节点; CMDBClient返回2节点
- 输入: `QueryDeliverStatus(flowID=1)`
- 断言: redis-cluster-a的deliver_status=PARTIAL; expected=3, actual=2

### TestCheckService_ExecuteCheck_ThreeLayers (P0)
- 前置: MatchRules返回3条规则: COMMON(节点数核查), MW_TYPE(redis内存核查), CLUSTER(redis-prod-a主从核查)
- 输入: `ExecuteCheck(flowID=1, "redis-prod-a")`
- 断言: DB中3条check_record; COMMON先于MW_TYPE先于CLUSTER执行; 日志文件存MinIO

### TestCheckService_ExecuteCheck_ScriptType (P1)
- 前置: 1条SCRIPT类型核查规则, script_content="echo OK", judge_rule={mode: "keyword", expected: "OK"}
- 输入: `ExecuteCheck(flowID=1, "redis-prod-a")`
- 断言: SSH执行脚本; 结果PASS; log_file_path指向MinIO文件

### TestCheckService_ExecuteCheck_APIType (P1)
- 前置: 1条API类型核查规则, api_url="http://xxx", judge_rule={mode: "status_code", expected: 200}
- 输入: `ExecuteCheck(flowID=1, "redis-prod-a")`
- 断言: HTTP调用成功; 结果PASS

### TestCheckService_GetCheckLog (P0)
- 前置: MinIO中有日志文件500行
- 输入: `GetCheckLog(recordID=1, startLine=0, lineCount=100)`
- 断言: 返回100行; `GetCheckLog(recordID=1, startLine=100, lineCount=100)` 返回下一100行

## Phase 6: 部署与监控

### TestDeployService_TriggerDeploy (P0)
- 前置: DeployConfig匹配返回参数; DeployClient.TriggerDeploy返回taskID="task-123"
- 输入: `TriggerDeploy(flowID=1, "redis-prod-a")`
- 断言: DB中deploy_record创建; 后台协程启动轮询状态

### TestDeployService_GetCheckedClusters (P0)
- 前置: flow中有3个集群核查通过(2redis+1kafka), mwType="redis"
- 输入: `GetCheckedClusters(flowID=1, "redis")`
- 断言: 返回2个redis集群; 各携带部署参数(来自DeployConfig)

### TestDeployService_RetryDeploy (P0)
- 前置: deploy_record.status=FAILED, DeployClient.RetryDeploy成功
- 输入: `RetryDeploy(deployID=1)`
- 断言: status重置为PENDING; retry_count+1

### TestDeployService_GetStageLog (P1)
- 前置: MinIO中有部署日志文件300行
- 输入: `GetStageLog(deployID=1, "DEPLOY", 0, 100)`
- 断言: 返回100行日志内容

### TestMonitorService_TriggerDeploy (P0)
- 前置: MonitorClient.TriggerDeploy返回taskID
- 输入: `TriggerDeploy(flowID=1, ips=["10.1.1.1","10.1.1.2"])`
- 断言: DB中monitor_deploy记录创建; deploy_status=RUNNING

### TestMonitorService_TriggerConfig (P0)
- 前置: MonitorClient.TriggerConfig返回taskID
- 输入: `TriggerConfig(flowID=1, clusterNames=["redis-prod-a"])`
- 断言: config_status=RUNNING

## Phase 7: 演练

### TestDrillService_GetDeployedClusters (P0)
- 前置: 5集群中2个deploy_record.status=DONE
- 输入: `GetDeployedClusters(flowID=1, "redis")`
- 断言: 返回2个DONE的集群

### TestDrillService_ExecuteDrill_AllScenes (P0)
- 前置: MatchScenes返回3个场景(COMMON+MW_TYPE+CLUSTER); 每个场景2个步骤
- 输入: `ExecuteDrill(flowID=1, "redis-prod-a", sceneIDs=[])` (空=全部)
- 断言: 执行6个步骤(3场景×2步骤); COMMON→MW_TYPE→CLUSTER顺序; DB中3条drill_record

### TestDrillService_ExecuteDrill_SpecificScene (P1)
- 前置: 指定1个场景
- 输入: `ExecuteDrill(flowID=1, "redis-prod-a", sceneIDs=[5])`
- 断言: 仅执行场景5的步骤; DB中1条drill_record

### TestDrillService_RetryDrill (P0)
- 前置: drill_record.status=FAILED
- 输入: `RetryDrill(drillID=1)`
- 断言: 重新执行该场景; status重置

### TestDrillService_StepTypes (P0)
- 前置: 1个场景含SHELL步骤+API步骤
- 输入: `ExecuteDrill(flowID=1, "redis-prod-a", sceneIDs=[sceneID])`
- 断言: SHELL步骤调用OpsClient.ExecuteScript; API步骤调用OpsClient.CallAPI

## Phase 8: 前端

### TestFlowDetailPage_Render (P1)
- 前置: Mock API返回flow含5个phase
- 输入: 访问 FlowDetail.vue
- 断言: 页面显示5个PhaseCard; MONITOR和DEPLOY并行排列

### TestWebSocket_Connection (P1)
- 前置: 后端WebSocket端点可用
- 输入: 连接WebSocket
- 断言: 收到状态推送消息

### TestLogViewer_Pagination (P1)
- 前置: Mock API返回100行日志
- 输入: 打开LogViewer, 点击"下一页"
- 断言: 显示下一100行; 总页数正确

### TestAdminPage_CRUD (P1)
- 前置: Mock API
- 输入: 在核查规则Tab创建→编辑→删除规则
- 断言: 表格数据更新正确

## 全局验收

### TestRESTfulPaths (P0)
- 前置: 服务启动
- 输入: 检查所有路由
- 断言: 无 `/api/v1/getXxx` 或 `/api/v1/doXxx` 等动词路径

### TestResponseFormatConsistency (P0)
- 前置: 服务启动
- 输入: 调用任意API
- 断言: 响应JSON包含 code/msg/reqId/data/timestamp

### TestNoMiddlewareDependency (P0)
- 前置: go.mod文件
- 输入: `grep redis/nacos/elastic go.mod`
- 断言: 返回空

### TestGoBuild (P0)
- 前置: 所有代码完成
- 输入: `go build ./cmd/server/`
- 断言: 编译成功无错误

### TestGoTestAll (P0)
- 前置: 所有代码完成
- 输入: `go test ./...`
- 断言: 全部P0测试通过
## CONSTRAINT覆盖映射表

> 每条CONSTRAINT对应哪些测试用例覆盖。编号C01-C76对应CONSTRAINTS.md表格的76条约束行(文件行7-82)。

| CONSTRAINT编号 | 约束关键词 | 覆盖测试 | 优先级 | 备注 |
|---|---|---|---|---|
| C01 | 仅依赖MySQL+MinIO | TestNoMiddlewareDependency | P0 | 已有覆盖 |
| C02 | AES-256加密存储敏感配置 | TestConfigCenter_SensitiveEncryption | P0 | 已有覆盖，需补充GCM模式验证(C62) |
| C03 | 配置热更新10秒内生效 | TestConfigCenter_HotReload | P0 | 已有覆盖，需补充清理DISABLE场景(C40) |
| C04 | 进程内缓存30分钟过期 | TestLocalCache_SetGetDelete | P0 | 已有覆盖，需补充TTL过期测试 |
| C05 | CMDB接口超时30秒重试3次间隔5秒 | TestCMDBClient_Retry | P0 | **新增** |
| C06 | 脚本核查超时60秒 | TestOpsClient_ScriptTimeout | P0 | **新增** |
| C07 | MinIO签名链接1小时 | TestMinioClient_SignedURL | P1 | **新增** |
| C08 | 日志分页100行/页 | TestCheckService_GetCheckLog + TestMinioClient_ReadLines | P0 | 已有部分覆盖，需补充通用ReadLines测试(C45) |
| C09 | MySQL分表按月 | TestAuditLog_MonthlyTable | P0 | **新增** |
| C10 | 分布式锁自动过期释放 | TestDistributedLock_ExpiredCleanup | P1 | 已有覆盖，需补充Acquire过期覆盖场景(C41) |
| C11 | 幂等批量防重 | TestResourceApplyItemUniqueIndex | P1 | 已有覆盖 |
| C12 | 逻辑删除不物理删除 | TestResourceService_DeleteApplyItemLogicalDelete + TestCheckRuleService_CRUD | P0 | 部分已有(核查规则Delete)，需补充ResourceItem逻辑删除(C70) |
| C13 | 令牌桶限流单节点 | TestRateLimit_Limiter + TestRateLimit_NonBlocking | P0 | **新增** |
| C14 | JWT无状态8小时 | TestJWTAuth_TokenExpiry | P1 | **新增** |
| C15 | 审计日志全量不可篡改 | TestAuditLog_NoUpdateDelete | P1 | **新增** |
| C16 | RESTful接口名词复数路径 | TestRESTfulPaths | P0 | 已有覆盖 |
| C17 | 统一请求响应格式 | TestResponseFormatConsistency | P0 | 已有覆盖 |
| C18 | 错误码分段 | TestErrcode | P1 | 已有覆盖 |
| C19 | 核查三层顺序COMMON→MW_TYPE→CLUSTER | TestCheckRuleService_MatchRules_ThreeLayers | P0 | 已有覆盖 |
| C20 | 演练三层顺序同核查 | TestDrillSceneService_MatchScenes_ThreeLayers | P0 | 已有覆盖 |
| C21 | 集群名称正则匹配 | TestDeployConfigService_MatchConfig + TestDeployConfigService_MatchConfig_NoMatch | P0 | 已有覆盖(部署配置正则)，需补充CheckRule/DrillScene正则场景 |
| C22 | 监控与部署并行无互斥依赖 | TestFlowEngine_StartPhase_ParallelAllowed | P0 | 已有覆盖 |
| C23 | 演练不等全部集群部署完成 | TestDrillService_GetDeployedClusters | P0 | 已有覆盖 |
| C24 | 用户手动触发不自动流转 | TestNoAutoTrigger | P1 | **新增** |
| C25 | 中间件类型枚举 | TestMWTypeEnumValidation | P1 | **新增** |
| C26 | InnoDB+UTF8MB4 | TestDBCharset | P1 | **新增** |
| C27 | 禁止聪明代码 | TestNoGenericFramework | P2 | **新增** |
| C28 | goroutine可追踪可取消 | TestDeployService_StopTask | P0 | **新增** |
| C29 | goroutine必须有panic恢复 | TestDeployService_PanicRecovery | P0 | **新增** |
| C30 | 多表写入必须在同一事务内 | TestFlowEngine_CompletePhaseTransaction | P0 | **新增** |
| C31 | 同集群不可并发触发相同操作 | TestDeployService_ConcurrentTrigger | P0 | **新增** |
| C32 | SSH凭据从SysConfig读取 | TestOpsClient_SSHCredentialsFromConfig | P0 | **新增** |
| C33 | 进程重启后恢复未完成轮询任务 | TestDeployService_RecoverAfterRestart | P0 | **新增** |
| C34 | DeployStageLog必须有Status字段 | TestDeployStageLog_StatusField | P1 | **新增** |
| C35 | MonitorDeploy必须有TaskID字段 | TestMonitorDeploy_TaskIDFields | P1 | **新增** |
| C36 | 提交失败必须记录失败原因 | TestResourceApplyItem_FailReason | P0 | **新增** |
| C37 | ConfigCenter.Get脱敏不返回真实值 | TestConfigCenter_GetDesensitization | P0 | **新增** |
| C38 | ConfigCenter.GetRealValue返回真实值 | TestConfigCenter_GetRealValue | P0 | **新增** |
| C39 | ConfigCenter sync.Map存储结构 | TestConfigCenter_StoreStructure | P1 | **新增** |
| C40 | 热更新需清理已删除配置项 | TestConfigCenter_HotReloadCleanDisabled | P0 | **新增** |
| C41 | 分布式锁Acquire过期锁可覆盖 | TestDistributedLock_AcquireExpiredOverwrite | P0 | **新增**，与C10部分重叠但场景不同 |
| C42 | 分布式锁Release需验证owner | TestDistributedLock_ReleaseOwnerVerification | P0 | **新增** |
| C43 | AuditLog operator从JWT context取 | TestAuditLog_OperatorFromJWT | P0 | **新增** |
| C44 | AuditLog.TableName动态按月分表 | TestAuditLog_MonthlyTable | P0 | 同C09，合并为一个测试 |
| C45 | MinIO ReadLines全量下载后按行分割 | TestMinioClient_ReadLines | P0 | **新增** |
| C46 | InitApply CMDB数据按集群合并 | TestResourceService_InitApply | P0 | 已有覆盖 |
| C47 | InitApply ownerGroup/opsGroup从配置取 | TestResourceService_InitApply_ConfigCenterParams | P1 | **新增**，补充ConfigCenter依赖场景 |
| C48 | QueryDeliverStatus对比并回填IPs | TestCheckService_QueryDeliverStatus | P0 | 已有覆盖 |
| C49 | CRUD Create字段校验 | TestCheckRuleService_FieldValidation + TestDrillSceneService_FieldValidation + TestDeployConfigService_FieldValidation | P0 | **新增** |
| C50 | JWTAuth token解析与context注入 | TestJWTAuth_TokenParsing | P0 | **新增** |
| C51 | JWT claims结构固定 | TestJWTAuth_ClaimsStructure | P1 | **新增**，合并到C50 |
| C52 | JWT_SECRET_KEY从环境变量读取 | TestJWTAuth_SecretKeyEnv | P1 | **新增** |
| C53 | RateLimit令牌桶非阻塞 | TestRateLimit_NonBlocking | P0 | **新增**，与C13合并为完整限流测试 |
| C54 | WebSocket Hub单流程订阅 | TestFlowWebSocket_PushStatus + TestWebSocket_SingleFlowSubscription | P1 | 已有部分覆盖，需补充单流程订阅场景 |
| C55 | WebSocket非阻塞推送 | TestWebSocket_NonBlockingPush | P1 | **新增** |
| C56 | main.go依赖注入顺序 | TestMainInitOrder | P2 | **新增** |
| C57 | main.go优雅退出顺序 | TestGracefulShutdown | P1 | **新增** |
| C58 | API handler统一模式 | TestHandlerPattern | P2 | **新增** |
| C59 | OpsClient每次SSH重新读取凭据 | TestOpsClient_CredentialsPerCall | P0 | **新增**，与C32互补 |
| C60 | SSH连接超时30秒脚本超时60秒 | TestOpsClient_ConnectionTimeout | P0 | **新增**，与C06互补 |
| C61 | SSH HostKeyCallback不校验 | TestOpsClient_HostKeyCallback | P2 | **新增** |
| C62 | AES-256-GCM加密模式 | TestAES256GCM | P0 | **新增** |
| C63 | SysConfig BeforeCreate Hook加密 | TestSysConfig_BeforeCreateEncryption | P0 | **新增** |
| C64 | SysConfig BeforeUpdate防重复加密 | TestSysConfig_BeforeUpdateNoDoubleEncrypt | P0 | **新增** |
| C65 | SysConfig AfterFind解密不脱敏 | TestSysConfig_AfterFindDecryptNotDesensitize | P0 | **新增** |
| C66 | DeployClient HTTP调用模式 | TestDeployClient_HTTPMode | P0 | **新增** |
| C67 | MonitorClient HTTP调用模式 | TestMonitorClient_HTTPMode | P0 | **新增** |
| C68 | OpsClient.CallAPI调用模式 | TestOpsClient_CallAPIMode | P0 | **新增** |
| C69 | ants协程池使用模式 | TestAntsPoolUsage | P0 | **新增** |
| C70 | ResourceApplyItem必须有Status字段 | TestResourceApplyItem_StatusField | P0 | **新增**，与C12逻辑删除互补 |
| C71 | ResourceService CRUD前置状态校验 | TestResourceService_StatusValidation | P0 | **新增** |
| C72 | AddApplyItem必填字段校验 | TestResourceService_AddItemValidation | P0 | **新增** |
| C73 | GetCheckedClusters核查通过聚合判定 | TestDeployService_GetCheckedClusters | P0 | 已有覆盖，需补充混合PASS+FAIL场景 |
| C74 | DeployService.RetryDeploy双路径模式 | TestDeployService_RetryDeploy_TaskIDNotEmpty + TestDeployService_RetryDeploy_TaskIDEmpty | P0 | 已有部分覆盖，需补充双路径 |
| C75 | DrillService.RetryDrill删除+重执行模式 | TestDrillService_RetryDrill_DeleteAndRerun | P0 | 已有部分覆盖，需补充物理删除+单场景重执行 |
| C76 | 查询ApplyItem必须过滤DISABLE | TestResourceService_QueryFilterDisabled | P0 | **新增** |
| C77 | MonitorDeployVO/MonitorConfigVO结构体 | TestMonitorService_VOFields | P1 | **新增**，补充VO字段验证 |

---

## 新增测试场景定义

> 为尚未覆盖的CONSTRAINT新增测试用例，格式: 前置条件→输入→预期断言。按Phase分组。

### Phase 1 补充: 基础层

#### P0 级别

### TestCMDBClient_Retry (C05)
- 前置: CMDBClient初始化; mock HTTP服务第1次返回超时, 第2次返回超时, 第3次返回200+正常JSON
- 输入: `cmdbClient.QueryResources("IDC-BJ-1")`
- 断言: HTTP请求发出3次; 间隔≥5秒; 最终返回正常数据; 3次都超时→返回ErrCMDBAPIFailed

### TestCMDBClient_Retry_NoRetryOn400 (C05补充)
- 前置: mock HTTP服务返回400 Bad Request
- 输入: `cmdbClient.QueryResources("IDC-BJ-1")`
- 断言: 仅1次请求(不重试); 返回ErrParamInvalid

### TestOpsClient_ScriptTimeout (C06)
- 前置: SSH mock服务, 脚本执行模拟sleep 70秒
- 输入: `opsClient.ExecuteScript("10.1.1.1", "sleep 70", 60*time.Second)`
- 断言: 60秒后返回超时错误; error包含"timeout"; ErrCheckFailed错误码

### TestMinioClient_ReadLines (C45)
- 前置: MinIO中有200行日志文件, 内容含`\r\n` Windows换行
- 输入: `ReadLines(bucket, object, startLine=0, 100)`
- 断言: 返回100行; 每行不含`\r`; `ReadLines(bucket, object, startLine=100, 100)` 返回下一100行; `ReadLines(bucket, object, startLine=300, 100)` 返回空列表(越界)

### TestAuditLog_MonthlyTable (C09+C44)
- 前置: AuditLog模型; 当前时间2024-06-15
- 输入: 创建一条AuditLog(OperateTime=time.Parse("2024-06-15"))
- 断言: `AuditLog.TableName()` 返回 `"audit_log_202406"`; DB中 `audit_log_202406` 表存在该记录; OperateTime为零值时TableName使用当前月份

### TestConfigCenter_GetDesensitization (C37)
- 前置: ConfigCenter已初始化; DB中有1条IsSensitive=true的配置(api_key=真实密钥)
- 输入: `configCenter.Get("api_key", "config.external.cmdb")`
- 断言: 返回 `"****"`; 不返回真实密钥明文

### TestConfigCenter_GetRealValue (C38)
- 前置: 同C37前置
- 输入: `configCenter.GetRealValue("api_key", "config.external.cmdb")`
- 断言: 返回真实密钥明文; 非IsSensitive配置Get()与GetRealValue()返回相同值

### TestConfigCenter_HotReloadCleanDisabled (C40)
- 前置: ConfigCenter已初始化; sync.Map中有5个entry(group="ops"); DB中将1条配置Status改为DISABLE
- 输入: 等待6秒(热更新轮询周期)
- 断言: sync.Map中该entry被Delete; `Get(disabled_key, "ops")` 返回空

### TestConfigCenter_StoreStructure (C39)
- 前置: ConfigCenter已初始化; DB中有IsSensitive=true配置(加密存储)
- 输入: 检查sync.Map内部数据
- 断言: key格式为`{group}:{key}`(如"ops:ssh_user"); value为ConfigEntry{Value=解密明文, Version=int, IsSensitive=true}; Map存明文而非加密串

### TestAES256GCM (C62)
- 前置: AES_SECRET_KEY环境变量已设置(32字节)
- 输入: `aesEncrypt("plaintext")` → 检查密文格式 → `aesDecrypt(密文)`
- 断言: 解密还原原始值; 密文为base64编码; 相同明文两次加密→密文不同(nonce随机); 截取密文前12字节为nonce; 密文非AES-CBC格式(无固定块填充)

### TestSysConfig_BeforeCreateEncryption (C63)
- 前置: AES_SECRET_KEY已设置; DB清空
- 输入: `db.Create(&SysConfig{ConfigKey:"ssh_key", ConfigGroup:"ops", ConfigValue:"real_password", IsSensitive:true})`
- 断言: DB中ConfigValue为base64加密串(非"real_password"); IsSensitive=false的配置DB中ConfigValue为明文

### TestSysConfig_BeforeUpdateNoDoubleEncrypt (C64)
- 前置: DB中有1条IsSensitive=true配置(已加密存储)
- 输入(场景1): `db.Save(&config)` (config.ConfigValue为AfterFind解密后的明文)
- 断言: BeforeUpdate检测到明文→重新加密; DB值仍为加密串(不双重加密)
- 输入(场景2): 直接UPDATE传入新明文值 `db.Model(&SysConfig{}).Where("id=?", id).Update("config_value", "new_password")`
- 断言: DB中存储为加密串(非明文"new_password")

### TestSysConfig_AfterFindDecryptNotDesensitize (C65)
- 前置: DB中有1条IsSensitive=true配置(加密存储)
- 输入: `db.First(&config, id)`
- 断言: config.ConfigValue为解密后明文(非`****`); config.ConfigValue为解密后明文(非加密串); db.Save(&config)触发BeforeUpdate→加密→DB值仍为加密串(AfterFind修改struct不写回DB)

### TestDeployClient_HTTPMode (C66)
- 前置: mock HTTP服务
- 输入(场景1): mock POST返回500 → `deployClient.TriggerDeploy(params)`
- 断言: 仅1次请求(不重试); 返回ErrAPICallFailed
- 输入(场景2): mock POST超时 → `deployClient.TriggerDeploy(params)`
- 断言: 30秒后返回ErrAPICallFailed; 不重试
- 输入(场景3): mock GET返回200 → `deployClient.GetDeployStatus(taskID)`
- 断言: 正常解析JSON响应
- 输入(场景4): mock GET返回500 → 调用后不报错(GET可容忍, 10秒后轮询重试)

### TestMonitorClient_HTTPMode (C67)
- 前置: mock HTTP服务
- 输入(场景1): mock POST返回500 → `monitorClient.TriggerDeploy(params)`
- 断言: 仅1次请求(不重试); 返回ErrAPICallFailed
- 输入(场景2): mock POST超时 → `monitorClient.TriggerConfig(params)`
- 断言: 30秒后返回ErrAPICallFailed; 不重试
- 输入(场景3): TriggerDeploy和TriggerConfig调用模式完全对称(相同HTTP模式)

### TestOpsClient_CallAPIMode (C68)
- 前置: mock HTTP服务; OpsClient初始化
- 输入(场景1): `opsClient.CallAPI("GET", "http://api.example.com/check", params={"key":"value"})`
- 断言: URL包含query参数`?key=value`; Body为空; 响应解析为map[string]any
- 输入(场景2): `opsClient.CallAPI("POST", "http://api.example.com/check", params={"key":"value"})`
- 断言: Body为JSON`{"key":"value"}`; 不重试; 500响应→ErrAPICallFailed
- 输入(场景3): `opsClient.CallAPI("PATCH", url, params)` → 返回ErrParamInvalid(非标准方法)
- 输入(场景4): mock响应非JSON → result包含raw_response+status_code字段

### TestAntsPoolUsage (C69)
- 前置: ants.NewPool(10); 5个节点IP; CheckService SCRIPT规则
- 输入: ExecuteCheck调用pool.Submit对5节点并发SSH
- 断言: nodeResults有5条记录(每节点1条); 闭包内panic→Status=FAILED+日志记录; pool.Submit失败→wg.Done()被调用(不阻塞WaitGroup); 执行顺序: 三层规则串行, 仅多节点并行

### TestLocalCache_TTLExpiry (C04补充)
- 前置: LocalCache初始化, TTL=30分钟
- 输入: `Set("template:1", data, 30*time.Minute)` → 等待31分钟(或mock时间推进)
- 断言: `Get("template:1")` 返回nil和false(TTL过期)

#### P1 级别

### TestMinioClient_SignedURL (C07)
- 前置: MinIO中有文件对象
- 输入: `minioClient.GetSignedURL(bucket, object)`
- 断言: URL包含expires参数≤3600秒; URL可正常访问文件内容

### TestJWTAuth_TokenExpiry (C14)
- 前置: 生成JWT token(exp=now+8h)
- 输入(场景1): 8小时后解析token
- 断言: jwt.ParseWithClaims返回expired错误; 中间件返回401
- 输入(场景2): 7小时59分解析token
- 断言: token有效; context中有user_id

### TestJWTAuth_TokenParsing (C50+C51)
- 前置: 生成合法JWT token(CustomClaims{UserID:123, Role:"admin"})
- 输入(场景1): 带合法token请求API
- 断言: c.Get("user_id")=123; c.Get("user_role")="admin"
- 输入(场景2): 带过期token请求 → 返回401
- 输入(场景3): 无Authorization头请求 → 返回401
- 输入(场景4): Authorization格式错误(非Bearer) → 返回401

### TestJWTAuth_SecretKeyEnv (C52)
- 前置: JWT_SECRET_KEY环境变量为空
- 输入: JWTAuth中间件处理请求
- 断言: 返回500错误(密钥为空); 设置JWT_SECRET_KEY后→正常解析

### TestAuditLog_OperatorFromJWT (C43)
- 前置: AuditLog中间件; JWT认证请求(user_id=456)
- 输入(场景1): 带JWT请求POST /api/v1/check-rules
- 断言: audit_log记录的operator="456"; Body被恢复(后续handler可正常读取)
- 输入(场景2): 未认证请求(无JWT)
- 断言: audit_log记录的operator="anonymous"

### TestAuditLog_NoUpdateDelete (C15)
- 前置: DB中有audit_log记录; 应用用户仅有INSERT+SELECT权限
- 输入: `db.Model(&AuditLog{}).Where("id=?", 1).Update("operator", "hacked")`
- 断言: 返回权限拒绝错误; `db.Delete(&AuditLog{}, 1)` → 返回权限拒绝错误

### TestOpsClient_SSHCredentialsFromConfig (C32)
- 前置: ConfigCenter中有ssh_user="root", ssh_private_key="密钥内容"
- 输入: `opsClient.ExecuteScript("10.1.1.1", "echo hello")`
- 断言: SSH连接使用ConfigCenter读取的凭据; 不使用硬编码凭据

### TestOpsClient_CredentialsPerCall (C59)
- 前置: OpsClient已执行1次SSH(使用旧密钥); 修改SysConfig中ssh_private_key为新密钥
- 输入: 再次调用 `opsClient.ExecuteScript("10.1.1.1", "echo hello")`
- 断言: 使用新密钥连接(不使用缓存的旧密钥)

### TestOpsClient_ConnectionTimeout (C60)
- 前置: SSH mock连接模拟超时(不响应)
- 输入: `opsClient.ExecuteScript("10.1.1.1", "echo hello")`
- 断言: 30秒内返回连接超时错误; 不等待60秒脚本超时

### TestWebSocket_SingleFlowSubscription (C54补充)
- 前置: WebSocket Hub; 两个客户端连接订阅同一flowID=5
- 输入: 第二个客户端订阅flowID=5
- 断言: Hub.clients[5]只保留最新连接(旧连接被注销); flowID=0的连接不收到PushStatus推送

### TestWebSocket_NonBlockingPush (C55)
- 前置: WebSocket Hub; broadcast channel缓冲256条
- 输入: 连续发送300条PushStatus消息(超出channel缓冲)
- 断言: 前256条正常推送; 超出部分丢弃+日志记录; 推送不阻塞业务逻辑(无死锁)

#### P2 级别

### TestNoAutoTrigger (C24)
- 前置: 全部业务Service代码
- 输入: `grep -rn 'cron\|ticker\|ScheduleFunc' internal/`
- 断言: 无自动调用StartPhase/TriggerDeploy/ExecuteCheck/ExecuteDrill的定时器代码

### TestMWTypeEnumValidation (C25)
- 前置: common/enum.go定义MWType常量
- 输入(场景1): 传入mwType="redis" → 校验合法
- 输入(场景2): 传入mwType="tomcat" → 返回ErrParamInvalid(不在枚举中)
- 断言: 合法值仅nginx/zookeeper/kafka/rocketmq/minio/redis

### TestDBCharset (C26)
- 前置: InitDB已执行; MySQL连接
- 输入: `SHOW TABLE STATUS LIKE 'delivery_flow'`
- 断言: Engine=InnoDB; `SHOW CREATE TABLE delivery_flow` 包含utf8mb4

### TestNoGenericFramework (C27)
- 前置: 全部.go文件
- 输入: `grep -rn 'func.*\[T any\]' internal/` + `grep -rn 'func Handle\[' internal/`
- 断言: 返回空(无泛型业务处理函数); 检查任意函数不超过50行; 检查无3层以上嵌套

### TestMainInitOrder (C56)
- 前置: main.go代码
- 输入: 检查初始化函数调用顺序
- 断言: config→database→cache→lock→ConfigCenter→MinIO→adapters→pool→admin→business→flow→middleware→routes; OpsClient在ConfigCenter之后初始化

### TestHandlerPattern (C58)
- 前置: 全部api/v1/*.go handler代码
- 输入: `grep -rn 'db\.Create\|db\.Find\|db\.Where' api/v1/`
- 断言: 返回空(handler不含直接DB操作); 所有handler使用ShouldBindJSON/Query→Service调用→response.Success/Fail模式

### TestOpsClient_HostKeyCallback (C61)
- 前置: OpsClient SSH连接代码
- 输入: SSH连接到未知主机
- 断言: 不报HostKey验证错误(当前使用InsecureIgnoreHostKey); ssh.ClientConfig.HostKeyCallback=ssh.InsecureIgnoreHostKey()

### TestDistributedLock_AcquireExpiredOverwrite (C41)
- 前置: distributed_lock表中有1条记录, expire_time=过去时间(已过期)
- 输入: `Acquire("same-lock", "new-owner", 30)`
- 断言: 返回true(过期锁被覆盖); 表中lock_owner="new-owner"; expire_time更新为新值

### TestDistributedLock_ReleaseOwnerVerification (C42)
- 前置: 分布式锁由owner-A持有
- 输入(场景1): `Release("lock-key", "owner-A")` → 记录被删除
- 输入(场景2): `Release("lock-key", "owner-B")` → 返回错误"锁不存在或非持有者"; 记录仍存在
- 断言: owner不匹配时不删除锁

### Phase 2 补充: 数据模型

#### P0 级别

### TestDeployStageLog_StatusField (C34)
- 前置: AutoMigrate已执行; 创建DeployRecord
- 输入: TriggerDeploy创建3条DeployStageLog
- 断言: 每条DeployStageLog有Status字段; 3条Status均为PENDING; VALIDATE/DEPLOY/VERIFY三阶段各1条

### TestMonitorDeploy_TaskIDFields (C35)
- 前置: AutoMigrate已执行; MonitorDeploy模型
- 输入: TriggerDeploy创建MonitorDeploy记录
- 断言: MonitorDeploy.DeployTaskID非空; TriggerConfig后ConfigTaskID非空; ConfigLogPath字段存在

### TestResourceApplyItem_FailReason (C36)
- 前置: ResourceApplyItem模型; mock CMDB提交失败
- 输入: ConfirmAndSubmit → CMDB.SubmitResource返回错误
- 断言: item.FailReason=err.Error()内容; 重试成功后FailReason清空

### TestResourceApplyItem_StatusField (C70)
- 前置: ResourceApplyItem模型; 1条item
- 输入(场景1): DeleteApplyItem → 检查DB
- 断言: item.Status="DISABLE"; 记录仍存在(不物理删除)
- 输入(场景2): 删除后再新增相同ClusterName+IDC → 不报唯一索引冲突(DISABLE不计入)

### Phase 3 补充: 管理配置

#### P0 级别

### TestCheckRuleService_FieldValidation (C49)
- 前置: 无
- 输入(场景1): 创建scope=CLUSTER但ClusterRegex为空的规则 → 返回ErrParamInvalid
- 输入(场景2): 创建scope=MW_TYPE但MWType为空的规则 → 返回ErrParamInvalid
- 输入(场景3): 创建JudgeRule mode=keyword但expected为空 → 返回ErrParamInvalid
- 输入(场景4): 创建JudgeRule mode=range但min/max缺失 → 返回ErrParamInvalid
- 断言: 各场景校验失败返回ErrParamInvalid+具体提示

### TestDrillSceneService_FieldValidation (C49补充)
- 前置: 无
- 输入(场景1): 创建Steps中Name为空的场景 → 返回ErrParamInvalid
- 输入(场景2): 创建Steps中Type非法(SHELL/ANSIBLE/API之外) → 返回ErrParamInvalid
- 输入(场景3): 创建Steps中Target IP格式非法 → 返回ErrParamInvalid
- 断言: 各场景校验失败

### TestDeployConfigService_FieldValidation (C49补充)
- 前置: 无
- 输入(场景1): 创建Params中Name为空的配置 → 返回ErrParamInvalid
- 输入(场景2): 创建Params中WidgetType非法 → 返回ErrParamInvalid
- 断言: 各场景校验失败

### TestCheckRuleService_MatchRules_ClusterRegex (C21补充)
- 前置: DB中有CheckRule ClusterRegex=`redis-cluster-prod-*`
- 输入: `MatchRules("redis-cluster-prod-a", "redis")`
- 断言: 正则匹配命中; 输入"redis-cluster-dev-b" → 不命中

### Phase 4 补充: 交付流程引擎

#### P0 级别

### TestFlowEngine_CompletePhaseTransaction (C30)
- 前置: flow创建; RESOURCE_APPLY=PENDING
- 输入: `CompletePhase(flowID, RESOURCE_APPLY)`
- 断言: FlowPhase.Status=DONE + DeliveryFlow.CurrentPhase更新在同一事务内; mock FlowPhase更新成功但DeliveryFlow更新失败→两者都回滚

### TestDeployService_ConcurrentTrigger (C31)
- 前置: DistributedLock可用; 两个goroutine准备触发同一集群部署
- 输入: goroutine-A和goroutine-B同时调用 `TriggerDeploy(flowID=1, "redis-prod-a")`
- 断言: 仅一个成功; 另一个返回ErrConcurrentTrigger(1005)

### TestDeployService_StopTask (C28)
- 前置: TriggerDeploy已启动后台轮询goroutine; activeTasks有记录
- 输入: `StopTask(flowID)`
- 断言: goroutine在1秒内退出(ctx.Done()触发); activeTasks中该flowID的cancel被调用; 无goroutine泄漏

### TestDeployService_PanicRecovery (C29)
- 前置: TriggerDeploy启动; mock轮询逻辑内部panic("unexpected error")
- 输入: 后台goroutine执行过程中panic
- 断言: defer recover捕获panic; DeployRecord.Status=FAILED; FailReason包含panic信息; WebSocket推送失败状态; 服务不崩溃(主进程继续运行)

### TestDeployService_RecoverAfterRestart (C33)
- 前置: deploy_record有1条status=DEPLOYING, taskID非空; monitor_deploy有1条deploy_status=RUNNING, deploy_task_id非空
- 输入: 模拟进程重启(调用恢复逻辑)
- 断言: 重新启动轮询goroutine继续跟踪状态; taskID为空的未完成记录→标记Status=FAILED

#### P1 级别

### TestGracefulShutdown (C57)
- 前置: 服务运行; 2个活跃后台goroutine
- 输入: 发送SIGTERM信号
- 断言: srv.Shutdown(5s超时); cancel()通知所有goroutine; StopAllTasks()调用; pool.Release(); db.Close(); 5秒内HTTP服务关闭

### Phase 5 补充: 资源申请与核查

#### P0 级别

### TestResourceService_DeleteApplyItemLogicalDelete (C12补充)
- 前置: ResourceApply.Status=DRAFT; 1条ApplyItem
- 输入: `DeleteApplyItem(itemID)`
- 断言: item.Status="DISABLE"(不物理删除); DB中记录仍存在; 查询列表不含DISABLE记录

### TestResourceService_StatusValidation (C71)
- 前置: ResourceApply.Status=SUBMITTED; 1条ApplyItem
- 输入(场景1): `UpdateApplyItem(itemID, ...)`
- 断言: 返回ErrParamInvalid("申请已提交，不可修改")
- 输入(场景2): `DeleteApplyItem(itemID)`
- 断言: 返回ErrParamInvalid("申请已提交，不可删除")
- 输入(场景3): `AddApplyItem(flowID, newItem)`
- 断言: 返回ErrParamInvalid("申请已提交，不可新增")
- 输入(场景4): ResourceApply.Status=DRAFT → 三个方法均正常执行

### TestResourceService_AddItemValidation (C72)
- 前置: ResourceApply.Status=DRAFT
- 输入(场景1): AddApplyItem ClusterName为空 → ErrParamInvalid
- 输入(场景2): AddApplyItem MWType="tomcat"(非法) → ErrParamInvalid
- 输入(场景3): AddApplyItem IDC为空 → ErrParamInvalid
- 输入(场景4): AddApplyItem NodeCount=0 → ErrParamInvalid
- 输入(场景5): AddApplyItem Env为空 → 默认值"prod"; IPs为空; DeliverStatus="NONE"; FailReason为空; Status="ENABLE"

### TestResourceService_QueryFilterDisabled (C76)
- 前置: 5条ApplyItem中2条Status=DISABLE
- 输入: 查询ApplyItem列表(各种方法: InitApply内部查询/ConfirmAndSubmit/GetCheckedClusters等)
- 断言: 查询结果不含DISABLE记录; NodeCount统计不含DISABLE条目

### TestResourceService_InitApply_ConfigCenterParams (C47)
- 前置: ConfigCenter有default_owner_group="ops-team", default_ops_group="infra-team"
- 输入: `InitApply(flowID=1, "IDC-BJ-1")`
- 断言: ApplyItem.OwnerGroup="ops-team"; OpsGroup="infra-team"; ConfigCenter未配置时→传空字符串不报错

### Phase 6 补充: 部署与监控

#### P0 级别

### TestDeployService_GetCheckedClusters_MixedResults (C73补充)
- 前置: 集群redis-prod-a有2条PASS+1条FAIL的CheckRecord; 集群redis-prod-b有3条PASS+0条FAIL
- 输入: `GetCheckedClusters(flowID=1, "redis")`
- 断言: redis-prod-a不通过(有FAIL记录); redis-prod-b通过(全部PASS); 仅返回redis-prod-b

### TestDeployService_RetryDeploy_TaskIDNotEmpty (C74路径1)
- 前置: deploy_record.status=FAILED, TaskID="task-123"非空
- 输入: `RetryDeploy(deployID)`
- 断言: 调用DeployClient.RetryDeploy("task-123")(从失败点继续); Status重置PENDING; RetryCount+1; 启动轮询goroutine

### TestDeployService_RetryDeploy_TaskIDEmpty (C74路径2)
- 前置: deploy_record.status=FAILED, TaskID为空
- 输入: `RetryDeploy(deployID)`
- 断言: 删除旧DeployRecord; 重新调用TriggerDeploy从头触发(创建新记录); 新记录有新TaskID

### TestDeployService_RetryDeploy_StatusNotFailed (C74补充)
- 前置: deploy_record.status=DONE
- 输入: `RetryDeploy(deployID)`
- 断言: 返回ErrParamInvalid("仅FAILED状态可重试")

#### P1 级别

### TestMonitorService_VOFields (C77)
- 前置: MonitorDeploy记录有DeployTaskID="m-task-1", ConfigTaskID="c-task-1"
- 输入(场景1): `GetDeployStatus(flowID)`
- 断言: 返回MonitorDeployVO包含FlowID,IPs,DeployStatus,DeployTaskID,DeployLogPath,StartTime,EndTime字段
- 输入(场景2): `GetConfigStatus(flowID)`
- 断言: 返回MonitorConfigVO包含FlowID,ConfigStatus,ConfigTaskID,ConfigLogPath,ConfigDetail字段; ConfigDetail从MinIO读取配置日志解析

### Phase 7 补充: 演练

#### P0 级别

### TestDrillService_RetryDrill_DeleteAndRerun (C75)
- 前置: drill_record.status=FAILED, sceneID=5, DrillScene.Steps有2步骤
- 输入: `RetryDrill(drillID=1)`
- 断言: 旧DrillRecord被物理删除(db.Delete); 新DrillRecord创建; 仅重试sceneID=5的单场景; 使用当前DrillScene.Steps(不使用旧版本)

### TestDrillService_RetryDrill_DisabledScene (C75补充)
- 前置: drill_scene.status=DISABLE
- 输入: `RetryDrill(drillID对应DISABLE场景)`
- 断言: 返回ErrParamInvalid("演练场景已禁用")

### TestDrillService_ExecuteDrill_StepFailNotInterrupt (补充)
- 前置: 1个场景含3步骤; 第2步骤mock失败
- 输入: `ExecuteDrill(flowID=1, "redis-prod-a", sceneIDs=[5])`
- 断言: 第2步骤FAIL但第3步骤仍执行(不中断); 场景overall_result=FAIL(有步骤失败); DB中drill_record.Result包含全部3步骤结果

### TestDrillService_GetDeployedClusters_DrillStatusSummary (C23补充)
- 前置: 5集群中2个deploy_record.status=DONE; 1个已完成演练, 1个部分完成, 3个未演练
- 输入: `GetDeployedClusters(flowID=1, "redis")`
- 断言: 返回2个DONE集群; 各集群携带drill_status(NONE/PARTIAL/ALL_DONE/FAILED)
