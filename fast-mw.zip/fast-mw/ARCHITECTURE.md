# Architecture

## 包依赖图（DAG）

```
cmd/server/main.go
  ├── internal/config/center.go
  │     ├── internal/database/mysql.go → gorm
  │     ├── sync.Map (内存缓存, key={group}:{key}→*ConfigEntry)
  │     └── crypto/aes (AES-256解密IsSensitive配置)
  ├── internal/database/mysql.go → gorm
  ├── internal/cache/local.go → go-cache
  ├── internal/lock/distributed.go → gorm (MySQL行锁)
  ├── pkg/minio/client.go → minio-go
  ├── pkg/response/response.go
  ├── pkg/errcode/errcode.go
  ├── internal/middleware/
  │     ├── auth.go → golang-jwt
  │     ├── audit.go → gorm
  │     ├── ratelimit.go (内存令牌桶)
  ├── internal/adapter/
  │     ├── cmdb/client.go → net/http
  │     ├── deploy/client.go → net/http
  │     ├── monitor/client.go → net/http
  │     ├── ops/client.go → net/http + golang.org/x/crypto/ssh
  ├── internal/admin/
  │     ├── check_rule.go → gorm
  │     ├── drill_scene.go → gorm
  │     ├── deploy_config.go → gorm → regexp
  ├── internal/flow/engine.go → gorm
  │     └── internal/flow/ws.go → gorilla/websocket
  ├── internal/resource/service.go
  │     ├── internal/adapter/cmdb
  │     ├── internal/config/center.go (GetRealValue获取ownerGroup/opsGroup)
  │     └── gorm
  ├── internal/check/service.go
  │     ├── internal/admin/check_rule.go (MatchRules)
  │     ├── internal/adapter/cmdb (交付状态)
  │     ├── ants (协程池)
  │     └── pkg/minio (日志存储)
  ├── internal/deploy/service.go
  │     ├── internal/admin/deploy_config.go (匹配参数)
  │     ├── internal/adapter/deploy
  │     └── gorm
  ├── internal/monitor/service.go
  │     ├── internal/adapter/monitor
  │     ├── pkg/minio
  │     └── gorm
  ├── internal/drill/service.go
  │     ├── internal/admin/drill_scene.go (MatchScenes)
  │     ├── internal/adapter/ops
  │     ├── ants (协程池)
  │     └── pkg/minio
  └── api/v1/
        ├── flow.go → internal/flow
        ├── resource.go → internal/resource
        ├── check.go → internal/check
        ├── monitor.go → internal/monitor
        ├── deploy.go → internal/deploy
        ├── drill.go → internal/drill
        └── admin.go → internal/admin
```

## 模块边界清单

| 模块 | 暴露接口 | 依赖内部模块 | 不依赖 |
|------|---------|-------------|--------|
| config | `Config`, `ConfigCenter`(Init/Get/GetRealValue/Set/StartHotReload) | database | adapter, business modules |
| database | `InitDB`, `AutoMigrate` | gorm | everything else |
| cache | `LocalCache` | go-cache | database, adapter |
| lock | `DistributedLock` | database | everything else |
| adapter/cmdb | `CMDBClient` | net/http, config | business modules |
| adapter/deploy | `DeployClient` | net/http, config | business modules |
| adapter/monitor | `MonitorClient` | net/http, config | business modules |
| adapter/ops | `OpsClient` | net/http, ssh, config, **config.ConfigCenter**(GetRealValue获取SSH凭据) | business modules |
| admin/check_rule | `CheckRuleService` | model | check, drill, deploy |
| admin/drill_scene | `DrillSceneService` | model | check, drill, deploy |
| admin/deploy_config | `DeployConfigService` | model, regexp | check, drill |
| flow | `FlowEngine`, `FlowWebSocket` | model, lock | resource, check, deploy, monitor, drill |
| resource | `ResourceService` | model, adapter/cmdb, **config.ConfigCenter**(GetRealValue获取ownerGroup/opsGroup) | check, deploy, drill |
| check | `CheckService` | model, admin/check_rule, adapter/cmdb, minio, ants | deploy, drill, monitor |
| deploy | `DeployService` | model, adapter/deploy, admin/deploy_config, **sync.Map(activeTasks)**, **flow(FailPhase)** | check, drill, monitor |
| monitor | `MonitorService` | model, adapter/monitor, minio, **sync.Map(activeTasks)**, **flow(FailPhase)** | check, deploy, drill |
| drill | `DrillService` | model, admin/drill_scene, adapter/ops, minio, ants | check, deploy, monitor |
| api/v1 | HTTP handlers | flow, resource, check, deploy, monitor, drill, admin | none (only calls services) |

**关键边界规则**：
- adapter 只被对应的业务模块调用，不调用业务模块
- admin 只被业务模块调用（check→check_rule, drill→drill_scene, deploy→deploy_config），admin不调用业务模块
- 业务模块之间不互相调用（check不调deploy，deploy不调drill）
- flow 只管理流程状态流转，不直接调用业务逻辑

## 数据流

### 创建交付流程
```
用户 POST /api/v1/flows {idc_name}
  → api/v1/flow.go → FlowEngine.CreateFlow
    → DB: INSERT delivery_flow + 5 flow_phase
  → Response: {flow_id, phases}
```

### 资源申请完整链路
```
用户 POST /api/v1/flows/:id/resource/init {ref_idc}
  → ResourceService.InitApply
    → ConfigCenter.GetRealValue("default_owner_group","resource") + GetRealValue("default_ops_group","resource")
    → CMDBClient.QueryResources(idc=ref_idc, ownerGroup, opsGroup)
    → 按ClusterName分组 → 生成ResourceApplyItem[]
    → DB: INSERT resource_apply + resource_apply_items
  → Response: items列表

用户修改/删除/新增items → PUT/DELETE/POST 对应接口

用户 POST /api/v1/flows/:id/resource/submit
  → ResourceService.ConfirmAndSubmit
    → 遍历items → CMDBClient.SubmitResource(逐集群)
    → DB: UPDATE resource_apply.status=SUBMITTED
    → FlowEngine.CompletePhase(flowID, RESOURCE_APPLY)
    → WebSocket: PushStatus(flowID)
  → Response: {success}
```

### 核查执行链路
```
用户 GET /api/v1/flows/:id/check/deliver-status
  → CheckService.QueryDeliverStatus
    → CMDBClient.QueryDeliveredResources(idc)
    → 与ResourceApplyItem对比节点数量
  → Response: [{cluster, deliver_status, expected_count, actual_count}]

用户 POST /api/v1/flows/:id/check/execute?cluster=xxx
  → CheckService.ExecuteCheck
    → CheckRuleService.MatchRules(clusterName, mwType)
      → 查COMMON规则 + MW_TYPE规则 + regexp(CLUSTER规则)
    → 串行执行三层规则:
      COMMON规则 → MW_TYPE规则 → CLUSTER规则
    → 每条规则:
      API类型 → HTTP调用 → JudgeRule判定
      SCRIPT类型 → SSH执行 → JudgeRule判定
    → DB: INSERT check_record (每条)
    → MinIO: Upload日志文件
  → WebSocket: PushStatus
  → Response: check_records[]
```

### 部署执行链路
```
用户 POST /api/v1/flows/:id/deploy/trigger?cluster=xxx
  → DeployService.TriggerDeploy
    → DeployConfigService.MatchConfig(clusterName) → 获取部署参数
    → DeployClient.TriggerDeploy(cluster, ips, params) → 获取taskID
    → DB: INSERT deploy_record
    → 后台协程轮询 DeployClient.GetDeployStatus(taskID)
      → 更新 deploy_record.status + deploy_stage_log
      → 日志写MinIO
    → WebSocket: PushStatus

    后台goroutine生命周期管理:
      go func() {
          defer panic recovery (更新Status=FAILED, 日志, WebSocket)
          defer cleanup activeTasks
          ctx, cancel := context.WithCancel(context.Background())
          activeTasks.Store(flowID-clusterName, cancel)
          for poll { check ctx.Done(); poll status; update DB; push WebSocket }
      }()
    
    重启恢复:
      main启动 → 查询未完成DeployRecord → 重新启动轮询goroutine
```

### 监控部署执行链路
```
用户 POST /api/v1/flows/:id/monitor/deploy {ips}
  → MonitorService.TriggerDeploy
    → MonitorClient.TriggerDeploy(ips) → 获取deployTaskID
    → DB: UPDATE monitor_deploy (DeployStatus=PENDING, DeployTaskID)
    → 后台goroutine轮询 (180次/10秒/30分钟)
      → 更新 DeployStatus + DeployLogPath
    → WebSocket: PushStatus

用户 POST /api/v1/flows/:id/monitor/config {clusters}
  → MonitorService.TriggerConfig (前提: DeployStatus=DONE)
    → MonitorClient.TriggerConfig(clusters) → 获取configTaskID
    → DB: UPDATE monitor_deploy (ConfigStatus=PENDING, ConfigTaskID)
    → 后台goroutine轮询 (180次/10秒/30分钟)
      → 更新 ConfigStatus + ConfigLogPath
    → WebSocket: PushStatus

    两个独立goroutine: Deploy轮询 + Config轮询
    各自独立context, 各自activeTasks记录
    重启恢复: 查询MonitorDeploy未完成状态, 恢复对应轮询
```

### 演练执行链路
```
用户 POST /api/v1/flows/:id/drill/execute?cluster=xxx {scene_ids: []}
  → DrillService.ExecuteDrill
    → 若scene_ids空 → DrillSceneService.MatchScenes(clusterName, mwType)
      → COMMON场景 + MW_TYPE场景 + regexp(CLUSTER场景)
    → 遍历每个场景的Steps:
      SHELL → OpsClient.ExecuteScript
      ANSIBLE → OpsClient.ExecuteScript
      API → OpsClient.CallAPI
    → DB: INSERT drill_record
    → MinIO: Upload日志
    → WebSocket: PushStatus
```

### 三层规则匹配核心逻辑
```
MatchRules(clusterName="redis-cluster-prod-a", mwType="redis"):
  1. 查 DB: scope=COMMON, status=ENABLE → 返回公共核查规则 (所有集群都执行)
  2. 查 DB: scope=MW_TYPE, mw_type="redis", status=ENABLE → 返回Redis类型核查规则
  3. 查 DB: scope=CLUSTER, status=ENABLE → 遍历每条, regexp.MatchString(clusterRegex, "redis-cluster-prod-a") → 命中返回
  
  合并结果, 按 scope(COMMON→MW_TYPE→CLUSTER) + sort 排序
  执行时严格按此顺序串行
```

## 关键设计决策表

| 决策            | 选择                                        | 理由                 | 否决方案          |
| ------------- | ----------------------------------------- | ------------------ | ------------- |
| 配置中心          | MySQL+sync.Map+5秒轮询                       | 无外部中间件依赖, 极简部署     | Nacos/Redis   |
| 分布式锁          | MySQL唯一索引+行锁                              | 已有MySQL, 不引入Redis  | Redis SETNX   |
| 缓存            | go-cache进程内缓存                             | 无外部依赖, 单机足够        | Redis缓存       |
| 并发控制          | ants协程池                                   | Go原生, 可控并发数        | goroutine无限制  |
| 状态推送          | WebSocket                                 | 实时性≤5秒, 无轮询开销      | SSE/前端轮询      |
| 流程流转          | 用户手动触发                                    | 需求明确: 不自动流转        | 自动FSM推进       |
| 核查/演练匹配       | 三层规则(Common+MWType+ClusterRegexp)         | 核心业务模式, 灵活覆盖所有场景   | 单层规则/硬编码      |
| 部署日志          | MinIO文件+MySQL路径引用                         | 大日志不适合存DB, 分页读取高效  | MySQL存储全文     |
| ORM           | GORM                                      | Go生态主流, 功能完备       | sqlx/raw SQL  |
| 前端            | Vue3+ElementPlus                          | 需求明确, 企业级组件库       | React/Angular |
| goroutine生命周期 | context.WithCancel + activeTasks sync.Map | 可追踪可取消, 优雅退出       | 裸goroutine无追踪 |
| panic恢复       | 每个goroutine defer recover                 | 防止单任务panic导致整个服务崩溃 | 不恢复直接崩溃       |
| 重启恢复          | 启动时查询DB未完成任务恢复轮询                          | 进程重启不丢失进行中任务       | 不恢复, 用户手动重试   |
| SSH凭据来源       | ConfigCenter动态读取                          | 支持运行时更换密钥, 不硬编码    | 配置文件硬编码/环境变量  |
