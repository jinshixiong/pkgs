# AGENTS.md

> 本文件是 LLM 编程助手的实时导航。意图文档（蓝图）描述"要做什么"，代码是"做了什么"，本文件记录两者之间的偏差和当前状态。

## 项目概况

一站式中间件交付平台：将新机房建设中的资源申请、资源核查、监控部署、服务部署、自动演练五个环节串联为用户手动触发的自动化流水线。

- 语言: Go (后端) + Vue3 (前端)
- 框架: Gin + GORM + ElementPlus
- 存储: MySQL + MinIO + go-cache(进程内)
- 无 Redis/Nacos/Elasticsearch 等外部中间件依赖

## 蓝图文件体系

| 文件 | 角色 | 维护策略 |
|------|------|---------|
| PRODUCT_REQUIREMENTS.md | 意图层 — 需求源头 | 需求变更时必须更新 |
| CONSTRAINTS.md | 约束层 — 精确代码指引 | 约束变更时必须更新 |
| ARCHITECTURE.md | 结构层 — 模块依赖与数据流 | 新增/删除/重构模块时更新 |
| IMPLEMENTATION_PLAN.md | 执行层 — 分步实现蓝图 | 代码完成后降级为历史参考，不再强同步 |
| FRONTEND_SPEC.md | 执行层 — 前端实现蓝图 | 前端代码完成后降级为历史参考 |
| TEST_SPECS.md | 验证层 — 测试规格 | 新增/删除功能时同步更新 |
| AGENTS.md | 导航层 — 偏差与状态 | 每次开发变更后更新 |

## 当前项目状态

- 状态: **未开始正式实现**
- STUBS 目录下有骨架代码（函数签名+panic("not implemented")），尚未开始填充真实逻辑
- 所有蓝图文件（Phase 1-8）均未执行，蓝图与代码当前无偏差

### 已完成的骨架结构

- `STUBS/cmd/server/main.go` — 入口，初始化配置→DB→路由→启动
- `STUBS/internal/config/` — Config 结构体 + ConfigCenter 签名
- `STUBS/internal/database/` — InitDB + AutoMigrate 签名
- `STUBS/internal/cache/` — LocalCache 签名
- `STUBS/internal/lock/` — DistributedLock 签名
- `STUBS/internal/middleware/` — JWTAuth + AuditLog + RateLimit 签名
- `STUBS/internal/model/` — 全部 GORM 模型结构体已定义
- `STUBS/internal/common/enum.go` — 中间件类型 + Scope + Phase + Status 常量
- `STUBS/internal/admin/` — CheckRuleService + DrillSceneService + DeployConfigService 签名
- `STUBS/internal/flow/` — FlowEngine + FlowWebSocket 签名
- `STUBS/internal/resource/` — ResourceService 签名
- `STUBS/internal/check/` — CheckService 签名
- `STUBS/internal/deploy/` — DeployService 签名
- `STUBS/internal/monitor/` — MonitorService 签名
- `STUBS/internal/drill/` — DrillService 签名
- `STUBS/internal/adapter/` — CMDB + Deploy + Monitor + Ops 四个适配器签名
- `STUBS/pkg/` — response + errcode + minio 签名
- `STUBS/api/v1/` — 全部路由注册 + handler 签名

### 待实现的 Phase

按 IMPLEMENTATION_PLAN.md 顺序：
- Phase 1: 项目骨架与基础层（Step 1.1-1.5）
- Phase 2: 数据模型定义（Step 2.1-2.2）
- Phase 3: 管理配置模块（Step 3.1-3.3）
- Phase 4: 交付流程引擎（Step 4.1-4.2）
- Phase 5: 资源申请与核查（Step 5.1-5.3）
- Phase 6: 部署与监控（Step 6.1-6.4）
- Phase 7: 演练与推送（Step 7.1-7.2）
- Phase 8: 前端（Step 8.1-8.4）

## Code Map

> 需求→代码的索引表。每个功能点记录：用户能做什么 → API 入口 → Service 核心方法 → 关键依赖 → 数据模型。
> Phase 完成后由 Walkthrough session 填充，日常维护时随代码变更同步更新。

### 基础层（Phase 1-2）

| 功能 | API 入口 | Service/核心方法 | 关键依赖 | 数据模型 |
|------|---------|-----------------|---------|---------|
| 加载配置 | — | config.Load → ConfigCenter.Init | config.yaml → sync.Map({group}:{key}→ConfigEntry) | SysConfig |
| 配置热更新 | — | ConfigCenter.StartHotReload | DB轮询MAX(version)+比对Map+增量拉取+清理DISABLE项 | SysConfig.Version |
| 获取配置值(脱敏) | — | ConfigCenter.Get(key,group) | sync.Map→IsSensitive返回"****"/非敏感返回明文 | SysConfig(Sensitive) |
| 获取配置真实值(内部) | — | ConfigCenter.GetRealValue(key,group) | sync.Map→返回解密后明文(不论IsSensitive) | SysConfig(Sensitive) |
| 设置配置值(含加密) | — | ConfigCenter.Set(key,group,value,operator) | AES-256加密+DB写入+History+Map刷新(存明文) | SysConfig(Sensitive)+SysConfigHistory |
| DB连接初始化 | — | database.InitDB | gorm+MySQL | — |
| 表自动迁移 | — | database.AutoMigrate | gorm AutoMigrate | 全部Model |
| 进程内缓存读写 | — | LocalCache.Get/Set/Delete | go-cache | — |
| 分布式锁获取/释放 | — | DistributedLock.Acquire/Release | MySQL primaryKey INSERT+过期覆盖+owner验证 | DistributedLock |
| 锁过期清理 | — | DistributedLock.StartCleanup | 每10秒DELETE过期 | DistributedLock.ExpireTime |
| JWT认证 | middleware | JWTAuth() | golang-jwt解析校验+c.Set("user_id","user_role") | — |
| 审计日志记录 | middleware | AuditLog() | 拦截请求→读Body+恢复Body→c.Next()→写audit_log(按月分表) | AuditLog(按月分表audit_log_{YYYYMM}) |
| 令牌桶限流 | middleware | RateLimit() | x/time/rate | — |
| MinIO文件上传 | — | MinioClient.Upload | minio-go | — |
| MinIO签名链接 | — | MinioClient.GetSignedURL | minio-go PresignedGetObject | — |
| MinIO日志分页读取 | — | MinioClient.ReadLines | GetObject+io.ReadAll+Split("\n")+TrimRight("\r")+截取[startLine:endLine] | — |
| 统一响应格式 | — | response.Success/Fail | — | — |
| 错误码定义 | — | errcode常量块 | — | — |

### 管理配置（Phase 3）

| 功能 | API 入口 | Service/核心方法 | 关键依赖 | 数据模型 |
|------|---------|-----------------|---------|---------|
| 核查规则CRUD | GET/POST/PUT/DELETE /api/v1/check-rules (GET:?scope=xxx&mw_type=xxx) | CheckRuleService.Create/Update/Delete/List/Get | gorm CRUD | CheckRule |
| 核查规则三层匹配 | GET /api/v1/check-rules/match?cluster=xxx&mw_type=xxx | CheckRuleService.MatchRules | COMMON→MW_TYPE→CLUSTER+regexp | CheckRule.Scope+MWType+ClusterRegex |
| 演练场景CRUD | GET/POST/PUT/DELETE /api/v1/drill-scenes (GET:?scope=xxx&mw_type=xxx) | DrillSceneService.Create/Update/Delete/List/Get | gorm CRUD | DrillScene |
| 演练场景三层匹配 | GET /api/v1/drill-scenes/match?cluster=xxx&mw_type=xxx | DrillSceneService.MatchScenes | 同核查三层逻辑 | DrillScene.Scope+MWType+ClusterRegex |
| 部署配置CRUD | GET/POST/PUT/DELETE /api/v1/deploy-configs (GET:?mw_type=xxx) | DeployConfigService.Create/Update/Delete/List/Get | gorm CRUD | DeployConfig |
| 部署配置正则匹配 | — | DeployConfigService.MatchConfig | regexp.MatchString(NameRegex) | DeployConfig.NameRegex |

### 交付流程引擎（Phase 4）

| 功能 | API 入口 | Service/核心方法 | 关键依赖 | 数据模型 |
|------|---------|-----------------|---------|---------|
| 创建交付流程 | POST /api/v1/flows | FlowEngine.CreateFlow | 5个FlowPhase记录 | DeliveryFlow+FlowPhase |
| 查看流程状态 | GET /api/v1/flows/:id | FlowEngine.GetFlowStatus | 聚合flow+phase+集群明细(5环节各自聚合策略) | DeliveryFlow+FlowPhase+各业务Record |
| 触发环节(含依赖校验) | POST /api/v1/flows/:id/phases/:type/start | FlowEngine.StartPhase | CHECK需RESOURCE_APPLY=DONE; DEPLOY需CHECK=DONE; MONITOR/DEPLOY并行 | FlowPhase.Status |
| 完成环节 | POST /api/v1/flows/:id/phases/:type/complete | FlowEngine.CompletePhase | — | FlowPhase.Status=DONE |
| WebSocket状态推送 | ws://host/ws?flow_id=xxx | FlowWebSocket.PushStatus | gorilla/websocket Hub | — |

### 资源申请（Phase 5）

| 功能 | API 入口 | Service/核心方法 | 关键依赖 | 数据模型 |
|------|---------|-----------------|---------|---------|
| 初始化资源申请 | POST /api/v1/flows/:id/resource/init (body:{ref_idc}) | ResourceService.InitApply | CMDB.QueryResources→按ClusterName分组→合并节点→存DB(ConfigCenter取ownerGroup/opsGroup) | ResourceApply+ResourceApplyItem |
| 修改申请条目 | PUT /api/v1/resource/items/:id (body:UpdateApplyItemReq) | ResourceService.UpdateApplyItem | ResourceApply.Status=DRAFT校验+gorm | ResourceApplyItem(不可改IPs/DeliverStatus/FailReason) |
| 删除申请条目 | DELETE /api/v1/resource/items/:id | ResourceService.DeleteApplyItem | ResourceApply.Status=DRAFT校验+逻辑删除(Status=DISABLE) | ResourceApplyItem.Status |
| 新增申请条目 | POST /api/v1/flows/:id/resource/items (body:AddApplyItemReq) | ResourceService.AddApplyItem | ResourceApply.Status=DRAFT校验+唯一索引防重+字段校验 | ResourceApplyItem |
| 确认提交申请 | POST /api/v1/flows/:id/resource/submit | ResourceService.ConfirmAndSubmit | CMDB.SubmitResource逐集群提交 | ResourceApply.Status=SUBMITTED |
| 查询资源列表 | GET /api/v1/flows/:id/resource/items | — | gorm查询 | ResourceApplyItem |

### 资源核查（Phase 5）

| 功能 | API 入口 | Service/核心方法 | 关键依赖 | 数据模型 |
|------|---------|-----------------|---------|---------|
| 查询交付状态 | GET /api/v1/flows/:id/check/deliver-status | CheckService.QueryDeliverStatus | CMDB.QueryDeliveredResources→按集群构建查找索引→对比节点数→回填IPs+DeliverStatus | ResourceApplyItem.DeliverStatus+IPs |
| 执行集群核查 | POST /api/v1/flows/:id/check/execute?cluster=xxx | CheckService.ExecuteCheck | MatchRules→串行三层→API/SCRIPT分发→JudgeRule判定 | CheckRecord |
| 核查API类型执行 | — | (ExecuteCheck内部) | HTTP调用+JudgeRule判定 | — |
| 核查SCRIPT类型执行 | — | (ExecuteCheck内部) | SSH执行+60秒超时+JudgeRule判定 | — |
| 查看核查明细 | GET /api/v1/flows/:id/check/detail?cluster=xxx | CheckService.GetCheckDetail | gorm查询 | CheckRecord |
| 查看核查日志(分页) | GET /api/v1/check/records/:id/log?start=0&count=100 | CheckService.GetCheckLog | MinIO.ReadLines(100行/页) | CheckRecord.LogFilePath |

### 服务部署（Phase 6）

| 功能 | API 入口 | Service/核心方法 | 关键依赖 | 数据模型 |
|------|---------|-----------------|---------|---------|
| 查看可部署集群 | GET /api/v1/flows/:id/deploy/clusters?mw_type=xxx | DeployService.GetCheckedClusters | 聚合判定(所有CheckRecord.Result=PASS)+DeployConfig匹配参数 | CheckRecord+DeployConfig |
| 触发集群部署 | POST /api/v1/flows/:id/deploy/trigger?cluster=xxx | DeployService.TriggerDeploy | DeployConfig匹配→DeployClient.TriggerDeploy→后台轮询 | DeployRecord |
| 部署状态轮询 | — | (后台协程) | DeployClient.GetDeployStatus→更新DB | DeployRecord+DeployStageLog |
| 重试失败部署 | POST /api/v1/deploy/:id/retry | DeployService.RetryDeploy | TaskID非空→DeployClient.RetryDeploy; TaskID为空→重新TriggerDeploy | DeployRecord.RetryCount |
| 查看部署明细 | GET /api/v1/flows/:id/deploy/detail?cluster=xxx | DeployService.GetDeployDetail | DeployRecord+3条StageLog+MinIO签名链接 | DeployRecord+DeployStageLog |
| 查看部署日志(分页) | GET /api/v1/deploy/:id/log?stage=xxx&start=0&count=100 | DeployService.GetStageLog | MinIO.ReadLines(100行/页) | DeployStageLog.LogFilePath |

### 监控部署（Phase 6）

| 功能 | API 入口 | Service/核心方法 | 关键依赖 | 数据模型 |
|------|---------|-----------------|---------|---------|
| 触发监控部署 | POST /api/v1/flows/:id/monitor/deploy (body:{ips:[]}) | MonitorService.TriggerDeploy | MonitorClient.TriggerDeploy→后台轮询 | MonitorDeploy.DeployStatus |
| 触发监控配置 | POST /api/v1/flows/:id/monitor/config (body:{clusters:[]}) | MonitorService.TriggerConfig | MonitorClient.TriggerConfig→后台轮询 | MonitorDeploy.ConfigStatus |
| 查看监控状态 | GET /api/v1/flows/:id/monitor/status → MonitorStatusVO{deploy,config} | MonitorService.GetDeployStatus→MonitorDeployVO+GetConfigStatus→MonitorConfigVO | gorm查询+MinIO读取ConfigDetail | MonitorDeploy |
| 查看监控日志(分页) | GET /api/v1/flows/:id/monitor/log?start=0&count=100 | MonitorService.GetDeployLog | MinIO.ReadLines | MonitorDeploy.DeployLogPath |

### 演练（Phase 7）

| 功能 | API 入口 | Service/核心方法 | 关键依赖 | 数据模型 |
|------|---------|-----------------|---------|---------|
| 查看可演练集群 | GET /api/v1/flows/:id/drill/clusters?mw_type=xxx | DrillService.GetDeployedClusters | 查deploy_record.status=DONE+演练状态汇总(NONE/PARTIAL/ALL_DONE/FAILED) | DeployRecord+DrillRecord |
| 执行集群演练(全场景) | POST /api/v1/flows/:id/drill/execute?cluster=xxx (body:{} 或 {scene_ids:[]}) | DrillService.ExecuteDrill | MatchScenes→串行三层→SHELL/ANSIBLE/API分发 | DrillRecord |
| 执行指定场景演练 | POST /api/v1/flows/:id/drill/execute?cluster=xxx (body:{scene_ids:[1,3,5]}) | (sceneIDs非空时) | 按指定sceneIDs执行 | DrillRecord |
| SHELL/ANSIBLE步骤执行 | — | (ExecuteDrill内部) | OpsClient.ExecuteScript | — |
| API步骤执行 | — | (ExecuteDrill内部) | OpsClient.CallAPI | — |
| 重试失败演练 | POST /api/v1/drill/:id/retry | DrillService.RetryDrill | 物理删除旧DrillRecord+重新ExecuteDrill单场景 | DrillRecord |
| 查看演练明细 | GET /api/v1/flows/:id/drill/detail?cluster=xxx | DrillService.GetDrillDetail | gorm查询 | DrillRecord |
| 查看演练日志(分页) | GET /api/v1/drill/records/:id/log?start=0&count=100 | DrillService.GetDrillLog | MinIO.ReadLines | DrillRecord.LogFilePath |

### 前端（Phase 8）

| 功能 | 页面/组件 | 关键API调用 | 状态管理 |
|------|---------|------------|---------|
| 流程总览页 | FlowDetail.vue + 5×PhaseCard | GET /api/v1/flows/:id | flow.ts (Pinia) |
| WebSocket推送 | websocket.ts | ws://连接+断线重连(3秒间隔最多5次) | websocket.ts (Pinia) |
| 资源申请面板 | ResourceApplyPanel(内嵌于FlowDetail) | init/submit/items CRUD | flow.ts |
| 核查面板 | CheckViewPanel(内嵌于FlowDetail) | deliver-status/execute/detail/log | flow.ts |
| 监控面板 | MonitorViewPanel(内嵌于FlowDetail) | deploy/config/status/log | flow.ts |
| 部署面板 | DeployViewPanel(内嵌于FlowDetail) + DeployProgress(三阶段进度条) | clusters/trigger/detail/log | flow.ts |
| 演练面板 | DrillViewPanel(内嵌于FlowDetail) + DrillProgress(场景结果卡片) | clusters/execute/detail/log | flow.ts |
| 日志分页查看 | LogViewer.vue | 各模块log接口(100行/页) | — |
| JudgeRule动态表单 | JudgeRuleForm.vue | — | — |
| Steps编辑器 | StepsEditor.vue | — | — |
| 管理配置页 | Admin.vue(3Tab: 核查规则/演练场景/部署配置) | check-rules/drill-scenes/deploy-configs CRUD | — |

### 外部服务适配器

| 适配器 | 文件 | 调用方式 | 被谁调用 |
|-------|------|---------|---------|
| CMDB | internal/adapter/cmdb/client.go | HTTP GET/POST, 30秒超时+3次重试间隔5秒 | ResourceService, CheckService |
| 中间件部署 | internal/adapter/deploy/client.go | HTTP POST(不重试)+GET, 30秒超时+状态码映射 | DeployService |
| 集群监控 | internal/adapter/monitor/client.go | HTTP POST(不重试)+GET, 30秒超时+TriggerDeploy/TriggerConfig对称模式 | MonitorService |
| 基础运维 | internal/adapter/ops/client.go | HTTP+SSH, 脚本60秒超时+CallAPI不重试 | CheckService(SCRIPT), DrillService |

## Walkthrough 记录

> 每个 Phase 完成后，进行一次 Walkthrough session，将结果整理在此。
> 执行 walkthrough的核心思路：
1. 列出本 Phase 实现了哪些功能
2. 每个功能的关键代码路径是什么（文件:行号）
3. 有哪些非显而易见的边界情况被处理了
4. 有哪些设计选择以及为什么这样选
5. 如果我要改 XX 功能，我应该改哪个文件的哪个函数"
执行完成后，把这个 walkthrough 的结果整理进 AGENTS.md 的 Code Map 和偏差记录。
> 格式: Phase编号 | 完成日期 | 核心发现 | 非显而易见的边界情况 | 关键设计选择及原因

（暂无记录，待 Phase 1 完成后填充）

## 蓝图偏差记录

> 格式: `位置 | 蓝图描述 | 实际实现 | 原因`

| 位置                                                | 蓝图描述                                     | 实际实现                                                                                                       | 原因                                    |
| ------------------------------------------------- | ---------------------------------------- | ---------------------------------------------------------------------------------------------------------- | ------------------------------------- |
| CONSTRAINTS.md                                    | 原有33条约束                                  | 新增9条约束(goroutine生命周期、panic恢复、事务边界、并发保护、SSH凭据、重启恢复、DeployStageLog.Status、MonitorDeploy.TaskID、FailReason字段) | 补充弱模型实现所需的关键细节(HIGH+MEDIUM风险)         |
| CONSTRAINTS.md                                    | 原有42条约束                                  | 新增12条约束(ConfigCenter.Get脱敏+GetRealValue+sync.Map存储结构+热更新清理DISABLE+锁Acquire过期覆盖+锁Release验证owner+AuditLog operator从JWT取+AuditLog.TableName动态分表+MinIO ReadLines全量下载按行分割+InitApply按集群合并+ownerGroup/opsGroup从配置取+QueryDeliverStatus回填IPs+CRUD字段校验) | 补充弱模型实现所需的关键细节(HIGH+MEDIUM风险)         |
| IMPLEMENTATION_PLAN.md Step 1.2                   | 原有错误码1XXX-25XX                           | 新增ErrSSHAuthFailed(1004)+ErrConcurrentTrigger(1005)                                                        | SSH认证失败和并发触发拒绝需要独立错误码                 |
| IMPLEMENTATION_PLAN.md Step 2.1 FlowPhase         | 原有6个字段                                   | 新增IsParallel bool+FailReason string                                                                        | 标记MONITOR/DEPLOY并行+记录环节失败原因           |
| IMPLEMENTATION_PLAN.md Step 2.1 ResourceApply     | Status枚举DRAFT/SUBMITTED/APPROVED         | 改为DRAFT/SUBMITTED/PARTIAL_SUBMITTED/SUBMIT_FAILED                                                          | 部分提交成功需要独立状态                          |
| IMPLEMENTATION_PLAN.md Step 2.1 ResourceApplyItem | 原有14个字段                                  | 新增FailReason string                                                                                        | CMDB提交失败需记录具体原因                       |
| IMPLEMENTATION_PLAN.md Step 2.1 CheckRecord       | 原有9个字段                                   | 新增FailReason string                                                                                        | 核查失败需记录具体原因                           |
| IMPLEMENTATION_PLAN.md Step 2.1 DeployRecord      | 原有9个字段                                   | 新增TaskID string                                                                                            | 轮询需要存储部署服务返回的taskID                   |
| IMPLEMENTATION_PLAN.md Step 2.1 DeployStageLog    | 原有5个字段                                   | 新增Status string                                                                                            | 每阶段需独立状态(PENDING/RUNNING/DONE/FAILED) |
| IMPLEMENTATION_PLAN.md Step 2.1 MonitorDeploy     | 原有7个字段                                   | 新增DeployTaskID+ConfigTaskID+ConfigLogPath                                                                  | 轮询需要存储taskID，配置日志需要独立MinIO路径          |
| IMPLEMENTATION_PLAN.md Step 4.1                   | CompletePhase/FailPhase无详细逻辑             | 新增完整伪代码(含db.Transaction事务包裹)                                                                               | 多表写入必须原子性，弱模型不知道需事务                   |
| IMPLEMENTATION_PLAN.md Step 5.2                   | ConfirmAndSubmit提交失败只说"记录失败原因"           | 明确item.FailReason=err.Error()赋值                                                                            | 弱模型不知道存到哪个字段                          |
| IMPLEMENTATION_PLAN.md Step 5.3                   | SSH凭据来源未指定                               | 新增前置条件:从ConfigCenter.Get读取ssh_user/ssh_private_key                                                         | 弱模型不知道SSH连接凭据从哪来                      |
| IMPLEMENTATION_PLAN.md Step 5.3                   | JudgeRule 4种mode仅文字描述                    | 新增JudgeRule JSON Schema(含mode/expected/field_path/min/max)                                                 | 弱模型不知道每种mode需要哪些JSON字段                |
| IMPLEMENTATION_PLAN.md Step 5.3                   | SCRIPT类型执行流程模糊                           | 新增逐节点SSH执行+单节点判定+全部汇总的完整伪代码                                                                                | 弱模型不知道多节点如何判定和汇总                      |
| IMPLEMENTATION_PLAN.md Step 6.2                   | 后台goroutine无生命周期管理                       | 新增context.WithCancel+activeTasks+panic recovery+ctx.Done()检查                                               | goroutine必须可追踪可取消可恢复                  |
| IMPLEMENTATION_PLAN.md Step 6.2                   | 无重启恢复机制                                  | 新增TriggerDeploy重启恢复逻辑(启动时扫描未完成记录)                                                                          | 进程重启后未完成任务不可丢失                        |
| IMPLEMENTATION_PLAN.md Step 6.2                   | DeployService无activeTasks字段              | 新增activeTasks sync.Map                                                                                     | 存储cancel函数用于优雅退出                      |
| IMPLEMENTATION_PLAN.md Step 6.4                   | MonitorService无activeTasks字段             | 新增activeTasks sync.Map                                                                                     | 两个独立goroutine各自追踪                     |
| IMPLEMENTATION_PLAN.md Step 6.4                   | Monitor两个goroutine无生命周期管理                | 新增同Step6.2的完整管理(context+panic+activeTasks)                                                                 | 同部署模块需求                               |
| IMPLEMENTATION_PLAN.md Step 6.4                   | 无重启恢复                                    | 新增MonitorService重启恢复逻辑(查询deploy_status/config_status未完成)                                                   | 同部署模块需求                               |
| IMPLEMENTATION_PLAN.md Step 6.4                   | DeployStatus/ConfigStatus枚举不完整           | 新增完整枚举(PENDING/RUNNING/DONE/FAILED)+独立管理说明                                                                 | 弱模型不知道两个状态独立管理                        |
| IMPLEMENTATION_PLAN.md Step 7.1                   | OpsClient无ConfigCenter依赖                 | 新增configCenter *ConfigCenter依赖                                                                             | SSH凭据从ConfigCenter动态读取                |
| IMPLEMENTATION_PLAN.md Step 7.2                   | Steps JSON和target字段未定义格式                 | 新增Steps JSON Schema+target字段规则(空/单IP/逗号分隔多IP)                                                              | 弱模型不知道target的格式和含义                    |
| IMPLEMENTATION_PLAN.md Step 7.2                   | SHELL/ANSIBLE/API步骤执行流程模糊                | 新增三种步骤的完整展开伪代码(含SSH连接、超时、单节点判定、汇总)                                                                         | 弱模型不知道每种步骤如何执行和判定                     |
| IMPLEMENTATION_PLAN.md Step 7.2                   | DrillRecord.Result JSON格式未定义             | 新增完整JSON Schema(含steps数组+nodes/api_result+overall_result)                                                  | 弱模型不知道结果JSON的结构                       |
| IMPLEMENTATION_PLAN.md Step 7.2                   | 汇总规则不完整                                  | 新增场景独立判定+互不影响+前端展示顺序                                                                                       | 弱模型不知道场景间如何汇总                         |
| ARCHITECTURE.md                                   | OpsClient无ConfigCenter依赖                 | adapter/ops新增依赖config.ConfigCenter                                                                         | SSH凭据动态读取                             |
| ARCHITECTURE.md                                   | DeployService/MonitorService无activeTasks | 模块边界表新增sync.Map(activeTasks)和flow(FailPhase)依赖                                                             | goroutine生命周期管理需要                     |
| ARCHITECTURE.md                                   | 部署数据流无goroutine生命周期                      | 新增goroutine生命周期流程图+重启恢复                                                                                    | 文档完整性                                 |
| ARCHITECTURE.md                                   | 无监控部署数据流图                                | 新增MonitorService完整数据流(Deploy+Config两条独立链路)                                                                 | 文档完整性                                 |
| ARCHITECTURE.md                                   | 设计决策表缺少goroutine相关                       | 新增4行(goroutine生命周期、panic恢复、重启恢复、SSH凭据来源)                                                                   | 设计决策需记录                               |
| IMPLEMENTATION_PLAN.md Step 1.3                   | ConfigCenter仅有函数签名无详细逻辑                 | 新增Init/Get/GetRealValue/Set/StartHotReload完整伪代码(含sync.Map key结构、加密解密流程、热更新增量拉取+清理DISABLE)                                        | 弱模型不知道Map存加密还是明文、Get是脱敏还是解密、热更新如何增量拉取      |
| IMPLEMENTATION_PLAN.md Step 1.3                   | ConfigCenter无GetRealValue方法              | 新增GetRealValue(key,group)方法返回真实解密值(不论IsSensitive)                                                                 | OpsClient获取SSH凭据需要真实值，Get()只返回****          |
| IMPLEMENTATION_PLAN.md Step 1.4                   | DistributedLock仅有函数签名无详细逻辑               | 新增Acquire(过期覆盖+owner验证)/Release(owner匹配)/StartCleanup(ctx.Done())完整伪代码                                                                 | 弱模型不知道锁key已存在时如何处理、owner生成规则、释放时owner验证      |
| IMPLEMENTATION_PLAN.md Step 1.5                   | AuditLog仅有函数签名无详细逻辑                 | 新增完整伪代码(含operator从JWT context取+Body读取恢复+参数2000字符截断+按月分表TableName()动态逻辑)                                                                                                       | 弱模型不知道operator从哪取、Body读后必须恢复、TableName动态分表    |
| IMPLEMENTATION_PLAN.md Step 1.5                   | MinioClient.ReadLines仅有签名              | 新增完整算法(GetObject+io.ReadAll+Split+TrimRight("\r")+移除末尾空行+越界检查+截取)                                                                  | 弱模型不知道MinIO不支持按行读取、需全量下载后按行分割、需处理\r        |
| IMPLEMENTATION_PLAN.md Step 1.1                   | 原有main.go仅有入口，无初始化接线                   | 新增main.go初始化接线详细逻辑流程(含依赖注入顺序+优雅退出步骤+依赖链路图)                                                                                                       | 弱模型不知道组件如何连接、依赖注入顺序、优雅退出步骤                              |
| IMPLEMENTATION_PLAN.md Step 1.2                   | 原有handler仅路由注册                   | 新增API handler统一模式示例(含reqID生成+参数解析+Service调用+Success/Fail响应+路径参数vs Query参数规则)                                                     | 弱模型不知道所有handler遵循同一模式、参数解析方式                          |
| IMPLEMENTATION_PLAN.md Step 1.5                   | JWTAuth仅有函数签名                   | 新增JWTAuth详细逻辑流程(含Authorization头解析+Bearer token提取+CustomClaims结构+JWT_SECRET_KEY+context注入+错误返回)                                                                 | 弱模型不知道claims结构、context key命名、JWT密钥来源                    |
| IMPLEMENTATION_PLAN.md Step 1.5                   | RateLimit仅有函数签名                   | 新增RateLimit详细逻辑流程(含令牌桶创建+非阻塞Allow()+burst=rps+429返回+WebSocket路由不使用)                                                                 | 弱模型可能误用阻塞Wait()、不知道burst参数含义                            |
| IMPLEMENTATION_PLAN.md Step 4.2                   | WebSocket仅有函数签名                   | 新增WebSocket Hub详细逻辑流程(含WSHub结构体+register/unregister/broadcast通道+HandleConnection连接升级+PushStatus消息推送+断线处理)                                                                 | 弱模型不知道Hub模式、连接升级流程、消息广播机制                              |
| IMPLEMENTATION_PLAN.md Step 7.1                   | OpsClient仅有函数签名                   | 新增OpsClient.ExecuteScript SSH连接详细逻辑流程(含ConfigCenter动态读取凭据+ssh.ClientConfig+连接建立+session+60秒超时+结果返回)                                                                 | 弱模型不知道SSH凭据从ConfigCenter读取、连接超时设置、ansible执行方式            |
| CONSTRAINTS.md                                    | 原有54条约束                          | 新增10条约束(JWTAuth token解析+context注入+JWT_SECRET_KEY环境变量+RateLimit非阻塞+WebSocket单流程订阅+非阻塞推送+main.go依赖注入顺序+优雅退出顺序+API handler统一模式+OpsClient每次SSH重新读取凭据+SSH连接/脚本超时+HostKeyCallback) | 补充基础设施组件的精确约束(防止弱模型用通用方案替代系统特定约定)               |
| IMPLEMENTATION_PLAN.md Step 5.2                   | InitApply仅有单行注释描述                        | 新增完整伪代码(含校验已存在→报错+CMDB按ClusterName分组+合并多节点IP+字段映射+Env默认prod+ownerGroup/opsGroup从ConfigCenter取)                                               | 弱模型不知道CMDB每条记录=一个节点需按集群合并、ownerGroup从哪取     |
| IMPLEMENTATION_PLAN.md Step 5.3                   | QueryDeliverStatus仅有单行注释描述              | 新增完整伪代码(含查找索引key=ClusterName:IDC+对比节点数→FULL/PARTIAL/NONE+回填IPs JSON到ApplyItem+DeliverStatus枚举)                                                | 弱模型不知道对比逻辑用哪个key构建索引、回填IPs到哪个字段、DeliverStatus判定 |
| IMPLEMENTATION_PLAN.md Step 3.1-3.3               | Create/Update无字段校验                      | 新增CheckRule/DrillScene/DeployConfig完整字段校验伪代码(含Scope条件校验+JudgeRule JSON Schema+Steps JSON+Params JSON+Target IP格式)                                          | 弱模型不知道scope=MW_TYPE时mwType必填、JudgeRule每种mode需哪些字段 |
| CONSTRAINTS.md                                    | 原有66条约束                          | 新增9条约束(AES-256-GCM加密模式+SysConfig BeforeCreate Hook加密+BeforeUpdate Hook防重复加密+AfterFind Hook解密不脱敏+DeployClient HTTP调用模式+MonitorClient HTTP调用模式+OpsClient.CallAPI调用模式+ants协程池使用模式) | 补充适配器/Hook/加密/协程池的精确约束(消除5处剩余"自由度")               |
| IMPLEMENTATION_PLAN.md Step 1.3                   | AES加密仅提crypto/aes+密钥来源            | 新增AES-256-GCM完整实现细节(加密模式+nonce随机12字节+密文格式base64(nonce+ciphertext+tag)+aesEncrypt/aesDecrypt完整伪代码+密钥更换后旧密文处理+禁止AES-CBC) | 弱模型不知道选GCM还是CBC、IV如何生成/存储、密文格式                    |
| IMPLEMENTATION_PLAN.md Step 2.1                   | SysConfig仅定义struct无Hook逻辑          | 新增BeforeCreate/BeforeUpdate/AfterFind三个Hook完整伪代码(含加密时机+防重复加密判断+解密不脱敏+设计选择表+边界情况) | 弱模型不知道加密放Service层还是Hook、AfterFind是否应脱敏、BeforeUpdate重复加密问题     |
| IMPLEMENTATION_PLAN.md Step 6.1                   | DeployClient仅函数签名无HTTP调用逻辑        | 新增DeployClient HTTP调用详细逻辑(http.Client{Timeout:30s}+POST不重试+GET可容忍+状态码映射200/400/500/其他+TriggerDeploy/GetDeployStatus/GetDeployStageLog/RetryDeploy各自伪代码) | 弱模型不知道适配器HTTP调用模式(CMDB有重试但Deploy/Monitor不应重试POST)      |
| IMPLEMENTATION_PLAN.md Step 6.3                   | MonitorClient仅函数签名无HTTP调用逻辑       | 新增MonitorClient HTTP调用详细逻辑(同DeployClient模式+TriggerDeploy/TriggerConfig/GetDeployStatus/GetConfigStatus/GetDeployLog/GetConfigDetail各自伪代码) | 同DeployClient, 弱模型不知道两个触发方法的对称模式                    |
| IMPLEMENTATION_PLAN.md Step 7.1                   | OpsClient.CallAPI仅签名                  | 新增CallAPI详细逻辑(http.Client{Timeout:30s}+GET→URL query+POST→JSON Body+不重试+响应解析map[string]any+JSON解析失败保留raw_response+status_code注入result+非标准方法拒绝) | 弱模型不知道CallAPI不重试(与CMDB不同)、GET和POST参数编码方式不同、keyword匹配需要raw_response |
| IMPLEMENTATION_PLAN.md Step 1.1                   | ants仅NewPool(10)一行                   | 新增ants协程池使用模式完整伪代码(仅SCRIPT多节点SSH使用pool.Submit+闭包内panic recovery+sync.Mutex保护并发写入+sync.WaitGroup等待完成+闭包捕获变量复制+pool.Submit失败也要wg.Done+使用规则表) | 弱模型不知道三层规则不并行仅多节点并行、闭包内必须recover+wg.Wait()、Submit失败必须wg.Done |
| IMPLEMENTATION_PLAN.md Step 2.1                   | ResourceApplyItem无Status字段           | 新增`Status string `gorm:"size:16;default:ENABLE"``字段; DeleteApplyItem逻辑删除设Status=DISABLE; 查询必须过滤DISABLE | 弱模型不知道ResourceApplyItem也需要Status字段支持逻辑删除(与其他模型一致) |
| IMPLEMENTATION_PLAN.md Step 5.2                   | Update/Delete/AddApplyItem仅函数签名      | 新增三个方法完整伪代码(含ResourceApply.Status=DRAFT前置校验+Update不可改IPs/DeliverStatus/FailReason+Delete逻辑删除Status=DISABLE+Add必填字段校验+默认值设置) | 弱模型不知道已提交的申请不允许修改/删除/新增条目、DeleteApplyItem需Status字段 |
| IMPLEMENTATION_PLAN.md Step 6.2                   | GetCheckedClusters仅函数签名             | 新增完整伪代码(含核查通过聚合判定:所有CheckRecord.Result=PASS+子查询方案+DeployConfig匹配参数+ClusterDeployVO结构体) | 弱模型不知道"核查通过"是所有记录PASS而非存在PASS记录、用什么查询方案 |
| IMPLEMENTATION_PLAN.md Step 6.2                   | RetryDeploy仅函数签名                    | 新增双路径详细伪代码(TaskID非空→DeployClient.RetryDeploy从失败点继续+TaskID为空→删除旧记录重新TriggerDeploy+Status!=FAILED拒绝重试) | 弱模型不知道RetryDeploy有两条路径(取决于TaskID是否存在)、外部重试vs本地重新触发 |
| IMPLEMENTATION_PLAN.md Step 6.4                   | MonitorService VO未定义                 | 新增MonitorDeployVO+MonitorConfigVO结构体定义+GetDeployStatus/GetConfigStatus完整伪代码(含ConfigDetail从MinIO读取) | 弱模型不知道返回VO的字段定义、ConfigDetail的来源 |
| IMPLEMENTATION_PLAN.md Step 7.2                   | RetryDrill仅函数签名                     | 新增完整伪代码(物理删除旧DrillRecord+重新ExecuteDrill单场景+场景DISABLE拒绝重试+使用当前DrillScene.Steps) | 弱模型不知道RetryDrill=删除+重执行(非逻辑删除)、物理删除原因、单场景重试 |
| CONSTRAINTS.md                                    | 原有74条约束                          | 新增8条约束(ResourceApplyItem.Status字段+CRUD前置状态校验+AddApplyItem字段校验+GetCheckedClusters聚合判定+RetryDeploy双路径+RetryDrill删除+重执行+查询过滤DISABLE+MonitorDeployVO/MonitorConfigVO定义) | 消除弱模型在Retry语义、前置校验、聚合查询的残余歧义 |
| IMPLEMENTATION_PLAN.md Step 1.5                   | RateLimit伪代码逻辑反转                  | 修复: limiter.Allow()返回true=放行, false=拒绝; 原伪代码`if !limiter.Allow()`导致放行被拒绝的请求 | 伪代码错误, 弱模型按原伪代码实现会写反限流逻辑 |
| IMPLEMENTATION_PLAN.md Step 5.1                   | CMDBClient仅函数签名无HTTP调用逻辑        | 新增CMDBClient HTTP调用详细逻辑(与Deploy/Monitor/Ops不同: CMDB的GET和POST都有重试3次间隔5秒+Retry封装函数+400不重试+500重试+SubmitResource幂等可重试) | CMDB是唯一有重试的适配器(与Deploy/Monitor/Ops的POST不重试不同), 弱模型不知道这个差异 |
| IMPLEMENTATION_PLAN.md Step 5.2                   | ResourceService无ConfigCenter依赖       | struct新增`configCenter *config.ConfigCenter`; NewResourceService新增configCenter参数 | InitApply需要从ConfigCenter取ownerGroup/opsGroup |
| IMPLEMENTATION_PLAN.md Step 4.1                   | GetFlowStatus仅有FlowStatusVO注释       | 新增FlowStatusVO+PhaseStatusVO+ClusterStatusVO完整结构体定义+聚合逻辑伪代码(5个环节各自如何聚合集群明细) | 弱模型不知道VO的字段定义、每个环节如何聚合集群维度状态 |
| IMPLEMENTATION_PLAN.md Step 6.2                   | GetDeployDetail仅有注释                 | 新增DeployDetailVO+DeployStageVO完整结构体定义+GetDeployDetail查询逻辑(含MinIO签名链接)+GetStageLog查询逻辑 | 弱模型不知道VO字段定义、签名链接生成、日志查询模式 |
| IMPLEMENTATION_PLAN.md Step 7.2                   | GetDeployedClusters/GetDrillDetail仅有签名 | 新增ClusterDrillVO结构体定义+GetDeployedClusters查询逻辑(含演练状态汇总NONE/PARTIAL/ALL_DONE/FAILED)+GetDrillDetail/GetDrillLog查询逻辑 | 弱模型不知道ClusterDrillVO字段、演练汇总判定规则 |
| FRONTEND_SPEC.md                                  | Phase 8前端仅有目录结构和组件名          | 新增完整前端规格(14章节: 技术栈/API封装/Pinia状态管理/路由配置/8个页面交互流程/3个公共组件/生命周期与数据流/错误处理/CSS规范 + TypeScript类型定义/API方法签名/Pinia Store模块/WebSocket推送消息Schema/组件级渲染规则) | 前端是最大缺口, 弱模型面对前端时"最常见模式"与产品需求差异大 |
| TEST_SPECS.md                                     | 仅281行覆盖主要测试场景                 | 新增CONSTRAINT覆盖映射表(C01-C77)+约40个新增测试用例(按P0/P1/P2分组) | 82条约束中62条缺少测试覆盖, 需补充 |
| IMPLEMENTATION_PLAN.md Step 1.2                   | 17个POST/PUT endpoint缺请求body JSON结构体 | 新增Handler Request结构体定义(CreateFlowReq/InitApplyReq/UpdateApplyItemReq/AddApplyItemReq/MonitorDeployReq/MonitorConfigReq/DrillExecuteReq) | 弱模型不知道handler req结构体与Model的区别(binding标签不同、字段可改范围不同) |
| IMPLEMENTATION_PLAN.md Step 1.2                   | 3个VO缺独立Go结构体定义                 | 新增DeliverStatusVO/ClusterDeployVO/ConfirmSubmitResult/FailedClusterInfo/MonitorStatusVO/CreateFlowVO Go结构体 | 弱模型不知道这些VO需在service层定义而非handler层 |
| IMPLEMENTATION_PLAN.md Step 1.2                   | monitor/status响应结构未定义              | 新增MonitorStatusVO(deploy+config合并)结构体 | 弱模型不知道如何将两个VO合并为一个JSON响应 |
| AGENTS.md Code Map                                | 7个API入口缺失query/body参数             | 补充check-rules/drill-scenes/deploy-configs List等的完整参数 | 前端需要知道完整参数才能正确调用API |
| STUBS/api/v1/routes.go                            | WebSocket路由 `/ws` 不在JWTAuth组        | STUBS注册 `/api/v1/ws/flow` 在JWTAuth组内 | WebSocket不应走JWTAuth中间件, STUBS错误 |
| STUBS/api/v1/resource.go                          | RegisterResourceRoutes不需config.Config   | STUBS函数签名包含cfg *config.Config | Handler不应依赖Config, 应依赖ResourceService |

## LLM 工作指引

### 开始新任务时

1. 先读本文件（AGENTS.md）了解当前状态和偏差
2. 读蓝图文件了解意图（按需读取相关 Phase）
3. 读现有代码了解真相（STUBS 下的骨架 + 已填充的实现）
4. **以代码为准，蓝图仅作为意图参考**

### 实现过程中的规则

- 遵循 CONSTRAINTS.md 中的精确代码指引，不可违反
- 遵循 ARCHITECTURE.md 中的模块边界，业务模块之间不互相调用
- 新增功能时：先确认 PRODUCT_REQUIREMENTS.md 中是否有对应需求
- 修改架构时：必须同步更新 ARCHITECTURE.md 和本文件偏差记录
- Bug 修复/实现微调：仅更新本文件偏差记录，不回溯改 IMPLEMENTATION_PLAN

### 编码规范

- 对核心实现逻辑进行充分的注释，使用简单的语言
- 统一响应格式: `pkg/response/response.go` 的 Success/Fail
- 错误码分段: `pkg/errcode/errcode.go` 系统级1XXX/业务级2XXX
- RESTful 路径: 名词复数，不用动词
- 逻辑删除: Delete 操作设 status=DISABLE，不物理删除
- 幂等: 批量操作用唯一索引防重

### 验证命令

```bash
# 编译
go build ./cmd/server/

# 全量测试
go test ./...

# 依赖检查（不允许 redis/nacos/elastic）
grep -E 'redis|nacos|elastic' go.mod  # 应返回空

# 路径检查（不允许动词路径）
grep -r '/api/v1/get' api/  # 应返回空

# 前端构建
cd web && npm run build
```

## 下一步计划

开始 Phase 1 实现：将 STUBS 代码逐步填充为真实逻辑，按 Step 1.1 → 1.5 顺序执行。

### 关键步骤的详细逻辑流程（已补充）

以下6个步骤在 IMPLEMENTATION_PLAN.md 中已补充了完整的功能逻辑流程描述（正常流程+异常流程+边界情况），弱模型实现时必须参考：

- **Step 4.1** FlowEngine.StartPhase — 前置依赖校验的精确规则（并行、FAILED重触发、DRILL放宽DEPLOY依赖）
- **Step 5.2** ResourceService.ConfirmAndSubmit — 逐集群提交+部分失败处理+SUBMIT_FAILED/SUBMITTED/PARTIAL_SUBMITTED三种状态
- **Step 5.3** CheckService.ExecuteCheck — 三层串行+FAIL不中断+SCRIPT全节点执行+重新核查覆盖+JudgeRule四种mode
- **Step 6.2** DeployService.TriggerDeploy — 后台轮询(360次/10秒/1小时)+三阶段日志即时上传MinIO+超时处理+重复触发拒绝
- **Step 6.4** MonitorService.TriggerDeploy/TriggerConfig — 两个独立轮询(180次/10秒/30分钟)+DeployStatus/ConfigStatus分别管理+Config依赖Deploy=DONE
- **Step 7.2** DrillService.ExecuteDrill — 三层串行+步骤FAIL不中断+SHELL全节点执行+重新演练覆盖+DRILL依赖DEPLOY=RUNNING或DONE

以下5个新增步骤在 IMPLEMENTATION_PLAN.md 中已补充了完整的功能逻辑流程描述，消除弱模型的剩余"自由度"：

- **Step 1.3** AES-256-GCM加密/解密 — 密文格式base64(nonce+ciphertext+tag)+nonce随机12字节+禁止AES-CBC+密钥更换后旧密文处理
- **Step 2.1** SysConfig GORM Hook — BeforeCreate加密+BeforeUpdate防重复加密+AfterFind解密不脱敏(脱敏由ConfigCenter.Get控制)
- **Step 1.1** ants协程池使用模式 — 仅SCRIPT多节点SSH使用pool.Submit+闭包内panic recovery+Mutex+WaitGroup+闭包变量复制+Submit失败wg.Done
- **Step 6.1** DeployClient HTTP调用 — POST不重试(非幂等)+GET可容忍+状态码映射+http.Client{Timeout:30s}
- **Step 6.3** MonitorClient HTTP调用 — 同DeployClient模式+TriggerDeploy/TriggerConfig对称+两个独立轮询链路
- **Step 7.1** OpsClient.CallAPI — GET→URL query+POST→JSON Body+不重试+JSON解析失败保留raw_response+status_code注入result
