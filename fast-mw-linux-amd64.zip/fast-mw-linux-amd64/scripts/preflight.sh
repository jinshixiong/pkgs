#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "请使用 root 或 sudo 执行 preflight.sh" >&2
  exit 1
fi

errors=0
ok() { printf '[OK] %s\n' "$1"; }
fail() { printf '[FAIL] %s\n' "$1" >&2; errors=$((errors + 1)); }

case "$(uname -m)" in
  x86_64|amd64) ok "CPU架构为x86_64" ;;
  *) fail "CPU架构不是x86_64: $(uname -m)" ;;
esac

for command_name in systemctl curl sqlite3 ansible-playbook nginx runuser file; do
  if command -v "${command_name}" >/dev/null 2>&1; then
    ok "命令可用: ${command_name}"
  else
    fail "缺少命令: ${command_name}"
  fi
done

for binary_path in /opt/fast-mw/bin/fast-mw-platform /opt/fast-mw/bin/fast-mw-migrate /opt/mwdeploy/bin/mwdeploy; do
  if [[ -x ${binary_path} ]] && file "${binary_path}" | grep -q 'ELF 64-bit.*x86-64'; then
    ok "Linux二进制有效: ${binary_path}"
  else
    fail "二进制缺失或不是Linux x86_64 ELF: ${binary_path}"
  fi
done

for config_path in /etc/fast-mw/config.yaml /etc/fast-mw/platform.env /etc/mwdeploy/fastMwService.yml /etc/mwdeploy/mwManageConfig.yml /etc/mwdeploy/api-token; do
  if [[ -s ${config_path} ]]; then
    ok "配置存在: ${config_path}"
  else
    fail "配置缺失或为空: ${config_path}"
  fi
done

if [[ -d /var/log/fast-mw ]] && runuser -u fastmw -- test -w /var/log/fast-mw; then
  ok "平台日志目录可写: /var/log/fast-mw"
else
  fail "平台日志目录不存在或不可写: /var/log/fast-mw"
fi

if [[ -d /var/log/mwdeploy ]] && runuser -u mwdeploy -- test -w /var/log/mwdeploy; then
  ok "mwDeploy日志目录可写: /var/log/mwdeploy"
else
  fail "mwDeploy日志目录不存在或不可写: /var/log/mwdeploy"
fi

if grep -Eq '__[A-Z0-9_]+__' /etc/fast-mw/config.yaml 2>/dev/null; then
  fail "平台配置仍包含未替换占位符"
else
  ok "平台配置占位符已替换"
fi

if grep -Eq '^[[:space:]]*services:[[:space:]]*\[\][[:space:]]*$' /etc/mwdeploy/mwManageConfig.yml 2>/dev/null; then
  fail "mwDeploy Catalog仍为空"
else
  ok "mwDeploy Catalog已配置"
fi

if [[ -f /opt/mwdeploy/mw-ansible/common/verify.yml ]]; then
  ok "通用验证Playbook存在"
else
  fail "缺少 /opt/mwdeploy/mw-ansible/common/verify.yml"
fi

if find /opt/mwdeploy/mw-ansible -type f -name '*.tpl' -print -quit 2>/dev/null | grep -q .; then
  ok "Inventory模板存在"
else
  fail "没有找到Inventory模板 (*.tpl)"
fi

token_file_value="$(tr -d '\r\n' < /etc/mwdeploy/api-token 2>/dev/null || true)"
token_env_value="$(sed -n 's/^MW_DEPLOY_API_TOKEN=//p' /etc/fast-mw/platform.env 2>/dev/null | tail -n 1)"
if [[ -n ${token_file_value} && ${token_file_value} == "${token_env_value}" ]]; then
  ok "平台与mwDeploy Token一致"
else
  fail "平台与mwDeploy Token不一致"
fi

if [[ -f /etc/nginx/conf.d/fast-mw.conf ]]; then
  if grep -Eq '__[A-Z0-9_]+__' /etc/nginx/conf.d/fast-mw.conf; then
    fail "Nginx配置仍包含未替换占位符"
  elif nginx -t; then
    ok "Nginx配置有效"
  else
    fail "Nginx配置检查失败"
  fi
else
  fail "尚未启用 /etc/nginx/conf.d/fast-mw.conf"
fi

if command -v systemd-analyze >/dev/null 2>&1; then
  if systemd-analyze verify /etc/systemd/system/mwdeploy.service /etc/systemd/system/fast-mw-platform.service; then
    ok "systemd单元有效"
  else
    fail "systemd单元检查失败"
  fi
fi

if runuser -u mwdeploy -- /usr/bin/ansible-playbook --version >/dev/null 2>&1; then
  ok "mwdeploy用户可执行Ansible"
else
  fail "mwdeploy用户无法执行 /usr/bin/ansible-playbook"
fi

if (( errors > 0 )); then
  printf '\n预检失败，共 %d 项。修复后再启动服务。\n' "${errors}" >&2
  exit 1
fi

echo
echo "预检通过。请另外确认MinIO中已创建minio.bucket配置的bucket，以及CMDB/监控/CAS网络和目标机SSH连通性。"
